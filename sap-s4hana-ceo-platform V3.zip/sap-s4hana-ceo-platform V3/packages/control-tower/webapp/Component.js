sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/Device",
  "sap/ui/model/json/JSONModel",
  "com/company/controltower/model/ErrorHandler",
  "com/company/controltower/model/Formatter"
], function (UIComponent, Device, JSONModel, ErrorHandler, Formatter) {
  "use strict";

  return UIComponent.extend("com.company.controltower.Component", {

    metadata: {
      manifest: "json"
    },

    /**
     * Component initialisation.
     * Manifest models (procurement, sales, bp, billing, ui) are already
     * instantiated before this runs. We add:
     *   - device model for responsive bindings
     *   - global OData error handler
     *   - formatter reference
     *   - router
     */
    init: function () {
      UIComponent.prototype.init.apply(this, arguments);

      // Device model
      var oDeviceModel = new JSONModel(Device);
      oDeviceModel.setDefaultBindingMode("OneWay");
      this.setModel(oDeviceModel, "device");

      // Global OData error handler — attaches to all four API models
      this._oErrorHandler = new ErrorHandler(this);

      // Make formatter available to all controllers and XML views
      this.formatter = Formatter;

      // Start routing
      this.getRouter().initialize();
    },

    getContentDensityClass: function () {
      if (this._sContentDensityClass === undefined) {
        this._sContentDensityClass = Device.support.touch
          ? "sapUiSizeCozy"
          : "sapUiSizeCompact";
      }
      return this._sContentDensityClass;
    },

    destroy: function () {
      if (this._oErrorHandler) {
        this._oErrorHandler.destroy();
      }
      UIComponent.prototype.destroy.apply(this, arguments);
    }
  });
});
