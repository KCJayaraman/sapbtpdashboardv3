/**
 * DelaySimulationEngine.js
 * com.logistics.delaylib.simulation.DelaySimulationEngine
 * ─────────────────────────────────────────────────────────────────────────────
 * Monte Carlo simulation engine for logistics delay forecasting.
 * Runs N iterations of a shipment against configurable risk scenarios
 * and returns probability distributions, P50/P90/P99 estimates, and
 * cost-impact projections.
 *
 * Framework-agnostic — no sap.m dependency at runtime.
 * ─────────────────────────────────────────────────────────────────────────────
 */
sap.ui.define([
  "sap/ui/base/Object"
], function (BaseObject) {
  "use strict";

  /**
   * Predefined scenario parameter sets.
   * Each scenario defines probability distributions for delay components.
   * Values are in days.
   */
  var SCENARIO_PARAMS = {
    Baseline: {
      portDelay:      { min: 0, max: 2,  mean: 0.5, stdDev: 0.8 },
      transitDelay:   { min: 0, max: 3,  mean: 0.3, stdDev: 0.6 },
      customsDelay:   { min: 0, max: 2,  mean: 0.2, stdDev: 0.4 },
      weatherDelay:   { min: 0, max: 1,  mean: 0.1, stdDev: 0.3 },
      carrierDelay:   { min: 0, max: 1,  mean: 0.2, stdDev: 0.3 },
      eventProb:      0.02  // probability of major disruption event
    },
    PortCongestion: {
      portDelay:      { min: 2, max: 14, mean: 5.0, stdDev: 3.0 },
      transitDelay:   { min: 0, max: 3,  mean: 0.5, stdDev: 0.8 },
      customsDelay:   { min: 0, max: 3,  mean: 0.3, stdDev: 0.6 },
      weatherDelay:   { min: 0, max: 1,  mean: 0.1, stdDev: 0.3 },
      carrierDelay:   { min: 1, max: 5,  mean: 2.0, stdDev: 1.2 },
      eventProb:      0.15
    },
    WeatherDisruption: {
      portDelay:      { min: 0, max: 5,  mean: 1.5, stdDev: 1.5 },
      transitDelay:   { min: 1, max: 10, mean: 4.0, stdDev: 2.5 },
      customsDelay:   { min: 0, max: 2,  mean: 0.2, stdDev: 0.5 },
      weatherDelay:   { min: 2, max: 14, mean: 5.0, stdDev: 3.0 },
      carrierDelay:   { min: 0, max: 3,  mean: 0.8, stdDev: 1.0 },
      eventProb:      0.20
    },
    CustomsDelay: {
      portDelay:      { min: 0, max: 3,  mean: 0.5, stdDev: 0.8 },
      transitDelay:   { min: 0, max: 2,  mean: 0.3, stdDev: 0.5 },
      customsDelay:   { min: 3, max: 21, mean: 7.0, stdDev: 4.0 },
      weatherDelay:   { min: 0, max: 1,  mean: 0.1, stdDev: 0.2 },
      carrierDelay:   { min: 0, max: 2,  mean: 0.3, stdDev: 0.5 },
      eventProb:      0.25
    },
    CapacityShortage: {
      portDelay:      { min: 1, max: 7,  mean: 3.0, stdDev: 1.8 },
      transitDelay:   { min: 0, max: 5,  mean: 1.5, stdDev: 1.2 },
      customsDelay:   { min: 0, max: 2,  mean: 0.2, stdDev: 0.4 },
      weatherDelay:   { min: 0, max: 1,  mean: 0.1, stdDev: 0.2 },
      carrierDelay:   { min: 2, max: 10, mean: 4.0, stdDev: 2.0 },
      eventProb:      0.10
    },
    Strike: {
      portDelay:      { min: 3, max: 30, mean: 10.0, stdDev: 6.0 },
      transitDelay:   { min: 0, max: 5,  mean: 1.0,  stdDev: 1.5 },
      customsDelay:   { min: 0, max: 3,  mean: 0.5,  stdDev: 0.8 },
      weatherDelay:   { min: 0, max: 1,  mean: 0.1,  stdDev: 0.2 },
      carrierDelay:   { min: 5, max: 20, mean: 8.0,  stdDev: 4.0 },
      eventProb:      0.40
    },
    Geopolitical: {
      portDelay:      { min: 0, max: 7,  mean: 2.0, stdDev: 2.0 },
      transitDelay:   { min: 3, max: 21, mean: 8.0, stdDev: 5.0 },
      customsDelay:   { min: 1, max: 10, mean: 3.0, stdDev: 2.5 },
      weatherDelay:   { min: 0, max: 2,  mean: 0.3, stdDev: 0.6 },
      carrierDelay:   { min: 2, max: 14, mean: 5.0, stdDev: 3.5 },
      eventProb:      0.30
    }
  };

  return BaseObject.extend("com.logistics.delaylib.simulation.DelaySimulationEngine", {

    /**
     * @param {object} [oConfig]
     * @param {number} [oConfig.iterations=1000]   Monte Carlo iterations
     * @param {number} [oConfig.seed]              Optional RNG seed (for reproducibility)
     * @param {number} [oConfig.demurrageDayRate=500] USD per day demurrage cost
     * @param {number} [oConfig.expediteCostRate=0.03]  % of shipment value for air freight upgrade
     */
    constructor: function (oConfig) {
      oConfig = oConfig || {};
      this._nIterations    = oConfig.iterations         || 1000;
      this._fDemurrageRate = oConfig.demurrageDayRate   || 500;
      this._fExpeditRate   = oConfig.expediteCostRate   || 0.03;
      this._oCustomScenarios = {};
      if (oConfig.seed !== undefined) {
        this._rng = this._seededRng(oConfig.seed);
      } else {
        this._rng = Math.random.bind(Math);
      }
    },

    // ── Simulation API ──────────────────────────────────────────────────────

    /**
     * Run a Monte Carlo simulation for a single shipment.
     *
     * @param {object} oShipment          Shipment context
     * @param {string} sScenario          Scenario name (from SimulationScenario enum)
     * @param {object} [oCustomParams]    Override scenario params for "Custom" scenario
     * @returns {object}                  Simulation result with statistics
     */
    simulate: function (oShipment, sScenario, oCustomParams) {
      var oParams = this._getScenarioParams(sScenario, oCustomParams);
      var aDelays = [];
      var aCosts  = [];
      var fValue  = parseFloat(oShipment.value || 0);

      for (var i = 0; i < this._nIterations; i++) {
        var fDelay = this._sampleDelay(oParams);
        var fCost  = this._computeCost(fDelay, fValue, oParams);
        aDelays.push(fDelay);
        aCosts.push(fCost);
      }

      aDelays.sort(function (a, b) { return a - b; });
      aCosts.sort(function (a, b) { return a - b; });

      return {
        scenario:      sScenario,
        shipment:      oShipment.reference || oShipment.orderId,
        iterations:    this._nIterations,
        delays: {
          p10:   this._percentile(aDelays, 10),
          p50:   this._percentile(aDelays, 50),
          p90:   this._percentile(aDelays, 90),
          p99:   this._percentile(aDelays, 99),
          mean:  this._mean(aDelays),
          stdDev:this._stdDev(aDelays),
          min:   aDelays[0],
          max:   aDelays[aDelays.length - 1],
          histogram: this._histogram(aDelays, 10)
        },
        costs: {
          p50:   this._percentile(aCosts, 50),
          p90:   this._percentile(aCosts, 90),
          mean:  this._mean(aCosts),
          max:   aCosts[aCosts.length - 1]
        },
        onTimeProb:   aDelays.filter(function (d) { return d <= 0; }).length / this._nIterations,
        delayProb:    aDelays.filter(function (d) { return d >  0; }).length / this._nIterations,
        severeProb:   aDelays.filter(function (d) { return d >= 7; }).length / this._nIterations,
        simulatedAt:  new Date().toISOString()
      };
    },

    /**
     * Compare multiple scenarios for the same shipment.
     * @param {object} oShipment
     * @param {Array}  aScenarios  Array of scenario name strings
     * @returns {object}  { comparison: [{scenario, p50, p90, delayProb, costP90}] }
     */
    compareScenarios: function (oShipment, aScenarios) {
      var that        = this;
      var aComparison = aScenarios.map(function (sScenario) {
        var oResult = that.simulate(oShipment, sScenario);
        return {
          scenario:   sScenario,
          p50:        oResult.delays.p50,
          p90:        oResult.delays.p90,
          delayProb:  Math.round(oResult.delayProb  * 100),
          severeProb: Math.round(oResult.severeProb * 100),
          onTimeProb: Math.round(oResult.onTimeProb * 100),
          costP90:    oResult.costs.p90,
          costMean:   oResult.costs.mean
        };
      });
      return {
        shipment:   oShipment.reference || oShipment.orderId,
        comparison: aComparison
      };
    },

    /**
     * Run a batch simulation across multiple shipments.
     * @param {Array}  aShipments
     * @param {string} sScenario
     * @returns {object}  { results, portfolioStats }
     */
    simulateBatch: function (aShipments, sScenario) {
      var that    = this;
      var aResults = aShipments.map(function (oShip) {
        return that.simulate(oShip, sScenario);
      });

      var aAllP90  = aResults.map(function (r) { return r.delays.p90;    });
      var aAllCost = aResults.map(function (r) { return r.costs.p90;     });
      var nDelayed = aResults.filter(function (r) { return r.delayProb > 0.5; }).length;

      return {
        results: aResults,
        portfolioStats: {
          totalShipments:  aShipments.length,
          expectedDelayed: nDelayed,
          portfolioP90:    this._mean(aAllP90),
          totalCostP90:    aAllCost.reduce(function (s, v) { return s + v; }, 0),
          worstCase:       Math.max.apply(null, aAllP90)
        }
      };
    },

    /**
     * Register a custom scenario with its own parameter set.
     */
    registerScenario: function (sName, oParams) {
      this._oCustomScenarios[sName] = oParams;
      return this;
    },

    /** Get scenario parameter set by name. */
    getScenarioParams: function (sScenario) {
      return this._getScenarioParams(sScenario, null);
    },

    /** List all available scenario names. */
    getScenarioNames: function () {
      return Object.keys(SCENARIO_PARAMS)
        .concat(Object.keys(this._oCustomScenarios));
    },

    // ── Internal — sampling & stats ─────────────────────────────────────────

    _getScenarioParams: function (sScenario, oOverride) {
      if (oOverride) { return oOverride; }
      if (this._oCustomScenarios[sScenario]) {
        return this._oCustomScenarios[sScenario];
      }
      return SCENARIO_PARAMS[sScenario] || SCENARIO_PARAMS["Baseline"];
    },

    /** Sample total delay for one iteration using the scenario parameters. */
    _sampleDelay: function (oParams) {
      var fDelay = 0;
      fDelay += this._sampleNormal(oParams.portDelay);
      fDelay += this._sampleNormal(oParams.transitDelay);
      fDelay += this._sampleNormal(oParams.customsDelay);
      fDelay += this._sampleNormal(oParams.weatherDelay);
      fDelay += this._sampleNormal(oParams.carrierDelay);

      // Random major disruption event
      if (this._rng() < (oParams.eventProb || 0)) {
        fDelay += this._sampleUniform(5, 21);
      }

      return Math.max(0, Math.round(fDelay * 10) / 10);
    },

    /** Compute cost impact for a given delay. */
    _computeCost: function (fDelay, fValue, oParams) {
      var fDemurrage = fDelay * this._fDemurrageRate;
      var fExpedite  = fDelay > 5 ? fValue * this._fExpeditRate : 0;
      return Math.round(fDemurrage + fExpedite);
    },

    /** Box-Muller transform for normal distribution sampling. */
    _sampleNormal: function (oSpec) {
      var u1 = this._rng();
      var u2 = this._rng();
      var z  = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
      var fRaw = oSpec.mean + oSpec.stdDev * z;
      return Math.min(oSpec.max, Math.max(oSpec.min, fRaw));
    },

    _sampleUniform: function (fMin, fMax) {
      return fMin + this._rng() * (fMax - fMin);
    },

    _percentile: function (aSorted, nP) {
      var idx = Math.floor((nP / 100) * aSorted.length);
      return Math.round(aSorted[Math.min(idx, aSorted.length - 1)] * 10) / 10;
    },

    _mean: function (aVals) {
      return Math.round((aVals.reduce(function (s, v) { return s + v; }, 0) / aVals.length) * 10) / 10;
    },

    _stdDev: function (aVals) {
      var fMean = this._mean(aVals);
      var fVar  = aVals.reduce(function (s, v) { return s + Math.pow(v - fMean, 2); }, 0) / aVals.length;
      return Math.round(Math.sqrt(fVar) * 10) / 10;
    },

    _histogram: function (aSorted, nBins) {
      var fMin  = aSorted[0];
      var fMax  = aSorted[aSorted.length - 1];
      var fStep = (fMax - fMin) / nBins || 1;
      var aBins = Array.from({ length: nBins }, function (_, i) {
        return { from: Math.round((fMin + i * fStep) * 10) / 10, count: 0 };
      });
      aSorted.forEach(function (v) {
        var nIdx = Math.min(Math.floor((v - fMin) / fStep), nBins - 1);
        aBins[nIdx].count++;
      });
      return aBins;
    },

    /** Linear congruential generator for seeded random numbers. */
    _seededRng: function (nSeed) {
      var s = nSeed;
      return function () {
        s = (s * 1664525 + 1013904223) & 0xffffffff;
        return (s >>> 0) / 0xffffffff;
      };
    }
  });
});
