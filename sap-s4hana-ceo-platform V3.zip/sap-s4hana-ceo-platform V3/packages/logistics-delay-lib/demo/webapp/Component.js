sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/model/json/JSONModel",
  "com/logistics/delaylib/rules/RulesEngine",
  "com/logistics/delaylib/simulation/DelaySimulationEngine"
], function (UIComponent, JSONModel, RulesEngine, DelaySimulationEngine) {
  "use strict";

  return UIComponent.extend("com.logistics.delaylib.demo.Component", {
    metadata: { manifest: "json" },

    init: function () {
      UIComponent.prototype.init.apply(this, arguments);

      // ── Bootstrap Rules Engine with default rules ──────────────────────────
      this._oEngine = new RulesEngine({ stopOnFirst: false, dryRun: false });
      this._oEngine.loadRules(this._oEngine.getDefaultRules());
      this.setModel(new JSONModel({ engine: this._oEngine }), "rules");

      // ── Bootstrap Simulation Engine ────────────────────────────────────────
      this._oSimEngine = new DelaySimulationEngine({
        iterations:      1000,
        demurrageDayRate:500,
        expediteCostRate:0.03
      });
      this.setModel(new JSONModel({ simEngine: this._oSimEngine }), "sim");

      // ── Sample shipment data ───────────────────────────────────────────────
      var oDataModel = new JSONModel({
        shipments: [
          { orderId:"TC-001", reference:"MAEU123456789", carrier:"Maersk",    mode:"SEA", modeIcon:"sap-icon://shipping-status", pol:"Rotterdam",  pod:"Shanghai",   eta:"2025-03-20", delayDays:8,  isDelayed:true,  status:"Delayed",   statusState:"Error",   delayState:"Error",   value:250000, soReference:"4500012345" },
          { orderId:"TC-002", reference:"EK180-12345678",carrier:"Emirates",   mode:"AIR", modeIcon:"sap-icon://flight",          pol:"Dubai",      pod:"New York",   eta:"2025-03-18", delayDays:2,  isDelayed:true,  status:"Delayed",   statusState:"Error",   delayState:"Error",   value:85000,  soReference:"" },
          { orderId:"TC-003", reference:"HLCU987654321", carrier:"Hapag-Lloyd",mode:"SEA", modeIcon:"sap-icon://shipping-status", pol:"Hamburg",    pod:"Singapore",  eta:"2025-03-25", delayDays:0,  isDelayed:false, status:"On Time",   statusState:"Success", delayState:"Success", value:180000, soReference:"4500019876" },
          { orderId:"TC-004", reference:"COSCO11223344", carrier:"COSCO",      mode:"SEA", modeIcon:"sap-icon://shipping-status", pol:"Tianjin",    pod:"Rotterdam",  eta:"2025-03-22", delayDays:14, isDelayed:true,  status:"Critical",  statusState:"Error",   delayState:"Error",   value:420000, soReference:"4500032100" },
          { orderId:"TC-005", reference:"LH458-99887766",carrier:"Lufthansa",  mode:"AIR", modeIcon:"sap-icon://flight",          pol:"Frankfurt",  pod:"Tokyo",      eta:"2025-03-16", delayDays:0,  isDelayed:false, status:"Delivered", statusState:"Success", delayState:"Success", value:62000,  soReference:"" },
          { orderId:"TC-006", reference:"ONE123987654",  carrier:"ONE",        mode:"SEA", modeIcon:"sap-icon://shipping-status", pol:"Busan",      pod:"Los Angeles",eta:"2025-03-28", delayDays:5,  isDelayed:true,  status:"Delayed",   statusState:"Error",   delayState:"Error",   value:310000, soReference:"4500041233" }
        ],
        kpis: {
          totalShipments: "6",
          delayed:        "4",
          onTimeRate:     "33%",
          avgDelayDays:   "4.8 days",
          onTimeRateState:"Error"
        }
      });
      this.setModel(oDataModel, "demo");

      this.getRouter().initialize();
    },

    getRulesEngine:     function () { return this._oEngine; },
    getSimulationEngine:function () { return this._oSimEngine; }
  });
});
