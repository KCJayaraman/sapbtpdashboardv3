sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
  "use strict";

  return Controller.extend("com.logistics.delaylib.demo.controller.Monitor", {

    onInit: function () {
      this.getOwnerComponent().getRouter()
        .getRoute("monitor")
        .attachPatternMatched(this._onRouteMatched, this);
    },

    _onRouteMatched: function () {
      var oMonitor  = this.byId("delayMonitor");
      var oModel    = this.getOwnerComponent().getModel("demo");

      // Bind the DelayMonitor control's internal table to the demo shipment data
      if (oMonitor) {
        oMonitor.setModel(oModel, "demo");
        oMonitor.bindShipmentData("demo", "/shipments");
      }

      // Run the RulesEngine against all sample shipments
      this._evaluateRules();
    },

    _evaluateRules: function () {
      var oEngine    = this.getOwnerComponent().getRulesEngine();
      var oDataModel = this.getOwnerComponent().getModel("demo");
      var aShipments = oDataModel.getProperty("/shipments") || [];

      // Batch evaluate — returns array of per-shipment results
      var oBatch = oEngine.evaluateBatch(aShipments);

      // Flatten all matched rules into a list for the results panel
      var aMatches = [];
      oBatch.results.forEach(function (oResult) {
        oResult.matched.forEach(function (oMatch) {
          oMatch.actions.forEach(function (oAction) {
            aMatches.push({
              ruleName:     oMatch.ruleName,
              severity:     oMatch.severity,
              severityState:oMatch.severity === "Critical" || oMatch.severity === "Error"
                              ? "Error"
                            : oMatch.severity === "Warning" ? "Warning" : "None",
              message:      oAction.message,
              shipment:     oResult.shipment
            });
          });
        });
      });

      // Bind results to the rule result list
      var oResultList = this.byId("ruleResultList");
      if (oResultList) {
        var oResultModel = new JSONModel(aMatches);
        oResultList.setModel(oResultModel, "rules");
        oResultList.bindItems({
          model:    "rules",
          path:     "/",
          template: oResultList.getItems().length > 0
            ? oResultList.removeItem(0)
            : this._buildResultItemTemplate()
        });
      }
    },

    _buildResultItemTemplate: function () {
      return new sap.m.ObjectListItem({
        icon:        "sap-icon://alert",
        title:       "{rules>ruleName}",
        number:      "{rules>severity}",
        numberState: "{rules>severityState}",
        attributes:  [
          new sap.m.ObjectAttribute({ text: "{rules>message}" })
        ]
      });
    },

    onShipmentPress: function (oEvent) {
      var sRef      = oEvent.getParameter("reference");
      var nDelay    = oEvent.getParameter("delayDays");
      var sCarrier  = oEvent.getParameter("carrier");
      MessageBox.information(
        "Shipment: " + sRef + "\nCarrier: " + sCarrier + "\nDelay: " + nDelay + " days\n\nIn production, this opens the TrackCargo tracking dialog.",
        { title: "Shipment Detail" }
      );
    },

    onRefresh: function () {
      MessageToast.show("Refreshing from TrackCargo API…");
      this._evaluateRules();
    }
  });
});
