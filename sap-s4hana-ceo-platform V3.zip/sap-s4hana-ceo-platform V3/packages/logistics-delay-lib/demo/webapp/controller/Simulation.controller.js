sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/MessageToast"
], function (Controller, MessageToast) {
  "use strict";

  return Controller.extend("com.logistics.delaylib.demo.controller.Simulation", {

    onInit: function () {
      this.getOwnerComponent().getRouter()
        .getRoute("simulation")
        .attachPatternMatched(this._onRouteMatched, this);
    },

    _onRouteMatched: function () {
      var oSimCtrl  = this.byId("delaySimulator");
      var oSimEngine = this.getOwnerComponent().getSimulationEngine();

      // Inject the shared simulation engine into the control
      if (oSimCtrl && oSimEngine) {
        oSimCtrl._oEngine = oSimEngine;
      }
    },

    onSimulationComplete: function (oEvent) {
      var sScenario = oEvent.getParameter("scenario");
      var oResult   = oEvent.getParameter("result");
      MessageToast.show(
        "Simulation complete — " + sScenario +
        ": P50 = " + oResult.delays.p50 + "d, P90 = " + oResult.delays.p90 + "d"
      );
    }
  });
});
