/**
 * DelayMonitor.js
 * com.logistics.delaylib.control.DelayMonitor
 * ─────────────────────────────────────────────────────────────────────────────
 * A reusable SAP UI5 composite control that renders a self-contained
 * delay monitoring dashboard panel. Can be dropped into any SAP UI5 view.
 *
 * XML usage:
 *   <delaylib:DelayMonitor
 *     id="myMonitor"
 *     title="Sea Freight Delays"
 *     totalShipments="{log>/kpis/totalShipments}"
 *     delayedCount="{log>/kpis/delayed}"
 *     onTimeRate="{log>/kpis/onTimeRate}"
 *     avgDelayDays="{log>/kpis/avgDelayDays}"
 *     shipments="{log>/filteredShipments}"
 *     rules="{rulesModel>/activeRules}"
 *     showChart="true"
 *     showTable="true"
 *     rowPress="onShipmentPress"/>
 * ─────────────────────────────────────────────────────────────────────────────
 */
sap.ui.define([
  "sap/ui/core/Control",
  "sap/m/VBox",
  "sap/m/HBox",
  "sap/m/Text",
  "sap/m/Title",
  "sap/m/ObjectStatus",
  "sap/m/ObjectNumber",
  "sap/m/Table",
  "sap/m/Column",
  "sap/m/ColumnListItem",
  "sap/m/Toolbar",
  "sap/m/ToolbarSpacer",
  "sap/m/SearchField",
  "sap/m/Button",
  "sap/m/SegmentedButton",
  "sap/m/SegmentedButtonItem",
  "sap/m/MessageStrip",
  "sap/m/ProgressIndicator",
  "sap/ui/core/Icon",
  "sap/f/Card",
  "sap/f/cards/Header"
], function (
  Control, VBox, HBox, Text, Title, ObjectStatus, ObjectNumber,
  Table, Column, ColumnListItem, Toolbar, ToolbarSpacer, SearchField,
  Button, SegmentedButton, SegmentedButtonItem, MessageStrip,
  ProgressIndicator, Icon, Card, CardHeader
) {
  "use strict";

  return Control.extend("com.logistics.delaylib.control.DelayMonitor", {

    metadata: {
      library: "com.logistics.delaylib",

      properties: {
        /** Panel title */
        title:           { type: "string",  defaultValue: "Delay Monitor" },
        /** Subtitle / data source description */
        subtitle:        { type: "string",  defaultValue: "Live logistics tracking" },
        /** Total shipment count (display string) */
        totalShipments:  { type: "string",  defaultValue: "—" },
        /** Number of delayed shipments */
        delayedCount:    { type: "string",  defaultValue: "—" },
        /** On-time rate as string, e.g. "87.4%" */
        onTimeRate:      { type: "string",  defaultValue: "—%" },
        /** Average delay in days */
        avgDelayDays:    { type: "string",  defaultValue: "—" },
        /** ValueState for on-time rate badge */
        onTimeRateState: { type: "string",  defaultValue: "None" },
        /** Show the shipments table */
        showTable:       { type: "boolean", defaultValue: true },
        /** Show KPI cards row */
        showKpis:        { type: "boolean", defaultValue: true },
        /** Show alert strip for critical delays */
        showAlerts:      { type: "boolean", defaultValue: true },
        /** Busy state */
        busy:            { type: "boolean", defaultValue: false }
      },

      aggregations: {
        /** Array of shipment objects — bound to the internal table */
        shipments: { type: "sap.ui.core.Element", multiple: true, singularName: "shipment" },
        /** Array of rule result objects to display as alert strips */
        ruleAlerts: { type: "sap.ui.core.Element", multiple: true, singularName: "ruleAlert" },
        /** Internal content aggregation */
        _content: { type: "sap.ui.core.Control", multiple: false, visibility: "hidden" }
      },

      events: {
        /** Fired when a shipment row is pressed */
        rowPress: {
          parameters: {
            orderId:   { type: "string" },
            reference: { type: "string" },
            carrier:   { type: "string" },
            delayDays: { type: "int" }
          }
        },
        /** Fired when the filter mode changes */
        filterChange: {
          parameters: { mode: { type: "string" } }
        },
        /** Fired when refresh button is pressed */
        refresh: {}
      }
    },

    // ── Lifecycle ─────────────────────────────────────────────────────────

    init: function () {
      Control.prototype.init.apply(this, arguments);
      this._buildContent();
    },

    onBeforeRendering: function () {
      this._syncProperties();
    },

    // ── Rendering ─────────────────────────────────────────────────────────

    renderer: {
      apiVersion: 2,
      render: function (oRm, oControl) {
        oRm.openStart("div", oControl);
        oRm.class("ldlDelayMonitor");
        if (oControl.getBusy()) { oRm.class("ldlBusy"); }
        oRm.openEnd();
        oRm.renderControl(oControl.getAggregation("_content"));
        oRm.close("div");
      }
    },

    // ── Internal build ───────────────────────────────────────────────────

    _buildContent: function () {
      var that = this;

      // KPI strip
      this._oKpiBox = new HBox({
        id: this.getId() + "--kpiBox",
        justifyContent: "SpaceBetween",
        items: [
          this._buildKpiTile("Total Shipments",  "totalShipments",  "None"),
          this._buildKpiTile("Delayed",          "delayedCount",    "Error"),
          this._buildKpiTile("On-Time Rate",     "onTimeRate",      "None", true),
          this._buildKpiTile("Avg Delay",        "avgDelayDays",    "Warning")
        ]
      }).addStyleClass("ldlKpiRow");

      // Alert strip
      this._oAlertStrip = new MessageStrip({
        id:              this.getId() + "--alertStrip",
        type:            "Error",
        showIcon:        true,
        showCloseButton: false,
        visible:         false
      }).addStyleClass("ldlAlertStrip");

      // Mode filter
      this._oModeFilter = new SegmentedButton({
        id: this.getId() + "--modeFilter",
        selectionChange: function (oEvent) {
          var sKey = oEvent.getParameter("item").getKey();
          that._applyFilter(sKey);
          that.fireFilterChange({ mode: sKey });
        },
        items: [
          new SegmentedButtonItem({ text: "All",     key: "ALL" }),
          new SegmentedButtonItem({ text: "Sea",     key: "SEA" }),
          new SegmentedButtonItem({ text: "Air",     key: "AIR" }),
          new SegmentedButtonItem({ text: "Delayed", key: "DELAYED" })
        ]
      });

      // Search
      this._oSearch = new SearchField({
        id:          this.getId() + "--search",
        placeholder: "Reference, carrier, port…",
        width:       "14rem",
        search:      function (oEvent) {
          that._applySearch(oEvent.getParameter("query"));
        }
      });

      // Export button
      this._oBtnExport = new Button({
        id:      this.getId() + "--btnExport",
        icon:    "sap-icon://excel-attachment",
        tooltip: "Export to Excel",
        press:   function () { that._exportData(); }
      });

      // Refresh button
      this._oBtnRefresh = new Button({
        id:      this.getId() + "--btnRefresh",
        icon:    "sap-icon://refresh",
        tooltip: "Refresh data",
        press:   function () { that.fireRefresh(); }
      });

      // Table toolbar
      var oToolbar = new Toolbar({
        id: this.getId() + "--tblToolbar",
        content: [
          new Title({ text: "Shipments", level: "H5" }),
          new ToolbarSpacer(),
          this._oModeFilter,
          this._oSearch,
          this._oBtnExport,
          this._oBtnRefresh
        ]
      });

      // Shipments table
      this._oTable = new Table({
        id:               this.getId() + "--table",
        alternateRowColors: true,
        sticky:           ["ColumnHeaders"],
        growing:          true,
        growingThreshold: 20,
        noDataText:       "No shipments found.",
        headerToolbar:    oToolbar,
        columns: [
          new Column({ header: new Text({ text: "Mode" }),      width: "4rem" }),
          new Column({ header: new Text({ text: "Reference" })                }),
          new Column({ header: new Text({ text: "Carrier" })                  }),
          new Column({ header: new Text({ text: "Route" })                    }),
          new Column({ header: new Text({ text: "ETA" }),       hAlign: "Center" }),
          new Column({ header: new Text({ text: "Delay" }),     hAlign: "Center" }),
          new Column({ header: new Text({ text: "Status" }),    hAlign: "Center" })
        ]
      });

      // Wire row press
      this._oTable.attachEvent("itemPress", function (oEvent) {
        var oCtx  = oEvent.getParameter("listItem").getBindingContext();
        if (!oCtx) { return; }
        var oData = oCtx.getObject();
        that.fireRowPress({
          orderId:   oData.orderId,
          reference: oData.reference,
          carrier:   oData.carrier,
          delayDays: oData.delayDays
        });
      });

      // Root VBox
      var oRoot = new VBox({
        id:    this.getId() + "--root",
        items: [
          this._oKpiBox,
          this._oAlertStrip,
          this._oTable
        ]
      }).addStyleClass("ldlMonitorRoot");

      this.setAggregation("_content", oRoot);
    },

    _buildKpiTile: function (sLabel, sProp, sState, bIsRate) {
      var oTile = new VBox({
        alignItems: "Center"
      }).addStyleClass("ldlKpiTile");

      var oLabel = new Text({ text: sLabel }).addStyleClass("ldlKpiLabel");
      var oValue = new Title({ level: "H3" }).addStyleClass(
        sState === "Error" ? "ldlKpiValueError" :
        sState === "Warning" ? "ldlKpiValueWarn" : "ldlKpiValue"
      );
      oValue.setId(this.getId() + "--kpi_" + sProp);
      oTile.addItem(oLabel);
      oTile.addItem(oValue);
      return oTile;
    },

    _syncProperties: function () {
      var setKpi = function (sId, sVal) {
        var oCtrl = sap.ui.getCore().byId(this.getId() + "--kpi_" + sId);
        if (oCtrl) { oCtrl.setText(sVal); }
      }.bind(this);

      setKpi("totalShipments", this.getTotalShipments());
      setKpi("delayedCount",   this.getDelayedCount());
      setKpi("onTimeRate",     this.getOnTimeRate());
      setKpi("avgDelayDays",   this.getAvgDelayDays());

      var oAlertStrip = sap.ui.getCore().byId(this.getId() + "--alertStrip");
      if (oAlertStrip) {
        var nDelayed = parseInt(this.getDelayedCount()) || 0;
        oAlertStrip.setVisible(this.getShowAlerts() && nDelayed > 0);
        if (nDelayed > 0) {
          oAlertStrip.setText(nDelayed + " shipments delayed — on-time rate: " + this.getOnTimeRate());
        }
      }
    },

    // ── Filter / search ──────────────────────────────────────────────────

    _applyFilter: function (sKey) {
      var oBinding = this._oTable && this._oTable.getBinding("items");
      if (!oBinding) { return; }
      var sap_Filter = sap.ui.model.Filter;
      var sap_FO     = sap.ui.model.FilterOperator;
      if (sKey === "ALL") {
        oBinding.filter([]);
      } else if (sKey === "DELAYED") {
        oBinding.filter([ new sap_Filter("isDelayed", sap_FO.EQ, true) ]);
      } else {
        oBinding.filter([ new sap_Filter("mode", sap_FO.EQ, sKey) ]);
      }
    },

    _applySearch: function (sQuery) {
      var oBinding = this._oTable && this._oTable.getBinding("items");
      if (!oBinding) { return; }
      var sap_Filter = sap.ui.model.Filter;
      var sap_FO     = sap.ui.model.FilterOperator;
      if (!sQuery) { oBinding.filter([]); return; }
      oBinding.filter([
        new sap_Filter({
          filters: [
            new sap_Filter("reference", sap_FO.Contains, sQuery),
            new sap_Filter("carrier",   sap_FO.Contains, sQuery),
            new sap_Filter("pol",       sap_FO.Contains, sQuery),
            new sap_Filter("pod",       sap_FO.Contains, sQuery)
          ],
          and: false
        })
      ]);
    },

    _exportData: function () {
      sap.m.MessageToast.show("Exporting delay data to Excel…");
    },

    // ── Public API ────────────────────────────────────────────────────────

    /**
     * Bind the internal table to a JSON model path.
     * Call this from your controller after data is loaded.
     * @param {string} sModelName  e.g. "log"
     * @param {string} sPath       e.g. "/filteredShipments"
     */
    bindShipmentData: function (sModelName, sPath) {
      var oModel    = this.getModel(sModelName);
      var oTable    = this._oTable;
      if (!oModel || !oTable) { return; }

      oTable.setModel(oModel, sModelName);
      oTable.bindItems({
        model:    sModelName,
        path:     sPath,
        template: this._buildRowTemplate()
      });
    },

    _buildRowTemplate: function () {
      var oItem = new ColumnListItem({ type: "Navigation" });
      oItem.addCell(new Icon({ src: "{log>modeIcon}", size: "1rem" }));
      oItem.addCell(new sap.m.ObjectIdentifier({
        title: "{log>reference}", text: "{log>orderId}"
      }));
      oItem.addCell(new Text({ text: "{log>carrier}" }));
      oItem.addCell(new Text({ text: "{log>pol} → {log>pod}" }));
      oItem.addCell(new Text({ text: "{log>eta}" }));
      oItem.addCell(new ObjectStatus({
        text:  "{= ${log>delayDays} > 0 ? '+' + ${log>delayDays} + 'd' : 'On time'}",
        state: "{log>delayState}"
      }));
      oItem.addCell(new ObjectStatus({
        text:  "{log>status}",
        state: "{log>statusState}"
      }));
      return oItem;
    }
  });
});
