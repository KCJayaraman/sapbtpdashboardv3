# Business Rules Authoring Guide

A practical guide for business analysts and developers to write, test, and
deploy logistics delay rules using the `RulesEngine` in the delay library.

---

## What Are Rules For?

Rules let you define business logic in configuration — not code.
A rule says: **"when a shipment meets these conditions, take these actions."**

No re-deployment needed. Rules can be:
- Added via the in-app **Rules Editor** UI
- Imported as JSON files from this repository
- Loaded from a backend store at runtime

---

## Rule Quick Reference

```json
{
  "id":             "RULE_ID",
  "name":           "Human-readable name",
  "description":    "What this rule detects and why",
  "active":         true,
  "severity":       "Warning",
  "priority":       20,
  "mode":           ["Sea", "Air"],
  "conditionLogic": "AND",
  "conditions":     [ { "field": "...", "operator": "...", "value": "..." } ],
  "actions":        [ { "type": "alert", "message": "...", "target": "..." } ],
  "tags":           ["sea", "overdue"]
}
```

---

## Step-by-Step: Writing Your First Rule

### Scenario
> "Alert the CEO when an air shipment from Dubai to New York is delayed by more than 1 day
> and the shipment is worth more than $100,000."

### Step 1 — Give the rule an ID and name

```json
{
  "id":   "DXB_JFK_001",
  "name": "Dubai–New York High-Value Air Delay"
}
```

IDs must be unique across all rules. Prefix by route, team, or area (e.g. `SEA_`, `AIR_`, `CUST_`, `FIN_`).

### Step 2 — Set severity and priority

```json
{
  "severity": "Error",
  "priority": 8
}
```

| Severity | When to use |
|---|---|
| `Info` | Advisory — good to know, no action required |
| `Warning` | Something to watch — review recommended |
| `Error` | Action required — SLA at risk |
| `Critical` | Immediate escalation — financial/reputational impact |

Lower priority number = evaluated first. Use `1–9` for critical rules that should
always run before others.

### Step 3 — Specify the mode

```json
{
  "mode": ["Air"]
}
```

Values: `"Sea"`, `"Air"`, `"Road"`, `"Rail"`, `"Multimodal"`, `"All"`.
Use `"All"` to apply regardless of transport mode.

### Step 4 — Write the conditions

```json
{
  "conditionLogic": "AND",
  "conditions": [
    { "field": "mode",      "operator": "eq",  "value": "Air"     },
    { "field": "pol",       "operator": "eq",  "value": "Dubai"   },
    { "field": "pod",       "operator": "contains", "value": "New York" },
    { "field": "delayDays", "operator": "gte", "value": 1         },
    { "field": "value",     "operator": "gt",  "value": 100000    }
  ]
}
```

`AND` means ALL conditions must be true. Change to `OR` if ANY condition should trigger the rule.

### Step 5 — Define the actions

```json
{
  "actions": [
    {
      "type":    "alert",
      "message": "Air shipment {reference} (DXB→JFK) worth ${value} is {delayDays}d delayed. Check {carrier}.",
      "target":  "CEO_DASHBOARD"
    },
    {
      "type":    "notify",
      "message": "High-value air delay alert for SO {soReference}",
      "target":  "SALES_TEAM"
    }
  ]
}
```

Use `{fieldName}` tokens in messages — they are replaced with real shipment values at runtime.

### Complete rule

```json
{
  "id":             "DXB_JFK_001",
  "name":           "Dubai–New York High-Value Air Delay",
  "description":    "Alerts CEO when high-value air shipment on DXB→JFK route is delayed",
  "active":         true,
  "severity":       "Error",
  "priority":       8,
  "mode":           ["Air"],
  "conditionLogic": "AND",
  "conditions": [
    { "field": "mode",      "operator": "eq",       "value": "Air"     },
    { "field": "pol",       "operator": "eq",       "value": "Dubai"   },
    { "field": "pod",       "operator": "contains", "value": "New York"},
    { "field": "delayDays", "operator": "gte",      "value": 1         },
    { "field": "value",     "operator": "gt",       "value": 100000    }
  ],
  "actions": [
    {
      "type":    "alert",
      "message": "Air shipment {reference} (DXB→JFK) worth ${value} is {delayDays}d delayed.",
      "target":  "CEO_DASHBOARD"
    }
  ],
  "tags": ["air", "dubai", "high-value", "new-york"]
}
```

---

## Condition Field Reference

| Field | Type | Example values |
|---|---|---|
| `delayDays` | number | `0`, `5`, `14` |
| `mode` | string | `"Sea"`, `"Air"`, `"Road"` |
| `carrier` | string | `"Maersk"`, `"Emirates"`, `"HAPAG-LLOYD"` |
| `pol` | string | `"Rotterdam"`, `"Hamburg"`, `"Dubai"` |
| `pod` | string | `"Shanghai"`, `"New York"`, `"Singapore"` |
| `status` | string | `"delayed"`, `"customs"`, `"on time"`, `"delivered"` |
| `value` | number | `50000`, `250000` |
| `isDelayed` | boolean | `true`, `false` |
| `soReference` | string | `"4500012345"`, `""` |
| `poReference` | string | `"4500099876"` |
| `incoterm` | string | `"EXW"`, `"DDP"`, `"FOB"`, `"CIF"` |
| `carrierDelayRate` | number | `0` to `100` (percentage) |
| `etaDayOfWeek` | string | `"Monday"` through `"Sunday"` |
| `customerRisk` | string | `"Low"`, `"Medium"`, `"High"` |

---

## Operator Reference

| Operator | Syntax | Example |
|---|---|---|
| `eq` | `field eq value` | `"mode" eq "Air"` |
| `neq` | `field neq value` | `"status" neq "delivered"` |
| `gt` | `field gt number` | `"delayDays" gt 5` |
| `gte` | `field gte number` | `"delayDays" gte 7` |
| `lt` | `field lt number` | `"value" lt 10000` |
| `lte` | `field lte number` | `"delayDays" lte 3` |
| `contains` | `field contains string` | `"status" contains "customs"` |
| `startsWith` | `field startsWith string` | `"carrier" startsWith "MAEU"` |
| `endsWith` | `field endsWith string` | `"reference" endsWith "789"` |
| `in` | `field in [array]` | `"carrier" in ["BASF","FOGR"]` |
| `notIn` | `field notIn [array]` | `"pol" notIn ["Hamburg"]` |
| `between` | `field between [min,max]` | `"delayDays" between [3,10]` |
| `regex` | `field regex pattern` | `"reference" regex "^MAEU"` |
| `isNull` | `field isNull` | `"soReference" isNull` — field is empty |
| `isNotNull` | `field isNotNull` | `"soReference" isNotNull` — field has value |
| `isTrue` | `field isTrue` | `"isDelayed" isTrue` |
| `isFalse` | `field isFalse` | `"isDelayed" isFalse` |

---

## Action Types

| Type | What it does | Where to set `target` |
|---|---|---|
| `alert` | Posts to the Alerts tab in the dashboard | `CEO_DASHBOARD` |
| `escalate` | Marks as requiring human escalation | `CPO`, `LOGISTICS_VP`, `CEO` |
| `flag` | Marks shipment for follow-up | `PROCUREMENT`, `SALES_TEAM` |
| `notify` | Sends notification to a team | `SALES_TEAM`, `LOGISTICS` |
| `block` | Flags as blocked (informational) | `APPROVER` |

You can register custom action handlers in the controller:
```javascript
oEngine.registerActionHandler("webhook", function(oAction, oShipment, oRule) {
  fetch("/my-webhook", {
    method: "POST",
    body: JSON.stringify({ action: oAction, shipment: oShipment })
  });
});
```

---

## Testing Rules

### In the Rules Editor UI

1. Open the **Rules** tab in the dashboard
2. Expand **Rule Test Sandbox** at the bottom of the page
3. Edit the test shipment JSON to match your scenario
4. Click **Run All Rules** to see which rules fire
5. Click the **play ▶** icon on any row to test a single rule

### In JavaScript (for developers)

```javascript
var oEngine = new RulesEngine({ rules: [myRule] });

var oResult = oEngine.evaluate({
  orderId:    "TEST-001",
  reference:  "MAEU123456789",
  carrier:    "Maersk",
  mode:       "Sea",
  pol:        "Rotterdam",
  pod:        "Shanghai",
  delayDays:  8,
  isDelayed:  true,
  value:      250000,
  status:     "delayed",
  soReference:"4500012345"
});

console.log("Rules fired:", oResult.rulesFired);
console.log("Matched:", oResult.matched.map(m => m.ruleName));
console.log("Actions:", oResult.actions.map(a => a.message));
```

### Dry run mode (no action handlers)

```javascript
var oEngine = new RulesEngine({ rules: myRules, dryRun: true });
var oResult = oEngine.evaluate(oShipment);
// Actions are listed in oResult but handlers are NOT called
```

---

## Sharing Rules Across the Team

Rules are portable JSON. Store them in this repository under
`docs/rules/` so the team can review, version-control, and share them.

### Export rules from the UI

1. Open **Rules** tab → click the **↓ Export** button
2. A `logistics-delay-rules-YYYY-MM-DD.json` file downloads
3. Add it to `docs/rules/` and commit

### Import team rules

1. Copy the JSON file content
2. Open **Rules** tab → click the **↑ Import** button
3. Paste the JSON → **Import**

The import merges with existing rules (same ID = update, new ID = add).

### Rule versioning

Name your files descriptively:
```
docs/rules/
├── default-rules-v1.json           # shipped with the library
├── emea-procurement-rules.json     # EMEA team rules
├── high-value-cargo-rules.json     # finance team rules
└── seasonal-weather-rules.json     # activated during storm season
```

Commit rule changes with a message like:
```
feat(rules): add DXB-JFK high-value air delay rule (DXB_JFK_001)
```

---

## Troubleshooting Rules

**Rule never fires:**
- Check `active: true`
- Check `conditionLogic` — if `AND`, all conditions must match
- Use **Test Rule** button with a shipment that should match
- Check operator — `contains` is case-insensitive; `eq` is loose equality (`==`)

**Rule fires too often:**
- Add more conditions to narrow the match
- Lower the priority number so it runs after more specific rules
- Set `stopOnFirst: true` in the engine to stop after first match

**Message token shows `{reference}` literally:**
- The field name must exactly match the shipment context key
- Check spelling: `reference` not `shipmentRef`

**`between` not working:**
- Value must be an array: `"value": [3, 10]` not `"value": "3,10"`
