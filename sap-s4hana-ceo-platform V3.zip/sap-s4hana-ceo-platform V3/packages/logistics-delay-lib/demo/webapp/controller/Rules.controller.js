sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/MessageToast",
  "sap/m/MessageBox"
], function (Controller, MessageToast, MessageBox) {
  "use strict";

  return Controller.extend("com.logistics.delaylib.demo.controller.Rules", {

    onInit: function () {
      this.getOwnerComponent().getRouter()
        .getRoute("rules")
        .attachPatternMatched(this._onRouteMatched, this);
    },

    _onRouteMatched: function () {
      var oEditor = this.byId("rulesEditor");
      var oEngine = this.getOwnerComponent().getRulesEngine();

      if (oEditor && oEngine) {
        // Load default rules into the editor from the engine
        oEditor.loadFromEngine(oEngine);
      }
    },

    onRuleSaved: function (oEvent) {
      var oRule = oEvent.getParameter("rule");
      MessageToast.show("Rule '" + oRule.name + "' saved to engine.");

      // In production: persist to SAP HANA Cloud or Object Store
      // this._persistRulesToBackend(oRule);
    },

    onRuleDeleted: function (oEvent) {
      var sId = oEvent.getParameter("ruleId");
      MessageToast.show("Rule " + sId + " deleted from engine.");
    },

    onRuleTested: function (oEvent) {
      var oResult = oEvent.getParameter("result");
      if (oResult && oResult.rulesFired > 0) {
        MessageToast.show(oResult.rulesFired + " rule(s) fired against test shipment.");
      } else {
        MessageToast.show("No rules matched the test shipment.");
      }
    },

    onRulesImported: function (oEvent) {
      var aRules = oEvent.getParameter("rules");
      MessageToast.show(aRules.length + " rules imported successfully.");
    }
  });
});
