# com.logistics.delaylib — Integration Guide
## Using the Library Inside the SAP Control Tower

This guide shows how to wire `com.logistics.delaylib` into the existing
`sap-control-tower` application (from the previous sessions).

---

## Step 1 — Install the Library on BTP

Deploy the library as a separate BTP package first:

```bash
# From the logistics-delay-library directory
npm install
mbt build
cf deploy mta_archives/com-logistics-delaylib_1.0.0.mtar
```

After deployment the library is served from the HTML5 App Repository
at path: `com/logistics/delaylib/`.

---

## Step 2 — Add Library Dependency in Control Tower manifest.json

```json
"sap.ui5": {
  "dependencies": {
    "libs": {
      "sap.ui.core":            {},
      "sap.m":                  {},
      "com.logistics.delaylib": {}
    }
  }
}
```

---

## Step 3 — Update the Logistics View

Replace the plain sap.m tables in `Logistics.view.xml` with the library control:

```xml
<mvc:View
  xmlns:delaylib="com.logistics.delaylib"
  ...>

  <!-- Replace the existing delay table with the library control -->
  <delaylib:DelayMonitor
    id="libraryMonitor"
    title="Logistics Delay Monitor"
    subtitle="TrackCargo API · Live"
    totalShipments="{log>/kpis/totalShipments}"
    delayedCount="{log>/kpis/delayed}"
    onTimeRate="{log>/kpis/onTimeRate}"
    avgDelayDays="{log>/kpis/avgDelayDays}"
    showKpis="true"
    showTable="true"
    showAlerts="true"
    rowPress="onShipmentPress"
    refresh="onRefresh"/>

  <!-- Rules Editor panel -->
  <delaylib:RulesEditor
    id="libraryRulesEditor"
    title="Delay Business Rules"
    editable="true"
    showTestPanel="true"
    ruleSave="onRuleSaved"
    ruleTest="onRuleTested"/>

  <!-- Simulation panel -->
  <delaylib:DelaySimulator
    id="librarySimulator"
    title="Delay Scenario Simulation"
    iterations="1000"
    simulationComplete="onSimulationComplete"/>

</mvc:View>
```

---

## Step 4 — Update Logistics.controller.js

```javascript
sap.ui.define([
  "./BaseController",
  "com/logistics/delaylib/rules/RulesEngine",
  "com/logistics/delaylib/simulation/DelaySimulationEngine"
], function (BaseController, RulesEngine, DelaySimulationEngine) {
  "use strict";

  return BaseController.extend("...", {

    onInit: function () {
      BaseController.prototype.onInit.apply(this, arguments);

      // Instantiate RulesEngine with default rules
      this._oRulesEngine = new RulesEngine({ stopOnFirst: false });
      this._oRulesEngine.loadRules(this._oRulesEngine.getDefaultRules());

      // Register action handler to push rule matches into the UI model
      this._oRulesEngine.registerActionHandler("alert", function (oAction) {
        var oUI    = this.getUIModel();
        var aAlerts = oUI.getProperty("/alerts") || [];
        aAlerts.push({
          id:            "RULE_" + Date.now(),
          priority:      oAction.severity,
          priorityState: oAction.severity === "Critical" || oAction.severity === "Error"
                           ? "Error" : "Warning",
          icon:          "sap-icon://alert",
          module:        "DelayLib Rules",
          title:         oAction.message,
          description:   "Rule: " + oAction.ruleId,
          category:      "Logistics",
          time:          new Date().toLocaleTimeString()
        });
        oUI.setProperty("/alerts", aAlerts);
        oUI.setProperty("/kpis/alertCount", aAlerts.length);
      }.bind(this));

      // Instantiate Simulation Engine
      this._oSimEngine = new DelaySimulationEngine({
        iterations:      1000,
        demurrageDayRate:500,
        expediteCostRate:0.03
      });

      this.getOwnerComponent().getRouter()
        .getRoute("logistics")
        .attachPatternMatched(this._loadData, this);
    },

    _loadData: function () {
      // ... existing TrackCargo API calls ...

      // After data loads, wire controls to library
      this._wireLibraryControls();
    },

    _wireLibraryControls: function () {
      // Wire DelayMonitor
      var oMonitor = this.byId("libraryMonitor");
      if (oMonitor) {
        oMonitor.setModel(this.getModel("ui"), "log");
        oMonitor.bindShipmentData("log", "/filteredShipments");
      }

      // Wire RulesEditor
      var oEditor = this.byId("libraryRulesEditor");
      if (oEditor) {
        oEditor.loadFromEngine(this._oRulesEngine);
      }

      // Wire Simulator
      var oSim = this.byId("librarySimulator");
      if (oSim) {
        oSim._oEngine = this._oSimEngine;
      }

      // Evaluate rules against live shipment data
      var aShipments = this.getUIModel().getProperty("/allShipments") || [];
      if (aShipments.length > 0) {
        this._oRulesEngine.evaluateBatch(aShipments);
      }
    },

    // Handle events from RulesEditor
    onRuleSaved: function (oEvent) {
      var oRule = oEvent.getParameter("rule");
      // Persist to HANA Cloud / Object Store
      sap.m.MessageToast.show("Rule '" + oRule.name + "' saved.");
    },

    onRuleTested: function (oEvent) {
      var oResult = oEvent.getParameter("result");
      sap.m.MessageToast.show(oResult.rulesFired + " rule(s) matched.");
    },

    // Handle events from DelaySimulator
    onSimulationComplete: function (oEvent) {
      var sScenario = oEvent.getParameter("scenario");
      var oResult   = oEvent.getParameter("result");
      sap.m.MessageToast.show(
        sScenario + ": P50=" + oResult.delays.p50 + "d, P90=" + oResult.delays.p90 + "d"
      );
    }
  });
});
```

---

## Persisting Rules to SAP BTP Object Store

For CEO-configured rules to survive deployments, persist them to the BTP
Object Store service:

```javascript
// Save rules
_persistRules: function () {
  var sJson = this._oRulesEngine.exportRules();
  fetch("/objectstore/delay-rules.json", {
    method:  "PUT",
    headers: { "Content-Type": "application/json" },
    body:    sJson
  });
},

// Load rules on startup
_loadRulesFromStore: function () {
  fetch("/objectstore/delay-rules.json")
    .then(function (r) { return r.json(); })
    .then(function (aRules) {
      this._oRulesEngine.loadRules(aRules);
      var oEditor = this.byId("libraryRulesEditor");
      if (oEditor) { oEditor.loadFromEngine(this._oRulesEngine); }
    }.bind(this));
}
```

---

## API Summary

### RulesEngine

```javascript
var oEngine = new RulesEngine({ rules: [], stopOnFirst: false, dryRun: false });

oEngine.addRule(oRule);                   // Add/replace a rule
oEngine.removeRule("RULE_001");           // Delete by ID
oEngine.setRuleActive("RULE_001", false); // Toggle without deleting
oEngine.loadRules(aRules);               // Replace entire ruleset
oEngine.getDefaultRules();               // Returns 10 built-in rules
oEngine.evaluate(oShipment);             // Single shipment → { matched, actions }
oEngine.evaluateBatch(aShipments);       // Array → { results, criticalCount }
oEngine.exportRules();                   // → JSON string (for persistence)
oEngine.importRules(sJson);              // Load from JSON string
oEngine.registerActionHandler("alert", fn); // Custom action handler
oEngine.getAuditLog();                   // All rule match history
```

### DelaySimulationEngine

```javascript
var oSim = new DelaySimulationEngine({ iterations: 1000, demurrageDayRate: 500 });

oSim.simulate(oShipment, "PortCongestion");          // Single simulation
oSim.compareScenarios(oShipment, ["Baseline","Strike"]); // Side-by-side
oSim.simulateBatch(aShipments, "WeatherDisruption"); // Portfolio simulation
oSim.registerScenario("MyScenario", oParams);        // Custom scenario
oSim.getScenarioNames();                             // Available scenarios
```

### RulesEditor Control Events

| Event | Parameters | When fired |
|---|---|---|
| `ruleSave` | `{ rule }` | After save button in edit dialog |
| `ruleDelete` | `{ ruleId }` | After delete confirmed |
| `ruleTest` | `{ rule, result }` | After test run |
| `rulesImport` | `{ rules }` | After JSON import |

### DelayMonitor Control Events

| Event | Parameters | When fired |
|---|---|---|
| `rowPress` | `{ orderId, reference, carrier, delayDays }` | Row clicked in table |
| `filterChange` | `{ mode }` | Mode filter changed |
| `refresh` | — | Refresh button pressed |

### DelaySimulator Control Events

| Event | Parameters | When fired |
|---|---|---|
| `simulationComplete` | `{ scenario, result }` | After run/compare completes |
