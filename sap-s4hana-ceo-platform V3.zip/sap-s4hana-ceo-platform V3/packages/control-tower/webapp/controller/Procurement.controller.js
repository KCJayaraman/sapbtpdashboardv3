sap.ui.define([
  "./BaseController",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/Sorter",
  "sap/ui/export/library"
], function (BaseController, Filter, FilterOperator, Sorter, exportLibrary) {
  "use strict";

  var EdmType = exportLibrary.EdmType;

  return BaseController.extend("com.company.controltower.controller.Procurement", {

    onInit: function () {
      BaseController.prototype.onInit.apply(this, arguments);
      this.getOwnerComponent().getRouter()
        .getRoute("procurement")
        .attachPatternMatched(this._loadData, this);
    },

    // ── Main loader ───────────────────────────────────────────────
    _loadData: function () {
      this.setBusy(true, "Procurement");
      var oSvc = this._oService;
      var oUI  = this.getUIModel();
      var sYear = new Date().getFullYear().toString();

      // 1. PO KPIs
      var pKPIs = oSvc.getPOKPIs(sYear).then(function (aR) {
        oUI.setProperty("/kpis/openPOs",
          parseInt(aR[0].__count || 0).toLocaleString());
        oUI.setProperty("/kpis/overduePOs",
          parseInt(aR[1].__count || 0).toLocaleString());
        oUI.setProperty("/kpis/blockedInvoices",
          parseInt(aR[2].__count || 0).toLocaleString());
      });

      // 2. Total PO Spend + 3-way match rate
      var pSpend = oSvc.getPurchaseOrders({ fiscalYear: sYear, top: "1000" })
        .then(function (oData) {
          var fTotal = 0, nMatched = 0, nTotal = oData.results.length;
          var oStatus = { open: 0, grPending: 0, invoiced: 0, blocked: 0, closed: 0 };

          oData.results.forEach(function (oPO) {
            fTotal += parseFloat(oPO.NetPurchaseOrderAmount) || 0;

            // 3-way match: PO created, GR posted, Invoice posted
            if (oPO.GoodsReceiptIsExpected &&
                oPO.InvoiceIsExpected &&
                oPO.PurchaseOrderStatus === "C") {
              nMatched++;
            }

            switch (oPO.PurchaseOrderStatus) {
              case "":  oStatus.open++;     break;
              case "A": oStatus.invoiced++; break;
              case "B": oStatus.blocked++;  break;
              case "C": oStatus.closed++;   break;
            }
            if (oPO.GoodsReceiptIsExpected && oPO.PurchaseOrderStatus !== "C") {
              oStatus.grPending++;
            }
          });

          oUI.setProperty("/kpis/totalPOValue",
            oSvc.formatAmount(fTotal, "USD"));
          oUI.setProperty("/kpis/threeWayMatch",
            (nTotal ? Math.round((nMatched / nTotal) * 100) : 0) + "%");
          oUI.setProperty("/poStatusCounts", oStatus);
        });

      // 3. Spend by material group (PO items)
      var pItems = oSvc.getPurchaseOrderItems({ top: "2000" })
        .then(function (oData) {
          var aByGroup = oSvc.aggregateByKey(
            oData.results, "MaterialGroup", "MaterialGroup", "NetPriceAmount"
          ).slice(0, 8);

          var fGrandTotal = aByGroup.reduce(function (s, o) { return s + o.total; }, 0);
          var aRows = aByGroup.map(function (o) {
            return {
              group:   o.label || "Unclassified",
              total:   oSvc.formatAmount(o.total, "EUR"),
              percent: Math.round((o.total / fGrandTotal) * 100),
              count:   o.count
            };
          });
          oUI.setProperty("/spendByCategory", aRows);
        });

      // 4. Bind PO table directly (OData list binding to procurement model)
      this._bindPOTable();

      // 5. Bind PR table
      this._bindPRTable();

      Promise.all([pKPIs, pSpend, pItems])
        .then(function () {
          this.setBusy(false, "Procurement");
          oUI.setProperty("/lastRefresh",
            new Date().toLocaleTimeString());
        }.bind(this))
        .catch(function (oErr) {
          this.setBusy(false, "Procurement");
          this._handleError(oErr, "Procurement load");
        }.bind(this));
    },

    // ── Bind PO table directly to OData ──────────────────────────
    _bindPOTable: function () {
      var oTable = this.byId("poTable");
      if (!oTable) { return; }

      var oToday = new Date();
      var aFilters = [
        new Filter("PurchaseOrderStatus", FilterOperator.NE, "C")
      ];

      oTable.bindItems({
        model:   "procurement",
        path:    "/PurchaseOrders",
        filters: aFilters,
        sorter:  new Sorter("NetPurchaseOrderAmount", true),
        parameters: {
          select: [
            "PurchaseOrder",
            "Supplier",
            "SupplierName",
            "NetPurchaseOrderAmount",
            "DocumentCurrency",
            "PurchasingDocumentDate",
            "PurchaseOrderStatus",
            "CompanyCode"
          ].join(","),
          top: "100"
        },
        template: oTable.getBindingInfo("items")
          ? oTable.getBindingInfo("items").template
          : this._getPOTemplate()
      });
    },

    // ── Build PO row template programmatically ────────────────────
    _getPOTemplate: function () {
      var ColumnListItem = sap.m.ColumnListItem;
      var ObjectIdentifier = sap.m.ObjectIdentifier;
      var ObjectStatus     = sap.m.ObjectStatus;
      var ObjectNumber     = sap.m.ObjectNumber;
      var Text             = sap.m.Text;

      var oItem = new ColumnListItem({ type: "Navigation" });
      oItem.attachPress(this.onPOPress, this);
      oItem.addCell(new ObjectIdentifier({
        title: "{procurement>PurchaseOrder}",
        text:  "{procurement>CompanyCode}"
      }));
      oItem.addCell(new Text({ text: "{procurement>SupplierName}" }));
      oItem.addCell(new Text({ text: "{procurement>Supplier}" }));
      oItem.addCell(new ObjectNumber({
        number: "{procurement>NetPurchaseOrderAmount}",
        unit:   "{procurement>DocumentCurrency}",
        state:  "{parts: [{path:'procurement>PurchaseOrderStatus'}], formatter: '.poStatusState'}"
      }));
      oItem.addCell(new Text({ text: "{procurement>PurchasingDocumentDate}" }));
      oItem.addCell(new ObjectStatus({
        text:  "{parts:[{path:'procurement>PurchaseOrderStatus'}],formatter:'.poStatusText'}",
        state: "{parts:[{path:'procurement>PurchaseOrderStatus'}],formatter:'.poStatusState'}"
      }));
      return oItem;
    },

    // ── Bind PR table ─────────────────────────────────────────────
    _bindPRTable: function () {
      var oTable = this.byId("prTable");
      if (!oTable) { return; }
      oTable.bindItems({
        model:      "procurement",
        path:       "/PurchaseRequisitions",
        parameters: {
          select: [
            "PurchaseRequisition",
            "PurchaseRequisitionStatus",
            "Material",
            "MaterialGroup",
            "TotalNetAmount",
            "DocumentCurrency",
            "CreationDate"
          ].join(","),
          top: "50",
          sorter: [{ path: "CreationDate", descending: true }]
        }
      });
    },

    // ── Table search ──────────────────────────────────────────────
    onPOSearch: function (oEvent) {
      var sQuery   = oEvent.getParameter("query");
      var oTable   = this.byId("poTable");
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }
      if (!sQuery) {
        oBinding.filter([
          new Filter("PurchaseOrderStatus", FilterOperator.NE, "C")
        ]);
        return;
      }
      oBinding.filter([
        new Filter({
          filters: [
            new Filter("PurchaseOrder",   FilterOperator.Contains, sQuery),
            new Filter("SupplierName",    FilterOperator.Contains, sQuery),
            new Filter("Supplier",        FilterOperator.Contains, sQuery)
          ],
          and: false
        })
      ]);
    },

    // ── Overdue filter toggle ─────────────────────────────────────
    onOverdueFilter: function (oEvent) {
      var bPressed = oEvent.getSource().getPressed();
      var oTable   = this.byId("poTable");
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }

      var aFilters = [new Filter("PurchaseOrderStatus", FilterOperator.NE, "C")];
      if (bPressed) {
        aFilters.push(new Filter("ScheduleLineDeliveryDate",
          FilterOperator.LT, new Date()));
      }
      oBinding.filter(aFilters);
    },

    // ── Status filter segmented button ────────────────────────────
    onStatusFilter: function (oEvent) {
      var sKey   = oEvent.getParameter("item").getKey();
      var oTable = this.byId("poTable");
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }

      var aFilters = [];
      if (sKey !== "ALL") {
        aFilters.push(new Filter("PurchaseOrderStatus", FilterOperator.EQ, sKey));
      } else {
        aFilters.push(new Filter("PurchaseOrderStatus", FilterOperator.NE, "C"));
      }
      oBinding.filter(aFilters);
    },

    // ── Excel export (live data from OData) ───────────────────────
    onExportPO: function () {
      var oTable   = this.byId("poTable");
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }

      // Pull current bound contexts
      var aData = oBinding.getCurrentContexts().map(function (oCtx) {
        return oCtx.getObject();
      });

      this._exportToExcel(aData, [
        { label: "PO Number",  property: "PurchaseOrder",           type: EdmType.String },
        { label: "Supplier",   property: "SupplierName",            type: EdmType.String },
        { label: "Supplier ID",property: "Supplier",                type: EdmType.String },
        { label: "Net Amount", property: "NetPurchaseOrderAmount",  type: EdmType.Number },
        { label: "Currency",   property: "DocumentCurrency",        type: EdmType.String },
        { label: "PO Date",    property: "PurchasingDocumentDate",  type: EdmType.Date   },
        { label: "Status",     property: "PurchaseOrderStatus",     type: EdmType.String },
        { label: "Company",    property: "CompanyCode",             type: EdmType.String }
      ], "PurchaseOrders_S4HANA");
    }
  });
});
