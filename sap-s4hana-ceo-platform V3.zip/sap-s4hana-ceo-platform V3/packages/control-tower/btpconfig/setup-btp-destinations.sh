#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# setup-btp-destinations.sh
# Configures BOTH BTP Destinations required by the SAP Control Tower:
#   1. S4HANA_BACKEND  → SAP S/4HANA OData APIs
#   2. TRACKCARGO_API  → TrackCargo REST API (trackcargo.co)
#   3. UI5_CDN         → ui5.sap.com CDN
#
# Prerequisites:
#   cf login -a https://api.cf.us10-001.hana.ondemand.com
#   cf install-plugin multiapps
#   btp login (SAP BTP CLI)
#
# Usage:
#   chmod +x setup-btp-destinations.sh
#   ./setup-btp-destinations.sh
# ─────────────────────────────────────────────────────────────────────────────

set -e

echo "========================================================="
echo "  SAP Control Tower — BTP Destination Setup"
echo "========================================================="

# ── Configuration — EDIT THESE VALUES ─────────────────────────────────────────
S4HANA_HOST="https://YOUR-S4HANA-HOST.sap.com"
S4HANA_CLIENT="100"
S4HANA_USER="YOUR_RFC_USER"
S4HANA_PASSWORD="YOUR_PASSWORD"

TRACKCARGO_API_KEY="YOUR_TRACKCARGO_API_KEY"
# Get yours at: https://trackcargo.co/signup → Developer → API Keys

SUBACCOUNT_GUID="YOUR_BTP_SUBACCOUNT_GUID"
# Find in BTP Cockpit → Account → Subaccount → Overview → Subaccount ID
# ──────────────────────────────────────────────────────────────────────────────

echo ""
echo "── Creating Destination: S4HANA_BACKEND ─────────────────"
cat > /tmp/s4hana_destination.json << EOF
{
  "Name": "S4HANA_BACKEND",
  "Type": "HTTP",
  "URL": "${S4HANA_HOST}",
  "Authentication": "BasicAuthentication",
  "User": "${S4HANA_USER}",
  "Password": "${S4HANA_PASSWORD}",
  "ProxyType": "Internet",
  "HTML5.DynamicDestination": "true",
  "WebIDEEnabled": "true",
  "WebIDEUsage": "odata_abap",
  "sap-client": "${S4HANA_CLIENT}",
  "sap-platform": "ABAP",
  "TrustAll": "false"
}
EOF

# Use BTP CLI to create destination
btp create services/destination \
  --subaccount "${SUBACCOUNT_GUID}" \
  --name S4HANA_BACKEND \
  --from-file /tmp/s4hana_destination.json 2>/dev/null || \
btp update services/destination \
  --subaccount "${SUBACCOUNT_GUID}" \
  --name S4HANA_BACKEND \
  --from-file /tmp/s4hana_destination.json

echo "  ✓ S4HANA_BACKEND destination configured"

echo ""
echo "── Creating Destination: TRACKCARGO_API ─────────────────"
cat > /tmp/trackcargo_destination.json << EOF
{
  "Name": "TRACKCARGO_API",
  "Type": "HTTP",
  "URL": "https://trackcargo.co",
  "Authentication": "NoAuthentication",
  "ProxyType": "Internet",
  "HTML5.DynamicDestination": "true",
  "HTML5.ForwardAuthToken": "false",
  "TrustAll": "false",
  "AdditionalHeaders.Authorization": "Bearer ${TRACKCARGO_API_KEY}",
  "AdditionalHeaders.Content-Type": "application/json",
  "AdditionalHeaders.Accept": "application/json"
}
EOF

btp create services/destination \
  --subaccount "${SUBACCOUNT_GUID}" \
  --name TRACKCARGO_API \
  --from-file /tmp/trackcargo_destination.json 2>/dev/null || \
btp update services/destination \
  --subaccount "${SUBACCOUNT_GUID}" \
  --name TRACKCARGO_API \
  --from-file /tmp/trackcargo_destination.json

echo "  ✓ TRACKCARGO_API destination configured"

echo ""
echo "── Creating Destination: UI5_CDN ───────────────────────"
cat > /tmp/ui5cdn_destination.json << EOF
{
  "Name": "UI5_CDN",
  "Type": "HTTP",
  "URL": "https://ui5.sap.com",
  "Authentication": "NoAuthentication",
  "ProxyType": "Internet",
  "HTML5.DynamicDestination": "true"
}
EOF

btp create services/destination \
  --subaccount "${SUBACCOUNT_GUID}" \
  --name UI5_CDN \
  --from-file /tmp/ui5cdn_destination.json 2>/dev/null || true

echo "  ✓ UI5_CDN destination configured"

echo ""
echo "── Verifying Destinations ───────────────────────────────"
btp list services/destination --subaccount "${SUBACCOUNT_GUID}" | grep -E "S4HANA_BACKEND|TRACKCARGO_API|UI5_CDN"

echo ""
echo "========================================================="
echo "  Setup complete!"
echo ""
echo "  Next steps:"
echo "  1. Verify destinations in BTP Cockpit → Connectivity → Destinations"
echo "  2. Test TrackCargo connectivity using 'Check Connection' button"
echo "  3. Replace YOUR_TRACKCARGO_API_KEY with real key from trackcargo.co/signup"
echo "  4. Deploy: mbt build && cf deploy mta_archives/*.mtar"
echo "========================================================="

# Cleanup
rm -f /tmp/s4hana_destination.json /tmp/trackcargo_destination.json /tmp/ui5cdn_destination.json
