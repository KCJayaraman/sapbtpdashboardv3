sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/MessageToast"
], function (Controller, MessageToast) {
  "use strict";

  return Controller.extend("com.logistics.delaylib.demo.controller.App", {

    onInit: function () {
      var oRouter = this.getOwnerComponent().getRouter();
      oRouter.attachRouteMatched(this._onRouteMatched, this);
    },

    _onRouteMatched: function (oEvent) {
      var sRoute   = oEvent.getParameter("name");
      var oSideNav = this.byId("sideNav");
      if (!oSideNav) { return; }
      var oMatch = oSideNav.getItems().find(function (i) {
        return i.getKey() === sRoute;
      });
      if (oMatch) { oSideNav.setSelectedItem(oMatch); }
    },

    onNavSelect: function (oEvent) {
      var sKey = oEvent.getParameter("item").getKey();
      this.getOwnerComponent().getRouter().navTo(sKey);
    }
  });
});
