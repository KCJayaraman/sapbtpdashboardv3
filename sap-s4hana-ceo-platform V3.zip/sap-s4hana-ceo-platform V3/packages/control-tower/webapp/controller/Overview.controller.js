sap.ui.define([
  "./BaseController",
  "sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
  "use strict";

  return BaseController.extend("com.company.controltower.controller.Overview", {

    onInit: function () {
      BaseController.prototype.onInit.apply(this, arguments);
      this.getOwnerComponent().getRouter()
        .getRoute("overview")
        .attachPatternMatched(this._loadData, this);
    },

    // ── Main data loader ─────────────────────────────────────────
    _loadData: function () {
      this.setBusy(true);
      var oUI = this.getUIModel();
      var sYear = new Date().getFullYear().toString();
      var oSvc  = this._oService;

      // ── 1. PO KPIs  (MM_PUR_PO_MAINT_V2_SRV) ──────────────────
      var pPOKPIs = oSvc.getPOKPIs(sYear)
        .then(function (aResults) {
          var oOpen    = aResults[0]; // all non-closed POs
          var oOverdue = aResults[1]; // overdue items
          var oBlocked = aResults[2]; // blocked POs

          oUI.setProperty("/kpis/openPOs",
            parseInt(oOpen.__count    || 0).toLocaleString());
          oUI.setProperty("/kpis/overduePOs",
            parseInt(oOverdue.__count || 0).toLocaleString());
          oUI.setProperty("/kpis/blockedInvoices",
            parseInt(oBlocked.__count || 0).toLocaleString());
        });

      // ── 2. PO Spend total (sum NetPurchaseOrderAmount) ──────────
      var pPOSpend = oSvc.getPurchaseOrders({ fiscalYear: sYear, top: "1000" })
        .then(function (oData) {
          var fTotal = 0;
          var fBlocked = 0;
          var nGRPending = 0;

          oData.results.forEach(function (oPO) {
            var fAmt = parseFloat(oPO.NetPurchaseOrderAmount) || 0;
            fTotal += fAmt;
            if (oPO.PurchaseOrderStatus === "B") { fBlocked += fAmt; }
            if (oPO.GoodsReceiptIsExpected && !oPO.GoodsReceiptIsNonValuated &&
                oPO.PurchaseOrderStatus !== "C") {
              nGRPending++;
            }
          });

          oUI.setProperty("/kpis/totalPOValue",
            oSvc.formatAmount(fTotal, "USD"));
          oUI.setProperty("/kpis/blockedPOValue",
            oSvc.formatAmount(fBlocked, "USD"));

          // Status breakdown for pipeline chart
          var oStatusMap = { open: 0, grPending: nGRPending, invoiced: 0, blocked: 0, closed: 0 };
          oData.results.forEach(function (oPO) {
            switch (oPO.PurchaseOrderStatus) {
              case "":  oStatusMap.open++;     break;
              case "A": oStatusMap.invoiced++; break;
              case "B": oStatusMap.blocked++;  break;
              case "C": oStatusMap.closed++;   break;
            }
          });
          oUI.setProperty("/poStatusCounts", oStatusMap);

          // Build spend by material group (aggregate PO items)
          return oSvc.getPurchaseOrderItems({ top: "2000" });
        })
        .then(function (oItemData) {
          var oSvc2 = this._oService;
          var aByGroup = oSvc2.aggregateByKey(
            oItemData.results,
            "MaterialGroup",
            "MaterialGroup",
            "NetPriceAmount"
          ).slice(0, 6);
          var fGroupTotal = aByGroup.reduce(function (s, o) { return s + o.total; }, 0);
          var aForChart = aByGroup.map(function (o) {
            return {
              category: o.label || "Other",
              total:    oSvc2.formatAmount(o.total, "EUR"),
              percent:  Math.round((o.total / fGroupTotal) * 100)
            };
          });
          oUI.setProperty("/spendByCategory", aForChart);
        }.bind(this));

      // ── 3. Sales KPIs  (SD_F1493_SALESORDER_MANAGE_SRV) ────────
      var oMonthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
      var pSalesKPIs = oSvc.getSalesKPIs(oMonthStart, new Date())
        .then(function (aResults) {
          oUI.setProperty("/kpis/openOrders",
            parseInt(aResults[0].__count || 0).toLocaleString());
        });

      // ── 4. Revenue from billing docs ─────────────────────────────
      var pRevenue = oSvc.getBillingDocuments({
        dateFrom: oMonthStart,
        dateTo:   new Date(),
        type:     "F2",
        top:      "1000"
      }).then(function (oData) {
        var fRev = 0;
        var fAvg = 0;
        oData.results.forEach(function (oDoc) {
          fRev += parseFloat(oDoc.TotalNetAmount) || 0;
        });
        fAvg = oData.results.length ? fRev / oData.results.length : 0;
        oUI.setProperty("/kpis/totalRevenue",
          oSvc.formatAmount(fRev, "USD"));
        oUI.setProperty("/kpis/avgOrderValue",
          oSvc.formatAmount(fAvg, "USD"));

        // Revenue by month (last 6 months) — group by BillingDocumentDate month
        return oSvc.getBillingDocuments({
          dateFrom: new Date(new Date().getFullYear(), new Date().getMonth() - 5, 1),
          dateTo:   new Date(),
          type:     "F2",
          top:      "5000"
        });
      }).then(function (oHistData) {
        var oMonthMap = {};
        oHistData.results.forEach(function (oDoc) {
          var sMonth = oDoc.BillingDocumentDate
            ? new Date(oDoc.BillingDocumentDate).toLocaleString("en", { month: "short" })
            : "?";
          if (!oMonthMap[sMonth]) { oMonthMap[sMonth] = 0; }
          oMonthMap[sMonth] += parseFloat(oDoc.TotalNetAmount) || 0;
        });
        var aMonths = Object.keys(oMonthMap).map(function (sM) {
          return { month: sM, revenue: Math.round(oMonthMap[sM] / 1e6 * 100) / 100 };
        });
        oUI.setProperty("/revenueByMonth", aMonths);
      });

      // ── 5. Supplier count  (API_BUSINESS_PARTNER) ───────────────
      var pSuppliers = oSvc.getSuppliers({ top: "1" })
        .then(function (oData) {
          // __count from $inlinecount if available; fall back to results array
          var n = oData.__count
            ? parseInt(oData.__count)
            : (oData.results ? oData.results.length : 0);
          oUI.setProperty("/kpis/activeSuppliers", n.toLocaleString());

          // Blocked suppliers
          return oSvc.getSuppliers({ isBlocked: true, top: "1000" });
        }).then(function (oBlocked) {
          oUI.setProperty("/kpis/atRiskSuppliers",
            (oBlocked.results ? oBlocked.results.length : 0).toLocaleString());
        });

      // ── Wait for all, then clear busy ───────────────────────────
      Promise.all([pPOKPIs, pPOSpend, pSalesKPIs, pRevenue, pSuppliers])
        .then(function () {
          this.setBusy(false);
          oUI.setProperty("/lastRefresh",
            new Date().toLocaleTimeString("en-US",
              { hour: "2-digit", minute: "2-digit" }));
          this._buildAlerts();
        }.bind(this))
        .catch(function (oErr) {
          this.setBusy(false);
          this._handleError(oErr, "Overview KPI load");
        }.bind(this));
    },

    // ── Derive alerts from live KPI data ─────────────────────────
    _buildAlerts: function () {
      var oUI    = this.getUIModel();
      var oKPIs  = oUI.getProperty("/kpis");
      var aAlerts = [];

      var nOverdue = parseInt((oKPIs.overduePOs || "0").replace(/,/g, "")) || 0;
      if (nOverdue > 0) {
        aAlerts.push({
          priority: "High", priorityState: "Error",
          icon: "sap-icon://alert", module: "MM-PUR",
          title: nOverdue + " Overdue Purchase Order Items",
          description: "Items past schedule line delivery date. Escalation recommended.",
          category: "Procurement", time: "Live"
        });
      }

      var nBlocked = parseInt((oKPIs.blockedInvoices || "0").replace(/,/g, "")) || 0;
      if (nBlocked > 0) {
        aAlerts.push({
          priority: "High", priorityState: "Error",
          icon: "sap-icon://alert", module: "MM-PUR",
          title: nBlocked + " Blocked Purchase Orders",
          description: "POs with status Blocked — release or investigate.",
          category: "Procurement", time: "Live"
        });
      }

      oUI.setProperty("/alerts", aAlerts);
      oUI.setProperty("/kpis/alertCount", aAlerts.length);
    },

    // ── Activity Feed — bind SO list directly ─────────────────────
    onAfterRendering: function () {
      // Bind the activity list directly to the sales OData model
      var oList = this.byId("activityList");
      if (oList && !oList._boundLive) {
        oList.bindItems({
          model:   "sales",
          path:    "/SalesOrders",
          template: oList.getItems()[0] ? oList.removeItem(0) : undefined,
          parameters: {
            select: "SalesOrder,SoldToPartyName,TotalNetAmount,TransactionCurrency,SalesOrderDate",
            top:    "6",
            sorter: [{ path: "SalesOrderDate", descending: true }]
          }
        });
        oList._boundLive = true;
      }
    },

    // ── SO Pipeline table row press ───────────────────────────────
    onSORowPress: function () { this.navTo("sales"); },
    onChartPress: function () { this.navTo("sales"); },

    // ── Filter bar change ─────────────────────────────────────────
    onFilterChange: function () { this._loadData(); }
  });
});
