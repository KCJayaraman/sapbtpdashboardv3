/**
 * com.logistics.delaylib — SAP UI5 Reusable Library
 * ─────────────────────────────────────────────────────────────────────────────
 * Package: com.logistics.delaylib
 * Version: 1.0.0
 *
 * Provides three pillars:
 *   1. CONTROLS   — DelayMonitor, DelaySimulator, RulesEditor (custom UI5 controls)
 *   2. RULES ENGINE — RulesEngine (pure JS, framework-agnostic rule evaluator)
 *   3. SIMULATION  — DelaySimulator (Monte-Carlo + scenario engine)
 *
 * Usage in any SAP UI5 app:
 *   sap.ui.getCore().loadLibrary("com.logistics.delaylib");
 *
 * Or in manifest.json:
 *   "sap.ui5": { "dependencies": { "libs": { "com.logistics.delaylib": {} } } }
 * ─────────────────────────────────────────────────────────────────────────────
 */
sap.ui.define([
  "sap/ui/core/library"
], function (coreLibrary) {
  "use strict";

  sap.ui.getCore().initLibrary({
    name:    "com.logistics.delaylib",
    version: "1.0.0",

    dependencies: [
      "sap.ui.core",
      "sap.m",
      "sap.f",
      "sap.ui.layout",
      "sap.suite.ui.microchart"
    ],

    types: [
      "com.logistics.delaylib.DelayStatus",
      "com.logistics.delaylib.RuleSeverity",
      "com.logistics.delaylib.ShipmentMode",
      "com.logistics.delaylib.SimulationScenario"
    ],

    controls: [
      "com.logistics.delaylib.control.DelayMonitor",
      "com.logistics.delaylib.control.DelaySimulator",
      "com.logistics.delaylib.control.RulesEditor",
      "com.logistics.delaylib.control.DelayGauge",
      "com.logistics.delaylib.control.ShipmentTimeline",
      "com.logistics.delaylib.control.RuleCard"
    ],

    elements: [],

    noLibraryCSS: false
  });

  var thisLib = sap.ui.requireSync("com/logistics/delaylib/library");

  // ── Enumerations ────────────────────────────────────────────────────────────

  /**
   * Delay severity status used in DelayMonitor and RulesEngine output.
   * @enum {string}
   */
  thisLib.DelayStatus = {
    /** No delay detected */
    OnTime:    "OnTime",
    /** 1–3 days delay */
    Minor:     "Minor",
    /** 4–7 days delay */
    Moderate:  "Moderate",
    /** 8–14 days delay */
    Severe:    "Severe",
    /** >14 days delay */
    Critical:  "Critical",
    /** Shipment cancelled or lost */
    Cancelled: "Cancelled"
  };

  /**
   * Business rule severity — used in RulesEditor and RulesEngine.
   * @enum {string}
   */
  thisLib.RuleSeverity = {
    Info:     "Info",
    Warning:  "Warning",
    Error:    "Error",
    Critical: "Critical"
  };

  /**
   * Shipment transport mode.
   * @enum {string}
   */
  thisLib.ShipmentMode = {
    Sea: "Sea",
    Air: "Air",
    Road: "Road",
    Rail: "Rail",
    Multimodal: "Multimodal"
  };

  /**
   * Predefined simulation scenarios.
   * @enum {string}
   */
  thisLib.SimulationScenario = {
    /** Normal operating conditions */
    Baseline:        "Baseline",
    /** Port congestion at major hubs */
    PortCongestion:  "PortCongestion",
    /** Adverse weather — storms, fog, ice */
    WeatherDisruption: "WeatherDisruption",
    /** Customs hold or inspection delay */
    CustomsDelay:    "CustomsDelay",
    /** Carrier capacity shortage */
    CapacityShortage: "CapacityShortage",
    /** Labour strike at port or carrier */
    Strike:          "Strike",
    /** Geopolitical event — rerouting */
    Geopolitical:    "Geopolitical",
    /** User-defined custom scenario */
    Custom:          "Custom"
  };

  return thisLib;
});
