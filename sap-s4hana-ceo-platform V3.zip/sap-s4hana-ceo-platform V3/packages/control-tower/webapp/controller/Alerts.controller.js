sap.ui.define([
  "./BaseController",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageBox",
  "sap/m/MessageToast"
], function (BaseController, Filter, FilterOperator, MessageBox, MessageToast) {
  "use strict";

  return BaseController.extend("com.company.controltower.controller.Alerts", {

    onInit: function () {
      BaseController.prototype.onInit.apply(this, arguments);
      this.getOwnerComponent().getRouter()
        .getRoute("alerts")
        .attachPatternMatched(this._loadData, this);
    },

    // ── Main loader — reads live data, derives exception alerts ───
    _loadData: function () {
      this.setBusy(true, "Alerts");
      var oSvc = this._oService;
      var oUI  = this.getUIModel();
      var aAlerts = [];

      var oNow   = new Date();
      var oMonth = new Date(oNow.getFullYear(), oNow.getMonth(), 1);

      // ── 1. Overdue PO items (MM_PUR_PO_MAINT_V2_SRV) ───────────
      var pOverdue = oSvc.getPurchaseOrderItems({ overdueOnly: true, top: "500" })
        .then(function (oData) {
          var n     = oData.results ? oData.results.length : 0;
          var fAmt  = 0;
          var oSupMap = {};
          oData.results.forEach(function (o) {
            fAmt += parseFloat(o.NetPriceAmount) || 0;
            oSupMap[o.PurchaseOrder] = true;
          });
          if (n > 0) {
            aAlerts.push({
              id: "ALT_OVERDUE_PO", priority: "High", priorityState: "Error",
              icon: "sap-icon://alert", module: "MM-PUR",
              title: n + " Overdue Purchase Order Items — " +
                     oSvc.formatAmount(fAmt, "EUR") + " at risk",
              description: Object.keys(oSupMap).length + " affected POs. " +
                           "Delivery dates exceeded. Escalation to CPO recommended.",
              category: "Procurement",
              time: new Date().toLocaleTimeString()
            });
          }
        });

      // ── 2. Blocked POs ──────────────────────────────────────────
      var pBlockedPO = oSvc.getPurchaseOrders({ status: "B", top: "200" })
        .then(function (oData) {
          var n    = oData.results ? oData.results.length : 0;
          var fAmt = 0;
          oData.results.forEach(function (o) {
            fAmt += parseFloat(o.NetPurchaseOrderAmount) || 0;
          });
          if (n > 0) {
            aAlerts.push({
              id: "ALT_BLOCKED_PO", priority: "High", priorityState: "Error",
              icon: "sap-icon://alert", module: "MM-PUR",
              title: n + " Blocked Purchase Orders — " + oSvc.formatAmount(fAmt, "EUR"),
              description: "POs with status B (Blocked). Cannot process GR/IV until released.",
              category: "Procurement",
              time: new Date().toLocaleTimeString()
            });
          }
        });

      // ── 3. Blocked sales orders (SD credit/delivery block) ──────
      var pBlockedSO = oSvc.getSalesOrders({ blocked: true, top: "200" })
        .then(function (oData) {
          var n    = oData.results ? oData.results.length : 0;
          var fAmt = 0;
          oData.results.forEach(function (o) {
            fAmt += parseFloat(o.TotalNetAmount) || 0;
          });
          if (n > 0) {
            aAlerts.push({
              id: "ALT_BLOCKED_SO", priority: "High", priorityState: "Error",
              icon: "sap-icon://alert", module: "SD",
              title: n + " Blocked Sales Orders — " + oSvc.formatAmount(fAmt, "USD"),
              description: "Orders with delivery/credit block. Customer billing delayed.",
              category: "Sales",
              time: new Date().toLocaleTimeString()
            });
          }
        });

      // ── 4. On-time delivery rate below 90% ──────────────────────
      var pOTD = oSvc.getSalesOrders({ dateFrom: oMonth, dateTo: oNow, top: "1000" })
        .then(function (oData) {
          var nTotal  = oData.results.length;
          var nOnTime = oData.results.filter(function (o) {
            return o.OverallDeliveryStatus === "C";
          }).length;
          var fRate = nTotal ? Math.round((nOnTime / nTotal) * 100) : 100;
          if (fRate < 90 && nTotal > 0) {
            aAlerts.push({
              id: "ALT_OTD", priority: "Medium", priorityState: "Warning",
              icon: "sap-icon://warning2", module: "SD",
              title: "On-Time Delivery " + fRate + "% — Below 90% SLA Threshold",
              description: (nTotal - nOnTime) + " of " + nTotal +
                           " orders (MTD) not yet delivered. Review shipping schedule.",
              category: "Sales",
              time: new Date().toLocaleTimeString()
            });
          }
        });

      // ── 5. Blocked / at-risk suppliers ──────────────────────────
      var pBlockedBP = oSvc.getSuppliers({ isBlocked: true, top: "500" })
        .then(function (oData) {
          var n = oData.results ? oData.results.length : 0;
          if (n > 0) {
            aAlerts.push({
              id: "ALT_SUPP_BLOCKED", priority: "Medium", priorityState: "Warning",
              icon: "sap-icon://warning2", module: "MM-PUR",
              title: n + " Suppliers Marked as Blocked",
              description: "These vendors cannot receive new POs. Review in Supplier Factsheet (F2710).",
              category: "Suppliers",
              time: new Date().toLocaleTimeString()
            });
          }
        });

      // ── 6. Returns (credit memos > 0 this month) ────────────────
      var pReturns = oSvc.getBillingDocuments({
        dateFrom: oMonth, dateTo: oNow, type: "G2", top: "200"
      }).then(function (oData) {
        var n    = oData.results ? oData.results.length : 0;
        var fAmt = 0;
        oData.results.forEach(function (o) {
          fAmt += parseFloat(o.TotalNetAmount) || 0;
        });
        if (n > 0) {
          aAlerts.push({
            id: "ALT_RETURNS", priority: "Medium", priorityState: "Warning",
            icon: "sap-icon://warning2", module: "SD",
            title: n + " Customer Returns (Credit Memos) this month",
            description: "Total credit value: " + oSvc.formatAmount(fAmt, "USD") +
                         ". Review quality or delivery issues.",
            category: "Sales",
            time: new Date().toLocaleTimeString()
          });
        }
      });

      // ── Collect, sort by priority, push to UI model ──────────────
      Promise.all([pOverdue, pBlockedPO, pBlockedSO, pOTD, pBlockedBP, pReturns])
        .then(function () {
          // Sort: High first, then Medium, then Low
          var oPriority = { "High": 0, "Medium": 1, "Low": 2 };
          aAlerts.sort(function (a, b) {
            return (oPriority[a.priority] || 9) - (oPriority[b.priority] || 9);
          });

          oUI.setProperty("/alerts", aAlerts);
          oUI.setProperty("/kpis/alertCount", aAlerts.length);

          // Summary KPIs
          var nHigh   = aAlerts.filter(function (a) { return a.priority === "High";   }).length;
          var nMedium = aAlerts.filter(function (a) { return a.priority === "Medium"; }).length;
          oUI.setProperty("/alertSummary", {
            high: nHigh, medium: nMedium,
            low:  aAlerts.length - nHigh - nMedium
          });

          this.setBusy(false, "Alerts");
          oUI.setProperty("/lastRefresh", new Date().toLocaleTimeString());
        }.bind(this))
        .catch(function (oErr) {
          this.setBusy(false, "Alerts");
          this._handleError(oErr, "Alerts load");
        }.bind(this));
    },

    // ── Category filter ───────────────────────────────────────────
    onAlertFilter: function (oEvent) {
      var sKey    = oEvent.getParameter("item").getKey();
      var oUI     = this.getUIModel();
      var aAll    = oUI.getProperty("/alerts") || [];
      if (sKey === "ALL") {
        oUI.setProperty("/alertsFiltered", aAll);
        return;
      }
      oUI.setProperty("/alertsFiltered",
        aAll.filter(function (a) { return a.category === sKey; }));
    },

    // ── Resolve alert ─────────────────────────────────────────────
    onResolveAlert: function (oEvent) {
      var oCtx = oEvent.getSource().getParent().getBindingContext("ui");
      if (!oCtx) { return; }
      var sTitle = oCtx.getProperty("title");
      MessageBox.confirm(
        "Mark this alert as acknowledged?\n\n" + sTitle,
        {
          title: "Acknowledge Alert",
          onClose: function (sAction) {
            if (sAction === MessageBox.Action.OK) {
              // In production: write a WorkflowTask completion to SWI2 or custom table
              var oUI    = this.getModel("ui");
              var aAlerts = oUI.getProperty("/alerts") || [];
              var sId     = oCtx.getProperty("id");
              var aNew    = aAlerts.filter(function (a) { return a.id !== sId; });
              oUI.setProperty("/alerts", aNew);
              oUI.setProperty("/kpis/alertCount", aNew.length);
              MessageToast.show("Alert acknowledged.");
            }
          }.bind(this)
        }
      );
    },

    // ── Alert press → deep link ───────────────────────────────────
    onAlertPress: function (oEvent) {
      var oCtx = oEvent.getSource().getBindingContext("ui");
      if (!oCtx) { return; }
      var oAlert = oCtx.getObject();
      MessageBox.warning(
        oAlert.title + "\n\n" + oAlert.description +
        "\n\nModule: " + oAlert.module +
        "\nDetected: " + oAlert.time,
        { title: "Alert Detail — " + oAlert.id }
      );
    }
  });
});
