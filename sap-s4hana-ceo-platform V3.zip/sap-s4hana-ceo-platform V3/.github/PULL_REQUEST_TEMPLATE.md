## Summary

<!-- What does this PR do? 2-3 sentences. -->

## Type of change

- [ ] Bug fix
- [ ] New feature
- [ ] Documentation
- [ ] Refactor
- [ ] Dependency update

## Package(s) changed

- [ ] `packages/control-tower`
- [ ] `packages/logistics-delay-lib`
- [ ] `docs/`
- [ ] `.github/`

## Testing done

- [ ] Ran `npm start` locally — no console errors
- [ ] Checked all affected tabs render correctly
- [ ] Ran `npx eslint webapp/` — no new errors
- [ ] Verified BTP deploy works (`mbt build` succeeds)

## Screenshots (if UI changed)

<!-- Add before/after screenshots if visual changes were made -->

## Related issues

Closes #

## Checklist

- [ ] Code follows the style in `CONTRIBUTING.md`
- [ ] API calls only in `*Service.js` files
- [ ] No hardcoded credentials or API keys
- [ ] Added/updated i18n properties if new strings were added
- [ ] Updated `CHANGELOG.md`
