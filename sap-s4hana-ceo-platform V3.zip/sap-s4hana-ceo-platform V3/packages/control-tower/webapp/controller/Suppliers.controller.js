sap.ui.define([
  "./BaseController",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/Sorter",
  "sap/ui/export/library"
], function (BaseController, Filter, FilterOperator, Sorter, exportLibrary) {
  "use strict";

  var EdmType = exportLibrary.EdmType;

  return BaseController.extend("com.company.controltower.controller.Suppliers", {

    onInit: function () {
      BaseController.prototype.onInit.apply(this, arguments);
      this.getOwnerComponent().getRouter()
        .getRoute("suppliers")
        .attachPatternMatched(this._loadData, this);
    },

    // ── Main loader ───────────────────────────────────────────────
    _loadData: function () {
      this.setBusy(true, "Suppliers");
      var oSvc = this._oService;
      var oUI  = this.getUIModel();

      // 1. Total active (non-blocked) suppliers
      var pActive = oSvc.getSuppliers({ isBlocked: false, top: "2000" })
        .then(function (oData) {
          var aAll    = oData.results || [];
          var nActive = aAll.filter(function (s) {
            return !s.IsBlockedForPosting && !s.PurchasingIsBlocked;
          }).length;
          oUI.setProperty("/kpis/activeSuppliers", nActive.toLocaleString());

          // Country breakdown for risk chart
          var oCountryMap = {};
          aAll.forEach(function (s) {
            var c = s.Country || "OTHER";
            oCountryMap[c] = (oCountryMap[c] || 0) + 1;
          });
          var aCountries = Object.keys(oCountryMap)
            .map(function (k) { return { country: k, count: oCountryMap[k] }; })
            .sort(function (a, b) { return b.count - a.count; })
            .slice(0, 8);
          oUI.setProperty("/suppliersByCountry", aCountries);

          return oData;
        });

      // 2. Blocked (at-risk) suppliers
      var pBlocked = oSvc.getSuppliers({ isBlocked: true, top: "1000" })
        .then(function (oData) {
          oUI.setProperty("/kpis/atRiskSuppliers",
            (oData.results ? oData.results.length : 0).toLocaleString());
        });

      // 3. Spend per supplier — cross-ref with PO data
      var pSpend = oSvc.getPurchaseOrders({ top: "2000" })
        .then(function (oData) {
          var aBySupplier = oSvc.aggregateByKey(
            oData.results, "Supplier", "SupplierName", "NetPurchaseOrderAmount"
          ).slice(0, 20);

          var fGrand = aBySupplier.reduce(function (s, o) { return s + o.total; }, 0);
          var aRows  = aBySupplier.map(function (o) {
            return {
              supplier:  o.key,
              name:      o.label || o.key,
              spendYTD:  oSvc.formatAmount(o.total, "EUR"),
              spendRaw:  o.total,
              percent:   Math.round((o.total / fGrand) * 100),
              poCount:   o.count
            };
          });
          oUI.setProperty("/supplierSpend", aRows);
        });

      // 4. Bind supplier table directly to OData
      this._bindSupplierTable();

      Promise.all([pActive, pBlocked, pSpend])
        .then(function () {
          this.setBusy(false, "Suppliers");
          oUI.setProperty("/lastRefresh", new Date().toLocaleTimeString());
        }.bind(this))
        .catch(function (oErr) {
          this.setBusy(false, "Suppliers");
          this._handleError(oErr, "Suppliers load");
        }.bind(this));
    },

    // ── Bind supplier table directly to A_Supplier OData ─────────
    _bindSupplierTable: function () {
      var oTable = this.byId("supplierTable");
      if (!oTable) { return; }

      oTable.bindItems({
        model:   "bp",
        path:    "/A_Supplier",
        sorter:  new Sorter("SupplierName", false),
        parameters: {
          select: [
            "Supplier",
            "SupplierName",
            "SupplierFullName",
            "Country",
            "CityName",
            "Industry",
            "SupplierAccountGroup",
            "CreationDate",
            "IsBlockedForPosting",
            "PurchasingIsBlocked",
            "PostingIsBlocked"
          ].join(","),
          top: "200"
        }
      });
    },

    // ── Search ────────────────────────────────────────────────────
    onSupplierSearch: function (oEvent) {
      var sQuery   = oEvent.getParameter("query");
      var oTable   = this.byId("supplierTable");
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }

      if (!sQuery) {
        oBinding.filter([]);
        return;
      }
      oBinding.filter([
        new Filter({
          filters: [
            new Filter("SupplierName",    FilterOperator.Contains, sQuery),
            new Filter("Supplier",        FilterOperator.Contains, sQuery),
            new Filter("Country",         FilterOperator.Contains, sQuery),
            new Filter("Industry",        FilterOperator.Contains, sQuery)
          ],
          and: false
        })
      ]);
    },

    // ── Country filter ────────────────────────────────────────────
    onCountryFilter: function (oEvent) {
      var sKey   = oEvent.getParameter("item").getKey();
      var oTable = this.byId("supplierTable");
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }

      if (sKey === "ALL") {
        oBinding.filter([]);
      } else {
        oBinding.filter([
          new Filter("Country", FilterOperator.EQ, sKey)
        ]);
      }
    },

    // ── Blocked filter ────────────────────────────────────────────
    onBlockedFilter: function (oEvent) {
      var bShow  = oEvent.getSource().getPressed();
      var oTable = this.byId("supplierTable");
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }

      if (bShow) {
        oBinding.filter([
          new Filter("IsBlockedForPosting", FilterOperator.EQ, true)
        ]);
      } else {
        oBinding.filter([]);
      }
    },

    // ── Export ────────────────────────────────────────────────────
    onExportSuppliers: function () {
      var oTable = this.byId("supplierTable");
      if (!oTable) { return; }
      var aData = (oTable.getBinding("items") || { getCurrentContexts: function(){ return []; }})
        .getCurrentContexts().map(function (c) { return c.getObject(); });

      this._exportToExcel(aData, [
        { label: "Supplier ID",   property: "Supplier",             type: EdmType.String  },
        { label: "Name",          property: "SupplierName",         type: EdmType.String  },
        { label: "Country",       property: "Country",              type: EdmType.String  },
        { label: "City",          property: "CityName",             type: EdmType.String  },
        { label: "Industry",      property: "Industry",             type: EdmType.String  },
        { label: "Account Group", property: "SupplierAccountGroup", type: EdmType.String  },
        { label: "Created",       property: "CreationDate",         type: EdmType.Date    },
        { label: "Blocked",       property: "IsBlockedForPosting",  type: EdmType.Boolean }
      ], "Suppliers_S4HANA");
    }
  });
});
