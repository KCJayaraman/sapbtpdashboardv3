# API Reference

Complete reference for all S/4HANA OData services and the TrackCargo REST API
used in this platform.

---

## S/4HANA OData APIs

### 1. MM_PUR_PO_MAINT_V2_SRV — Purchase Orders

**Base URL:** `/sap/opu/odata/sap/MM_PUR_PO_MAINT_V2_SRV/`
**Model key in manifest:** `procurement`
**Auth:** Via `S4HANA_BACKEND` BTP Destination (BasicAuth / OAuth)

#### Entity Set: PurchaseOrders

| Field | Type | Description |
|---|---|---|
| `PurchaseOrder` | String(10) | **Key** — PO document number |
| `Supplier` | String(10) | Vendor number (LFA1-LIFNR) |
| `SupplierName` | String(80) | Vendor name |
| `PurchasingOrganization` | String(4) | Purchasing org |
| `PurchasingGroup` | String(3) | Purchasing group |
| `NetPurchaseOrderAmount` | Decimal | Total net value |
| `DocumentCurrency` | String(5) | Currency key |
| `PurchasingDocumentDate` | DateTime | PO creation date |
| `PurchaseOrderStatus` | String(1) | ` `=Open, `A`=In Process, `B`=Blocked, `C`=Closed |
| `GoodsReceiptIsExpected` | Boolean | GR expected flag |
| `InvoiceIsExpected` | Boolean | Invoice expected flag |
| `CompanyCode` | String(4) | Company code |

**Example call (from S4HanaService.js):**
```javascript
this._read(this._oProcModel, "/PurchaseOrders", {
  filters: [new Filter("PurchaseOrderStatus", FilterOperator.NE, "C")],
  urlParameters: {
    "$top": "200",
    "$orderby": "NetPurchaseOrderAmount desc",
    "$select": "PurchaseOrder,Supplier,SupplierName,NetPurchaseOrderAmount,..."
  }
});
```

#### Entity Set: PurchaseOrderItems

| Field | Type | Description |
|---|---|---|
| `PurchaseOrder` | String(10) | **Key** — parent PO number |
| `PurchaseOrderItem` | String(5) | **Key** — item number |
| `Material` | String(40) | Material number |
| `MaterialGroup` | String(9) | Material group (for spend analysis) |
| `NetPriceAmount` | Decimal | Net price |
| `ScheduleLineDeliveryDate` | DateTime | Expected delivery date |
| `PurchaseOrderStatus` | String(1) | Item status |

**Used for:** Overdue detection (`ScheduleLineDeliveryDate lt today`), spend by material group aggregation.

#### Entity Set: PurchaseRequisitions

| Field | Type | Description |
|---|---|---|
| `PurchaseRequisition` | String(10) | **Key** |
| `PurchaseRequisitionStatus` | String(1) | Status |
| `Material` | String(40) | Material |
| `MaterialGroup` | String(9) | Material group |
| `TotalNetAmount` | Decimal | Total value |
| `CreationDate` | DateTime | Created on |

---

### 2. SD_F1493_SALESORDER_MANAGE_SRV — Sales Orders

**Base URL:** `/sap/opu/odata/sap/SD_F1493_SALESORDER_MANAGE_SRV/`
**Model key in manifest:** `sales`

#### Entity Set: SalesOrders

| Field | Type | Description |
|---|---|---|
| `SalesOrder` | String(10) | **Key** — SO document number |
| `SoldToParty` | String(10) | Customer number |
| `SoldToPartyName` | String(40) | Customer name |
| `SalesOrganization` | String(4) | Sales org (VKORG) |
| `TotalNetAmount` | Decimal | Net order value |
| `TransactionCurrency` | String(5) | Currency |
| `SalesOrderDate` | DateTime | Order creation date |
| `RequestedDeliveryDate` | DateTime | Requested delivery |
| `OverallSDProcessStatus` | String(1) | ` `=Open, `A`=In Process, `B`=Partial, `C`=Completed |
| `OverallDeliveryStatus` | String(1) | ` `=Not started, `A`=Partial, `C`=Full |
| `SalesOrderBlockingReasonCode` | String(2) | Non-empty = blocked |

**Filter for on-time delivery rate:**
```javascript
// Delivered on time = OverallDeliveryStatus eq 'C' within the month
new Filter("SalesOrderDate", FilterOperator.GE, oMonthStart)
```

#### Entity Set: SalesOrderItems

| Field | Type | Description |
|---|---|---|
| `SalesOrder` | String(10) | **Key** |
| `SalesOrderItem` | String(6) | **Key** |
| `Material` | String(40) | Material |
| `MaterialGroup` | String(9) | Material group |
| `NetAmount` | Decimal | Line item net value |

---

### 3. API_BUSINESS_PARTNER — Supplier Master

**Base URL:** `/sap/opu/odata/sap/API_BUSINESS_PARTNER/`
**Model key in manifest:** `bp`

#### Entity Set: A_Supplier

| Field | Type | Description |
|---|---|---|
| `Supplier` | String(10) | **Key** — vendor number |
| `SupplierName` | String(80) | Vendor name |
| `Country` | String(3) | Country key |
| `CityName` | String(40) | City |
| `Industry` | String(10) | Industry sector |
| `SupplierAccountGroup` | String(4) | Account group |
| `CreationDate` | DateTime | Created on |
| `IsBlockedForPosting` | Boolean | FI posting block |
| `PurchasingIsBlocked` | Boolean | MM purchasing block |

**Filter for blocked suppliers (at-risk):**
```javascript
new Filter("IsBlockedForPosting", FilterOperator.EQ, true)
```

#### Entity Set: A_SupplierPurchasingOrg

| Field | Type | Description |
|---|---|---|
| `Supplier` | String(10) | **Key** |
| `PurchasingOrganization` | String(4) | **Key** |
| `PaymentTerms` | String(4) | Payment terms |
| `IsGoodsReceiptBased` | Boolean | GR-based IV flag |

---

### 4. SD_INVOICE_POST_SRV — Billing Documents

**Base URL:** `/sap/opu/odata/sap/SD_INVOICE_POST_SRV/`
**Model key in manifest:** `billing`

#### Entity Set: BillingDocument

| Field | Type | Description |
|---|---|---|
| `BillingDocument` | String(10) | **Key** |
| `BillingDocumentType` | String(4) | `F2`=Invoice, `G2`=Credit memo, `L2`=Debit memo |
| `SalesOrganization` | String(4) | Sales org |
| `BillingDocumentDate` | DateTime | Billing date |
| `SoldToParty` | String(10) | Customer number |
| `SoldToPartyName` | String(40) | Customer name |
| `TotalNetAmount` | Decimal | Net billing value |
| `TransactionCurrency` | String(5) | Currency |

**Filter for MTD revenue:**
```javascript
new Filter("BillingDocumentDate", FilterOperator.GE, oMonthStart),
new Filter("BillingDocumentType", FilterOperator.EQ, "F2")
```

**Filter for returns (credit memos):**
```javascript
new Filter("BillingDocumentType", FilterOperator.EQ, "G2")
```

---

## TrackCargo REST API

**Base URL (via BTP proxy):** `/trackcargo/`
**Actual URL:** `https://trackcargo.co`
**Auth:** Bearer token injected by BTP Destination `TRACKCARGO_API`
**Docs:** [trackcargo.co/developer](https://trackcargo.co/developer)

### Endpoints

#### GET /api/v1/client-orders/recent

Returns most recently created tracking orders across all modes.

**Query parameters:**
| Parameter | Type | Description |
|---|---|---|
| `limit` | int | Max results (default 50) |

**Response:**
```json
{
  "orders": [
    {
      "orderId":    "TC-12345",
      "reference":  "MAEU123456789",
      "carrier":    "Maersk",
      "type":       "sea",
      "status":     "delayed",
      "delayDays":  5,
      "pol":        "Rotterdam",
      "pod":        "Shanghai",
      "eta":        "2025-03-25",
      "isDelayed":  true
    }
  ]
}
```

#### GET /api/v1/client-orders/sea

Returns all sea freight orders.

**Response:** Same shape as `/recent` but filtered to `type: "sea"`.

#### GET /api/v1/client-orders/air

Returns all air freight orders (`type: "air"`).

#### GET /api/v1/client-orders/sea/overview

Returns aggregate statistics for sea shipments.

**Response:**
```json
{
  "overview": {
    "total":      42,
    "delayed":    8,
    "onTime":     28,
    "inTransit":  34,
    "arrived":    8,
    "onTimeRate": 77.8
  }
}
```

#### GET /api/v1/client-orders/air/overview

Same shape as `/sea/overview` but for air freight.

#### GET /api/v1/client-orders/{orderId}

Returns full detail for a single order.

**Path parameters:**
| Parameter | Description |
|---|---|
| `orderId` | Order ID from the orders list |

#### GET /api/v1/client-orders/{orderId}/tracking

Returns live tracking event timeline for a single order.

**Response:**
```json
{
  "tracking": {
    "currentStatus": "delayed",
    "eta":           "2025-03-25",
    "delayDays":     5,
    "events": [
      {
        "timestamp": "2025-03-10T08:00:00Z",
        "location":  "Rotterdam",
        "event":     "Vessel departed",
        "status":    "departed"
      },
      {
        "timestamp": "2025-03-18T14:00:00Z",
        "location":  "Suez Canal",
        "event":     "Rerouting due to congestion",
        "status":    "delayed"
      }
    ]
  }
}
```

#### POST /api/v1/client-orders/create

Creates a new tracking order.

**Request body:**
```json
{
  "type":           "sea",
  "trackingNumber": "MAEU123456789",
  "carrier":        "MAEU",
  "reference":      "4500012345",
  "description":    "Optional free-text"
}
```

**Response:**
```json
{
  "orderId": "TC-99999",
  "status":  "created",
  "message": "Tracking order created successfully"
}
```

#### GET /api/tracking/api/v1/active-airlines

Returns supported airline carriers.

#### GET /api/tracking/api/v1/active-shipping-lines

Returns supported ocean shipping lines (75+ carriers).

---

## Delay Library — RulesEngine API

```javascript
// Constructor
var oEngine = new RulesEngine({
  rules:       [],          // initial rule set
  stopOnFirst: false,       // stop after first rule matches
  dryRun:      false        // evaluate without firing action handlers
});

// Rule management
oEngine.addRule(oRule);                    // → this (chainable)
oEngine.removeRule("RULE_001");            // → this
oEngine.setRuleActive("RULE_001", false);  // → this
oEngine.getRule("RULE_001");               // → rule object | null
oEngine.getRules();                        // → Array of rules (copy)
oEngine.loadRules(aRules);                 // → this — replaces ruleset
oEngine.getDefaultRules();                 // → Array of 10 built-in rules

// Evaluation
oEngine.evaluate(oShipment);
// → { matched: [{ruleId, ruleName, severity, actions}], rulesFired, rulesSkipped }

oEngine.evaluateBatch(aShipments);
// → { results: [...], totalMatches, criticalCount, errorCount }

// Persistence
oEngine.exportRules();         // → JSON string
oEngine.importRules(sJson);    // → this

// Custom handlers
oEngine.registerActionHandler("myAction", function(oAction, oShipment, oRule) {
  // called when a rule with action.type === "myAction" fires
});

// Audit
oEngine.getAuditLog();   // → Array of match records
oEngine.clearAuditLog(); // → this
```

---

## Delay Library — DelaySimulationEngine API

```javascript
var oEngine = new DelaySimulationEngine({
  iterations:      1000,   // Monte Carlo iterations
  demurrageDayRate:500,    // USD cost per delay day
  expediteCostRate:0.03,   // fraction of shipment value for air upgrade
  seed:            42      // optional — for reproducible results
});

// Single simulation
var oResult = oEngine.simulate(oShipment, "PortCongestion");
// oResult.delays:  { p10, p50, p90, p99, mean, stdDev, min, max, histogram }
// oResult.costs:   { p50, p90, mean, max }
// oResult.onTimeProb, oResult.delayProb, oResult.severeProb

// Scenario comparison
var oComp = oEngine.compareScenarios(oShipment, ["Baseline", "Strike"]);
// oComp.comparison: [{ scenario, p50, p90, onTimeProb, delayProb, costP90 }]

// Batch simulation (portfolio)
var oBatch = oEngine.simulateBatch(aShipments, "WeatherDisruption");
// oBatch.portfolioStats: { totalShipments, expectedDelayed, portfolioP90, totalCostP90 }

// Custom scenario
oEngine.registerScenario("RedSea2024", {
  portDelay:    { min: 5, max: 20, mean: 10, stdDev: 4 },
  transitDelay: { min: 7, max: 28, mean: 14, stdDev: 6 },
  customsDelay: { min: 2, max: 8,  mean: 4,  stdDev: 2 },
  weatherDelay: { min: 0, max: 3,  mean: 1,  stdDev: 1 },
  carrierDelay: { min: 3, max: 12, mean: 6,  stdDev: 3 },
  eventProb:    0.35
});

oEngine.getScenarioNames(); // → ["Baseline", "PortCongestion", ..., "RedSea2024"]
```
