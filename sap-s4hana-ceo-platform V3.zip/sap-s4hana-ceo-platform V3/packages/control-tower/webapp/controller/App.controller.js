sap.ui.define([
  "./BaseController",
  "sap/m/MessageToast"
], function (BaseController, MessageToast) {
  "use strict";

  return BaseController.extend("com.company.controltower.controller.App", {

    onInit: function () {
      BaseController.prototype.onInit.apply(this, arguments);
      var oRouter = this.getOwnerComponent().getRouter();
      oRouter.attachRouteMatched(this._onRouteMatched, this);
      this._startClock();
    },

    _onRouteMatched: function (oEvent) {
      var sRoute = oEvent.getParameter("name");
      var oSideNav = this.byId("sideNav");
      if (!oSideNav) { return; }
      var oMatch = oSideNav.getItems().find(function (i) {
        return i.getKey() === sRoute;
      });
      if (oMatch) { oSideNav.setSelectedItem(oMatch); }
    },

    onNavItemSelect: function (oEvent) {
      var sKey = oEvent.getParameter("item").getKey();
      if (sKey === "settings") {
        MessageToast.show("Settings panel coming soon.");
        return;
      }
      this.getOwnerComponent().getRouter().navTo(sKey);
    },

    onAvatarPress: function () {
      MessageToast.show("SAP S/4HANA CEO Control Tower — v2.0 (Live API)");
    },

    _startClock: function () {
      var oClock = this.byId("ctClock");
      var fnTick = function () {
        if (oClock && !oClock.bIsDestroyed) {
          oClock.setText(new Date().toLocaleTimeString("en-US", {
            hour: "2-digit", minute: "2-digit", second: "2-digit"
          }));
        }
      };
      fnTick();
      setInterval(fnTick, 1000);
    }
  });
});
