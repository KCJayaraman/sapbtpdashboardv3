# Changelog

All notable changes to this project are documented here.
Format: [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
Versioning: [Semantic Versioning](https://semver.org/)

---

## [3.0.0] — 2025-03-15

### Added — Control Tower
- **Logistics tab** — TrackCargo REST API integration via BTP Destination `TRACKCARGO_API`
  - Sea + air freight real-time tracking
  - Carrier delay rate breakdown
  - Trade lane risk ranking
  - Delayed shipments table sorted by delay days
  - Live tracking event dialog (per-shipment row press)
  - "Track New Shipment" dialog — calls `POST /api/v1/client-orders/create`
- `TrackCargoService.js` — full REST client covering all 10 TrackCargo endpoints
- `btpconfig/TRACKCARGO_API.destination` — importable BTP Destination file
- `btpconfig/setup-btp-destinations.sh` — automated BTP CLI setup script
- `btpconfig/TRACKCARGO_DESTINATION_SETUP.md` — manual setup guide
- Delay alerts from TrackCargo feed automatically into the Alerts tab

### Added — Delay Library (`com.logistics.delaylib`)
- New standalone SAP UI5 library — first release
- `RulesEngine.js` — pure JS rule evaluator with 17 operators, AND/OR logic, audit log
- `DelaySimulationEngine.js` — Monte Carlo simulation with 7 built-in scenarios
- `DelayMonitor.js` — drop-in delay KPI + shipment table composite control
- `RulesEditor.js` — full business rules management UI control
- `DelaySimulatorControl.js` — simulation UI with P50/P90/P99 results
- 10 default rules covering overdue sea/air, high-value, customs hold, trade lane
- `INTEGRATION.md` — guide for wiring library into any SAP UI5 app
- Demo application with 3 tabs (Monitor, Rules, Simulation)

### Changed
- `mta.yaml` — updated to v3.0.0, added TRACKCARGO_API and UI5_CDN destinations
- `approuter/xs-app.json` — added `/trackcargo/*` route with no auth (BTP key injection)

---

## [2.0.0] — 2025-03-01

### Added
- **Live S/4HANA OData** — replaced all mock data with real API calls
- `S4HanaService.js` — central OData service layer (12 methods, all 4 APIs)
- `ErrorHandler.js` — global OData metadata + request error handler
- `Formatter.js` — 20+ pure formatter functions for status, dates, amounts
- Direct OData table bindings in Procurement and Suppliers views
- `localService/` metadata stubs for offline development
- Excel export for all tables via `sap.ui.export.Spreadsheet`

### Changed
- `manifest.json` — 4 real `sap.ui.model.odata.v2.ODataModel` entries replacing mock `JSONModel`
- All controllers rewritten — no `{dashboard>...}` bindings remain
- `Component.js` — registers `ErrorHandler` and `Formatter`

### Removed
- `webapp/model/mockData.json` — all data is now live

---

## [1.0.0] — 2025-01-15

### Added
- Initial Control Tower release with mock data
- 5 tabs: Overview, Procurement, Sales & Revenue, Suppliers, Alerts
- SAP UI5 ShellBar + TNT ToolPage + SideNavigation shell
- 8 KPI cards with mock data
- BTP deployment descriptor (`mta.yaml`)
- XSUAA security with `Control_Tower_CEO` and `Control_Tower_Admin` roles
- App Router with `xs-app.json` route configuration
