/**
 * ErrorHandler.js
 * Attaches to all OData models and surfaces S/4HANA error responses
 * to the user as MessageBox dialogs or MessageStrip banners.
 *
 * Registered in Component.js and active for the app's lifetime.
 */
sap.ui.define([
  "sap/ui/base/Object",
  "sap/m/MessageBox",
  "sap/m/MessageToast"
], function (BaseObject, MessageBox, MessageToast) {
  "use strict";

  return BaseObject.extend("com.company.controltower.model.ErrorHandler", {

    /**
     * @param {sap.ui.core.UIComponent} oComponent
     */
    constructor: function (oComponent) {
      var aModelNames = ["procurement", "sales", "bp", "billing"];

      aModelNames.forEach(function (sName) {
        var oModel = oComponent.getModel(sName);
        if (!oModel) { return; }

        // OData v2 fires metadataFailed when the service metadata cannot be loaded
        oModel.attachMetadataFailed(function (oEvent) {
          var oParams = oEvent.getParameters();
          this._showServiceError(
            "Metadata load failed for model '" + sName + "'.\n" +
            "Check your BTP Destination (" + sName.toUpperCase() + "_BACKEND) and S/4HANA connectivity.\n\n" +
            "Status: " + (oParams.statusCode || "—") + " " + (oParams.statusText || ""),
            true /* critical */
          );
        }, this);

        // OData request errors (4xx / 5xx / network)
        oModel.attachRequestFailed(function (oEvent) {
          var oParams  = oEvent.getParameters();
          var nStatus  = parseInt(oParams.statusCode);

          // 401 / 403 → auth problem
          if (nStatus === 401 || nStatus === 403) {
            this._showServiceError(
              "Authentication error on " + sName + " API (HTTP " + nStatus + ").\n" +
              "Verify your XSUAA role assignment: Control_Tower_CEO or Control_Tower_Admin.",
              true
            );
            return;
          }

          // 404 → entity set not found (wrong API version or not activated)
          if (nStatus === 404) {
            var sUrl = (oParams.response && oParams.response.requestUri) || "";
            this._showServiceError(
              "OData entity set not found (404) on " + sName + ".\n" +
              "URL: " + sUrl + "\n\n" +
              "Ensure the S/4HANA OData service is activated in /IWFND/MAINT_SERVICE.",
              false
            );
            return;
          }

          // 500 → backend ABAP error
          if (nStatus >= 500) {
            var sMsg = this._extractODataError(oParams.response);
            this._showServiceError(
              "S/4HANA backend error on " + sName + " (HTTP " + nStatus + "):\n" + sMsg,
              false
            );
            return;
          }

          // Other errors — toast only (don't block the UI for minor failures)
          if (nStatus >= 400) {
            MessageToast.show(
              sName + " API error " + nStatus + ": " +
              this._extractODataError(oParams.response)
            );
          }
        }, this);
      }, this);
    },

    // ── Helpers ───────────────────────────────────────────────────

    /**
     * Parses OData error response body to extract message.value.
     * S/4HANA returns: { error: { message: { value: "..." } } }
     * @param {object} oResponse  XHR response object
     * @returns {string}
     */
    _extractODataError: function (oResponse) {
      if (!oResponse) { return "Unknown error"; }
      try {
        var oBody = JSON.parse(oResponse.body || oResponse.responseText || "{}");
        return (oBody.error && oBody.error.message && oBody.error.message.value)
          ? oBody.error.message.value
          : (oResponse.statusText || "Unknown error");
      } catch (e) {
        return oResponse.statusText || "Unknown error";
      }
    },

    /**
     * Shows a MessageBox.error for critical errors, MessageToast for minor ones.
     * @param {string}  sMessage
     * @param {boolean} bCritical  true = MessageBox, false = console + toast
     */
    _showServiceError: function (sMessage, bCritical) {
      jQuery.sap.log.error("[ControlTower] " + sMessage);
      if (bCritical) {
        MessageBox.error(sMessage, {
          title: "S/4HANA Connection Error",
          details: "The Control Tower requires active OData service connections.\n" +
                   "Refer to the README for BTP Destination configuration steps."
        });
      } else {
        MessageToast.show(sMessage.split("\n")[0], { duration: 5000 });
      }
    }
  });
});
