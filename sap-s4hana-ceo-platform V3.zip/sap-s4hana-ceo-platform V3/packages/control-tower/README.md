# SAP S/4HANA CEO Control Tower — v2.0 (Live API Edition)

Production-ready SAP UI5 application that calls **real S/4HANA OData APIs** — zero mock data.
Deployable to **SAP BTP Cloud Foundry** (Trial or Production).

---

## What Changed from v1.0

| Area | v1.0 Mock | v2.0 Live API |
|---|---|---|
| Data source | `mockData.json` | Real S/4HANA OData v2 |
| Model type | `JSONModel` | `sap.ui.model.odata.v2.ODataModel` |
| Table binding | `{dashboard>/...}` | `{procurement>/PurchaseOrders}` etc. |
| KPI values | Hardcoded strings | Computed from `oModel.read()` |
| Alerts | Static list | Derived from 6 live exception queries |
| Error handling | None | `ErrorHandler.js` |
| Formatters | None | `Formatter.js` — 20+ pure functions |

---

## S/4HANA OData APIs Used

| Model Key | Service Name | Entity Sets |
|---|---|---|
| `procurement` | `MM_PUR_PO_MAINT_V2_SRV` | PurchaseOrders, PurchaseOrderItems, PurchaseRequisitions |
| `sales` | `SD_F1493_SALESORDER_MANAGE_SRV` | SalesOrders, SalesOrderItems |
| `bp` | `API_BUSINESS_PARTNER` | A_Supplier, A_SupplierPurchasingOrg |
| `billing` | `SD_INVOICE_POST_SRV` | BillingDocument |

---

## Project Structure

```
webapp/
├── Component.js              Registers 4 ODataModels + ErrorHandler + Formatter
├── manifest.json             4 OData dataSources declared as ODataModel
├── service/
│   └── S4HanaService.js      ALL OData calls live here — returns Promises
├── model/
│   ├── Formatter.js          20+ pure formatter functions (status, dates, amounts)
│   └── ErrorHandler.js       Global handler: metadata failures + HTTP 4xx/5xx
├── controller/
│   ├── BaseController.js     Shared: service, export, nav, search
│   ├── App.controller.js     Shell + SideNav + clock
│   ├── Overview.controller.js    5 parallel API calls → KPI aggregation
│   ├── Procurement.controller.js PO lifecycle + direct OData table binding
│   ├── Sales.controller.js       Revenue + SO pipeline + customer aggregation
│   ├── Suppliers.controller.js   A_Supplier table + spend cross-ref
│   └── Alerts.controller.js      6 exception queries → live alert list
├── view/
│   ├── Overview.view.xml     Binds to {ui>/kpis/...} computed from OData
│   ├── Procurement.view.xml  Table: {procurement>/PurchaseOrders}
│   ├── Sales.view.xml        Table: {sales>/SalesOrders}
│   ├── Suppliers.view.xml    Table: {bp>/A_Supplier}
│   └── Alerts.view.xml       Table: {ui>/alerts} derived from OData
└── localService/             OData metadata stubs for offline dev
```

---

## Deployment to SAP BTP Trial

### 1. Create BTP Services
```bash
cf login -a https://api.cf.us10-001.hana.ondemand.com

cf create-service xsuaa application sap-control-tower-xsuaa -c xs-security.json
cf create-service html5-apps-repo app-host     sap-control-tower-html5-repo-host
cf create-service html5-apps-repo app-runtime  sap-control-tower-html5-repo-runtime
cf create-service destination lite             sap-control-tower-dest
```

### 2. Configure S4HANA_BACKEND Destination (BTP Cockpit)
```
Name:            S4HANA_BACKEND
Type:            HTTP
URL:             https://YOUR-S4HANA-HOST.sap.com
Authentication:  BasicAuthentication
User / Password: YOUR_RFC_USER / YOUR_PASSWORD
Properties:      sap-client=100, HTML5.DynamicDestination=true
```

### 3. Activate OData Services in S/4HANA
Run `/IWFND/MAINT_SERVICE` and activate:
- `MM_PUR_PO_MAINT_V2_SRV`
- `SD_F1493_SALESORDER_MANAGE_SRV`
- `API_BUSINESS_PARTNER`
- `SD_INVOICE_POST_SRV`

### 4. Build and Deploy
```bash
npm install
mbt build
cf deploy mta_archives/sap-s4hana-control-tower_2.0.0.mtar
```

### 5. Assign Roles
BTP Cockpit → Security → Role Collections:
- `Control_Tower_CEO` → executive users
- `Control_Tower_Admin` → IT admins

---

## Local Development
```bash
# Update ui5.yaml: set url: to your S/4HANA hostname
npm install
npm start   # proxies API calls through to S/4HANA
```

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `401` on OData calls | Assign `Control_Tower_CEO` role in BTP Cockpit |
| `404` on entity sets | Activate service in `/IWFND/MAINT_SERVICE` |
| Metadata load failed | Configure `S4HANA_BACKEND` destination |
| KPIs show `—` | Check fiscal year matches your S/4HANA data range |
| CORS error locally | Use `npm start`, not direct file open |

---

## Resources
- SAP API Hub: https://api.sap.com
- UI5 Docs: https://ui5.sap.com
- BTP Trial: https://hanatrial.ondemand.com
