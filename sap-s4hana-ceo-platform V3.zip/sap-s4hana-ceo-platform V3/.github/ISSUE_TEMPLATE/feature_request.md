---
name: Feature Request
about: Propose a new feature or enhancement
title: '[FEAT] '
labels: enhancement
assignees: ''
---

## Is this related to a problem?
A clear description of the problem this feature would solve.
e.g. "It's frustrating that I have to navigate three screens to see..."

## Proposed solution
A clear description of what you want to happen.

## Which package does this affect?
- [ ] `packages/control-tower` — CEO Dashboard
- [ ] `packages/logistics-delay-lib` — Delay Library
- [ ] New package
- [ ] Both / cross-cutting

## User story
As a [CEO / analyst / developer], I want to [action] so that [outcome].

## Acceptance criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Mockup / wireframe
If you have a sketch or reference, add it here.

## Alternatives considered
Have you considered any alternative approaches?

## Additional context
S/4HANA entity sets involved, TrackCargo endpoints, UI5 controls to use, etc.
