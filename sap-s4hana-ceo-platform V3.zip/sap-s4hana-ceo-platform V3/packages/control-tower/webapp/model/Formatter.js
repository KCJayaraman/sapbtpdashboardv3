/**
 * Formatter.js
 * Stateless formatter functions referenced in XML views.
 * All functions must be pure — no side effects.
 *
 * Usage in XML binding:
 *   formatter='.formatter.functionName'
 * after registering this module in the controller or via manifest.
 */
sap.ui.define([], function () {
  "use strict";

  return {

    // ── Purchase Order status ──────────────────────────────────────

    /**
     * Maps PurchaseOrderStatus code → human-readable label.
     * EKKO-AEDAT status codes from MM_PUR_PO_MAINT_V2_SRV.
     * @param {string} sStatus
     * @returns {string}
     */
    poStatusText: function (sStatus) {
      var mMap = {
        "":  "Open",
        "A": "In Process",
        "B": "Blocked",
        "C": "Closed"
      };
      return mMap[sStatus] !== undefined ? mMap[sStatus] : (sStatus || "Unknown");
    },

    /**
     * Maps PurchaseOrderStatus → sap.ui.core.ValueState.
     * @param {string} sStatus
     * @returns {string}
     */
    poStatusState: function (sStatus) {
      var mMap = {
        "":  "None",
        "A": "Warning",
        "B": "Error",
        "C": "Success"
      };
      return mMap[sStatus] !== undefined ? mMap[sStatus] : "None";
    },

    /**
     * Returns true if a PO is overdue (delivery date < today and not closed).
     * @param {string|Date} vDeliveryDate  ScheduleLineDeliveryDate
     * @param {string}      sStatus        PurchaseOrderStatus
     * @returns {boolean}
     */
    isOverdue: function (vDeliveryDate, sStatus) {
      if (sStatus === "C") { return false; }
      if (!vDeliveryDate)  { return false; }
      var oDate = (vDeliveryDate instanceof Date) ? vDeliveryDate : new Date(vDeliveryDate);
      return oDate < new Date();
    },

    /**
     * Returns "Error" state if overdue, otherwise "None".
     * @param {string|Date} vDeliveryDate
     * @param {string}      sStatus
     * @returns {string}
     */
    overdueState: function (vDeliveryDate, sStatus) {
      return this.isOverdue(vDeliveryDate, sStatus) ? "Error" : "None";
    },

    /**
     * Human-readable overdue label.
     * @param {string|Date} vDeliveryDate
     * @param {string}      sStatus
     * @returns {string}
     */
    overdueLabel: function (vDeliveryDate, sStatus) {
      if (sStatus === "C") { return "Closed"; }
      if (!vDeliveryDate)  { return "—"; }
      var oDate = (vDeliveryDate instanceof Date) ? vDeliveryDate : new Date(vDeliveryDate);
      var nDays = Math.floor((new Date() - oDate) / 86400000);
      if (nDays > 0) { return "+" + nDays + "d late"; }
      if (nDays === 0) { return "Due today"; }
      return Math.abs(nDays) + "d remaining";
    },

    // ── Sales Order status ─────────────────────────────────────────

    /**
     * Maps OverallSDProcessStatus → label.
     * SD_F1493_SALESORDER_MANAGE_SRV status codes.
     * @param {string} sStatus
     * @returns {string}
     */
    soStatusText: function (sStatus) {
      var mMap = {
        "":  "Open",
        "A": "In Process",
        "B": "Partially Processed",
        "C": "Completed"
      };
      return mMap[sStatus] !== undefined ? mMap[sStatus] : (sStatus || "Unknown");
    },

    /**
     * Maps OverallSDProcessStatus → sap.ui.core.ValueState.
     * @param {string} sStatus
     * @returns {string}
     */
    soStatusState: function (sStatus) {
      var mMap = {
        "":  "None",
        "A": "None",
        "B": "Warning",
        "C": "Success"
      };
      return mMap[sStatus] !== undefined ? mMap[sStatus] : "None";
    },

    /**
     * Maps OverallDeliveryStatus → label.
     * @param {string} sStatus
     * @returns {string}
     */
    deliveryStatusText: function (sStatus) {
      var mMap = {
        "":  "Not Started",
        "A": "Not Delivered",
        "B": "Partial",
        "C": "Fully Delivered"
      };
      return mMap[sStatus] !== undefined ? mMap[sStatus] : (sStatus || "—");
    },

    /**
     * Maps OverallDeliveryStatus → ValueState.
     * @param {string} sStatus
     * @returns {string}
     */
    deliveryStatusState: function (sStatus) {
      var mMap = {
        "":  "None",
        "A": "Error",
        "B": "Warning",
        "C": "Success"
      };
      return mMap[sStatus] !== undefined ? mMap[sStatus] : "None";
    },

    /**
     * Returns "Error" state if a blocking reason code is set.
     * @param {string} sBlockCode  SalesOrderBlockingReasonCode
     * @returns {string}
     */
    blockState: function (sBlockCode) {
      return (sBlockCode && sBlockCode !== "") ? "Error" : "None";
    },

    /**
     * Returns "Blocked" or "—" from blocking reason code.
     * @param {string} sBlockCode
     * @returns {string}
     */
    blockText: function (sBlockCode) {
      return (sBlockCode && sBlockCode !== "") ? "Blocked (" + sBlockCode + ")" : "—";
    },

    // ── Supplier / Business Partner status ─────────────────────────

    /**
     * Returns "Error" if supplier is blocked for posting.
     * @param {boolean} bBlocked  IsBlockedForPosting
     * @param {boolean} bPurBlocked  PurchasingIsBlocked
     * @returns {string}
     */
    supplierBlockState: function (bBlocked, bPurBlocked) {
      return (bBlocked || bPurBlocked) ? "Error" : "Success";
    },

    /**
     * Human label for supplier block status.
     * @param {boolean} bBlocked
     * @param {boolean} bPurBlocked
     * @returns {string}
     */
    supplierBlockText: function (bBlocked, bPurBlocked) {
      if (bBlocked && bPurBlocked) { return "FI + MM Blocked"; }
      if (bBlocked)    { return "FI Blocked"; }
      if (bPurBlocked) { return "Purchasing Blocked"; }
      return "Active";
    },

    // ── Billing / Invoice status ───────────────────────────────────

    /**
     * Maps billing document type to a readable label.
     * @param {string} sType  BillingDocumentType
     * @returns {string}
     */
    billingTypeText: function (sType) {
      var mMap = {
        "F1": "Invoice (Down Payment)",
        "F2": "Invoice",
        "F5": "Pro Forma (Order)",
        "F8": "Pro Forma (Delivery)",
        "G2": "Credit Memo",
        "L2": "Debit Memo",
        "RE": "Returns"
      };
      return mMap[sType] || sType || "—";
    },

    /**
     * Returns ValueState for billing document type.
     * @param {string} sType
     * @returns {string}
     */
    billingTypeState: function (sType) {
      if (sType === "G2" || sType === "RE") { return "Error"; }
      if (sType === "F2" || sType === "F1") { return "Success"; }
      return "None";
    },

    // ── Number / currency formatters ───────────────────────────────

    /**
     * Formats a raw OData decimal as a short display string.
     * e.g. 1234567.89 → "$1.23M"
     * @param {string|number} vAmount
     * @param {string}        sCurrency
     * @returns {string}
     */
    formatShortAmount: function (vAmount, sCurrency) {
      var fVal = parseFloat(vAmount);
      if (isNaN(fVal)) { return "—"; }
      var sPrefix = (sCurrency === "EUR") ? "€"
                  : (sCurrency === "USD") ? "$"
                  : (sCurrency || "");
      if (Math.abs(fVal) >= 1e9) { return sPrefix + (fVal / 1e9).toFixed(2) + "B"; }
      if (Math.abs(fVal) >= 1e6) { return sPrefix + (fVal / 1e6).toFixed(2) + "M"; }
      if (Math.abs(fVal) >= 1e3) { return sPrefix + (fVal / 1e3).toFixed(1) + "K"; }
      return sPrefix + fVal.toFixed(2);
    },

    /**
     * Percentage formatter — appends % sign.
     * @param {number} fValue
     * @returns {string}
     */
    formatPercent: function (fValue) {
      if (fValue === null || fValue === undefined) { return "—"; }
      return Math.round(parseFloat(fValue)) + "%";
    },

    /**
     * Returns ObjectNumber state based on a percentage vs a threshold.
     * e.g. formatPercentState(87, 90) → "Warning" (below threshold)
     * @param {number} fValue
     * @param {number} fThreshold
     * @returns {string}
     */
    formatPercentState: function (fValue, fThreshold) {
      var f = parseFloat(fValue);
      var t = parseFloat(fThreshold) || 90;
      if (isNaN(f)) { return "None"; }
      if (f >= t)            { return "Success"; }
      if (f >= (t * 0.9))   { return "Warning"; }
      return "Error";
    },

    // ── Date formatters ────────────────────────────────────────────

    /**
     * Returns "X days ago" / "In X days" relative label.
     * @param {string|Date} vDate
     * @returns {string}
     */
    relativeDays: function (vDate) {
      if (!vDate) { return "—"; }
      var oDate = (vDate instanceof Date) ? vDate : new Date(vDate);
      var nDays = Math.round((oDate - new Date()) / 86400000);
      if (nDays === 0)  { return "Today"; }
      if (nDays === -1) { return "Yesterday"; }
      if (nDays === 1)  { return "Tomorrow"; }
      if (nDays < 0)    { return Math.abs(nDays) + " days ago"; }
      return "In " + nDays + " days";
    },

    /**
     * Returns ObjectStatus state for a date (overdue = Error, soon = Warning, future = None).
     * @param {string|Date} vDate
     * @param {number}      nWarnDays  days before due that triggers Warning (default 7)
     * @returns {string}
     */
    dueDateState: function (vDate, nWarnDays) {
      if (!vDate) { return "None"; }
      var oDate = (vDate instanceof Date) ? vDate : new Date(vDate);
      var nDays = Math.round((oDate - new Date()) / 86400000);
      var nWarn = typeof nWarnDays === "number" ? nWarnDays : 7;
      if (nDays < 0)            { return "Error"; }
      if (nDays <= nWarn)       { return "Warning"; }
      return "None";
    },

    // ── Visibility helpers ─────────────────────────────────────────

    /**
     * Returns true if a string value is non-empty (for visibility bindings).
     * @param {string} sValue
     * @returns {boolean}
     */
    isNotEmpty: function (sValue) {
      return !!(sValue && sValue.trim && sValue.trim() !== "" && sValue !== "—");
    },

    /**
     * Returns true if an array has items (for list empty-state visibility).
     * @param {Array} aItems
     * @returns {boolean}
     */
    hasItems: function (aItems) {
      return Array.isArray(aItems) && aItems.length > 0;
    },

    /**
     * Negates a boolean (for inverse visibility bindings).
     * @param {boolean} bValue
     * @returns {boolean}
     */
    not: function (bValue) {
      return !bValue;
    },

    // ── Icon helpers ───────────────────────────────────────────────

    /**
     * Returns a trend icon based on numeric change.
     * @param {number} fChange
     * @returns {string}  sap-icon://... URI
     */
    trendIcon: function (fChange) {
      var f = parseFloat(fChange);
      if (isNaN(f)) { return "sap-icon://status-inactive"; }
      if (f > 0)    { return "sap-icon://trend-up"; }
      if (f < 0)    { return "sap-icon://trend-down"; }
      return "sap-icon://status-inactive";
    },

    /**
     * Returns color for a trend icon.
     * @param {number} fChange
     * @param {boolean} bInverseGood  true if UP is bad (e.g. returns, overdue count)
     * @returns {string}
     */
    trendColor: function (fChange, bInverseGood) {
      var f = parseFloat(fChange);
      if (isNaN(f)) { return "Neutral"; }
      var bUp = f > 0;
      if (bInverseGood) { bUp = !bUp; }
      return bUp ? "Positive" : "Critical";
    },

    /**
     * Maps alert priority string → sap.ui.core.MessageType for MessageItem.
     * @param {string} sPriority  "High" | "Medium" | "Low"
     * @returns {string}
     */
    alertPriorityType: function (sPriority) {
      var mMap = { "High": "Error", "Medium": "Warning", "Low": "Information" };
      return mMap[sPriority] || "None";
    }
  };
});
