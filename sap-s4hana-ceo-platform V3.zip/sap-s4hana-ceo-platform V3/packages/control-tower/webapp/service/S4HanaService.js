/**
 * S4HanaService.js
 * Central service layer — all S/4HANA OData calls live here.
 * Controllers call these methods and receive Promises; no OData
 * plumbing leaks into view controllers.
 *
 * APIs used:
 *   procurement  → MM_PUR_PO_MAINT_V2_SRV
 *   sales        → SD_F1493_SALESORDER_MANAGE_SRV
 *   bp           → API_BUSINESS_PARTNER
 *   billing      → SD_INVOICE_POST_SRV
 */
sap.ui.define([
  "sap/ui/base/Object",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/Sorter"
], function (BaseObject, Filter, FilterOperator, Sorter) {
  "use strict";

  return BaseObject.extend("com.company.controltower.service.S4HanaService", {

    /**
     * @param {sap.ui.core.UIComponent} oComponent  owner component
     */
    constructor: function (oComponent) {
      this._oComponent  = oComponent;
      this._oProcModel  = oComponent.getModel("procurement");
      this._oSalesModel = oComponent.getModel("sales");
      this._oBPModel    = oComponent.getModel("bp");
      this._oBillingModel = oComponent.getModel("billing");
    },

    // ─────────────────────────────────────────────────────────────
    // PROCUREMENT  (MM_PUR_PO_MAINT_V2_SRV)
    // ─────────────────────────────────────────────────────────────

    /**
     * Fetch open / overdue purchase orders.
     * EntitySet : PurchaseOrders
     * Key fields : PurchaseOrder
     */
    getPurchaseOrders: function (oParams) {
      oParams = oParams || {};
      var aFilters = [];

      // Fiscal-year filter
      if (oParams.fiscalYear) {
        aFilters.push(new Filter("PurchasingDocumentDate",
          FilterOperator.GE, new Date(oParams.fiscalYear + "-01-01")));
        aFilters.push(new Filter("PurchasingDocumentDate",
          FilterOperator.LE, new Date(oParams.fiscalYear + "-12-31")));
      }

      // Overdue only flag
      if (oParams.overdueOnly) {
        aFilters.push(new Filter("ScheduleLineDeliveryDate",
          FilterOperator.LT, new Date()));
        aFilters.push(new Filter("PurchaseOrderStatus",
          FilterOperator.NE, "C")); // exclude Closed
      }

      // Status filter (B=Blocked, etc.)
      if (oParams.status) {
        aFilters.push(new Filter("PurchaseOrderStatus",
          FilterOperator.EQ, oParams.status));
      }

      return this._read(this._oProcModel, "/PurchaseOrders", {
        filters: aFilters,
        urlParameters: {
          "$top":     oParams.top    || "200",
          "$orderby": oParams.orderby || "NetPurchaseOrderAmount desc",
          "$select":  [
            "PurchaseOrder",
            "Supplier",
            "SupplierName",
            "PurchasingOrganization",
            "PurchasingGroup",
            "NetPurchaseOrderAmount",
            "DocumentCurrency",
            "PurchaseOrderDate",
            "PurchasingDocumentDate",
            "PurchaseOrderStatus",
            "GoodsReceiptIsExpected",
            "GoodsReceiptIsNonValuated",
            "InvoiceIsExpected",
            "CompanyCode"
          ].join(",")
        }
      });
    },

    /**
     * Fetch PO items for overdue / blocked analysis.
     * EntitySet : PurchaseOrderItems
     */
    getPurchaseOrderItems: function (oParams) {
      oParams = oParams || {};
      var aFilters = [];

      if (oParams.purchaseOrder) {
        aFilters.push(new Filter("PurchaseOrder",
          FilterOperator.EQ, oParams.purchaseOrder));
      }

      // Items past schedule line delivery date
      if (oParams.overdueOnly) {
        aFilters.push(new Filter("ScheduleLineDeliveryDate",
          FilterOperator.LT, new Date()));
      }

      return this._read(this._oProcModel, "/PurchaseOrderItems", {
        filters: aFilters,
        urlParameters: {
          "$top":    oParams.top || "500",
          "$select": [
            "PurchaseOrder",
            "PurchaseOrderItem",
            "Material",
            "MaterialGroup",
            "PurchaseOrderItemText",
            "OrderQuantity",
            "NetPriceAmount",
            "DocumentCurrency",
            "GoodsReceiptQuantity",
            "InvoiceQuantity",
            "ScheduleLineDeliveryDate",
            "PurchaseOrderStatus"
          ].join(",")
        }
      });
    },

    /**
     * KPI: count open POs, overdue POs, blocked POs.
     * Uses $inlinecount to avoid fetching all records.
     */
    getPOKPIs: function (sFiscalYear) {
      var sYear = sFiscalYear || new Date().getFullYear().toString();
      var oDateFrom = new Date(sYear + "-01-01");
      var oDateTo   = new Date(sYear + "-12-31");
      var oToday    = new Date();

      // Parallel reads — open, overdue, blocked
      var pOpen = this._read(this._oProcModel, "/PurchaseOrders", {
        urlParameters: {
          "$inlinecount": "allpages",
          "$top": "0",
          "$filter": "PurchaseOrderStatus ne 'C' and PurchasingDocumentDate ge datetime'" +
                     oDateFrom.toISOString().slice(0,10) + "T00:00:00' and " +
                     "PurchasingDocumentDate le datetime'" + oDateTo.toISOString().slice(0,10) + "T23:59:59'"
        }
      });

      var pOverdue = this._read(this._oProcModel, "/PurchaseOrderItems", {
        urlParameters: {
          "$inlinecount": "allpages",
          "$top": "0",
          "$filter": "ScheduleLineDeliveryDate lt datetime'" +
                     oToday.toISOString().slice(0,10) + "T00:00:00' and " +
                     "PurchaseOrderStatus ne 'C'"
        }
      });

      var pBlocked = this._read(this._oProcModel, "/PurchaseOrders", {
        urlParameters: {
          "$inlinecount": "allpages",
          "$top": "0",
          "$filter": "PurchaseOrderStatus eq 'B'"
        }
      });

      return Promise.all([pOpen, pOverdue, pBlocked]);
    },

    /**
     * Fetch purchase requisitions.
     * EntitySet : PurchaseRequisitions
     */
    getPurchaseRequisitions: function (oParams) {
      oParams = oParams || {};
      var aFilters = [];
      if (oParams.status) {
        aFilters.push(new Filter("PurchaseRequisitionStatus",
          FilterOperator.EQ, oParams.status));
      }
      return this._read(this._oProcModel, "/PurchaseRequisitions", {
        filters: aFilters,
        urlParameters: {
          "$top":    oParams.top || "100",
          "$select": [
            "PurchaseRequisition",
            "PurchaseRequisitionStatus",
            "Material",
            "MaterialGroup",
            "TotalNetAmount",
            "DocumentCurrency",
            "RequisitionerName",
            "PurchasingGroup",
            "CreationDate"
          ].join(",")
        }
      });
    },

    // ─────────────────────────────────────────────────────────────
    // SALES  (SD_F1493_SALESORDER_MANAGE_SRV)
    // ─────────────────────────────────────────────────────────────

    /**
     * Fetch sales orders.
     * EntitySet : SalesOrders
     * Key fields : SalesOrder
     */
    getSalesOrders: function (oParams) {
      oParams = oParams || {};
      var aFilters = [];

      if (oParams.dateFrom) {
        aFilters.push(new Filter("SalesOrderDate",
          FilterOperator.GE, oParams.dateFrom));
      }
      if (oParams.dateTo) {
        aFilters.push(new Filter("SalesOrderDate",
          FilterOperator.LE, oParams.dateTo));
      }
      if (oParams.salesOrg) {
        aFilters.push(new Filter("SalesOrganization",
          FilterOperator.EQ, oParams.salesOrg));
      }
      if (oParams.overallStatus) {
        aFilters.push(new Filter("OverallSDProcessStatus",
          FilterOperator.EQ, oParams.overallStatus));
      }
      if (oParams.blocked) {
        // C = Completely Blocked
        aFilters.push(new Filter("SalesOrderBlockingReasonCode",
          FilterOperator.NE, ""));
      }

      return this._read(this._oSalesModel, "/SalesOrders", {
        filters: aFilters,
        urlParameters: {
          "$top":     oParams.top || "200",
          "$orderby": oParams.orderby || "SalesOrderDate desc",
          "$select":  [
            "SalesOrder",
            "SalesOrderType",
            "SalesOrganization",
            "DistributionChannel",
            "OrganizationDivision",
            "SoldToParty",
            "SoldToPartyName",
            "ShipToParty",
            "TotalNetAmount",
            "TransactionCurrency",
            "SalesOrderDate",
            "RequestedDeliveryDate",
            "OverallSDProcessStatus",
            "OverallDeliveryStatus",
            "OverallBillingStatus",
            "SalesOrderBlockingReasonCode",
            "IncotermsClassification",
            "CustomerPaymentTerms"
          ].join(",")
        }
      });
    },

    /**
     * Fetch sales order items for revenue aggregation.
     * EntitySet : SalesOrderItems
     */
    getSalesOrderItems: function (oParams) {
      oParams = oParams || {};
      var aFilters = [];
      if (oParams.salesOrder) {
        aFilters.push(new Filter("SalesOrder",
          FilterOperator.EQ, oParams.salesOrder));
      }
      if (oParams.material) {
        aFilters.push(new Filter("Material",
          FilterOperator.EQ, oParams.material));
      }
      return this._read(this._oSalesModel, "/SalesOrderItems", {
        filters: aFilters,
        urlParameters: {
          "$top":    oParams.top || "500",
          "$select": [
            "SalesOrder",
            "SalesOrderItem",
            "Material",
            "MaterialGroup",
            "SalesOrderItemText",
            "RequestedQuantity",
            "NetAmount",
            "TransactionCurrency",
            "StorageLocation",
            "DeliveryDate"
          ].join(",")
        }
      });
    },

    /**
     * KPI counts for sales overview.
     */
    getSalesKPIs: function (oDateFrom, oDateTo) {
      var sFrom = this._toODataDate(oDateFrom || this._monthStart());
      var sTo   = this._toODataDate(oDateTo   || new Date());

      var pOpen = this._read(this._oSalesModel, "/SalesOrders", {
        urlParameters: {
          "$inlinecount": "allpages",
          "$top": "0",
          "$filter": "SalesOrderDate ge datetime'" + sFrom + "' and " +
                     "SalesOrderDate le datetime'" + sTo   + "' and " +
                     "OverallSDProcessStatus ne 'C'"
        }
      });

      var pBlocked = this._read(this._oSalesModel, "/SalesOrders", {
        urlParameters: {
          "$inlinecount": "allpages",
          "$top": "0",
          "$filter": "SalesOrderBlockingReasonCode ne '' and " +
                     "SalesOrderDate ge datetime'" + sFrom + "'"
        }
      });

      return Promise.all([pOpen, pBlocked]);
    },

    /**
     * Top customers by net order value (YTD).
     * Reads SalesOrders, groups client-side by SoldToParty.
     */
    getTopCustomers: function (sYear) {
      sYear = sYear || new Date().getFullYear().toString();
      return this._read(this._oSalesModel, "/SalesOrders", {
        urlParameters: {
          "$top":     "1000",
          "$orderby": "TotalNetAmount desc",
          "$filter":  "SalesOrderDate ge datetime'" + sYear + "-01-01T00:00:00'",
          "$select":  [
            "SoldToParty",
            "SoldToPartyName",
            "SalesOrganization",
            "TotalNetAmount",
            "TransactionCurrency",
            "OverallSDProcessStatus",
            "CustomerPaymentTerms"
          ].join(",")
        }
      });
    },

    // ─────────────────────────────────────────────────────────────
    // BUSINESS PARTNER / SUPPLIERS  (API_BUSINESS_PARTNER)
    // ─────────────────────────────────────────────────────────────

    /**
     * Fetch supplier master data.
     * EntitySet : A_Supplier
     * Key fields : Supplier
     */
    getSuppliers: function (oParams) {
      oParams = oParams || {};
      var aFilters = [
        new Filter("IsNaturalPerson", FilterOperator.EQ, false)
      ];
      if (oParams.supplierAccountGroup) {
        aFilters.push(new Filter("SupplierAccountGroup",
          FilterOperator.EQ, oParams.supplierAccountGroup));
      }
      if (oParams.country) {
        aFilters.push(new Filter("Country", FilterOperator.EQ, oParams.country));
      }
      if (oParams.isBlocked !== undefined) {
        aFilters.push(new Filter("IsBlockedForPosting",
          FilterOperator.EQ, oParams.isBlocked));
      }

      return this._read(this._oBPModel, "/A_Supplier", {
        filters: aFilters,
        urlParameters: {
          "$top":    oParams.top || "200",
          "$select": [
            "Supplier",
            "SupplierName",
            "SupplierFullName",
            "Country",
            "Region",
            "CityName",
            "Industry",
            "SupplierAccountGroup",
            "CreationDate",
            "IsBlockedForPosting",
            "PaymentTerms",
            "PurchasingIsBlocked",
            "PostingIsBlocked"
          ].join(",")
        }
      });
    },

    /**
     * Fetch supplier purchasing data (delivery performance per vendor).
     * EntitySet : A_SupplierPurchasingOrg
     */
    getSupplierPurchasingData: function (oParams) {
      oParams = oParams || {};
      var aFilters = [];
      if (oParams.purchasingOrg) {
        aFilters.push(new Filter("PurchasingOrganization",
          FilterOperator.EQ, oParams.purchasingOrg));
      }
      if (oParams.supplier) {
        aFilters.push(new Filter("Supplier",
          FilterOperator.EQ, oParams.supplier));
      }

      return this._read(this._oBPModel, "/A_SupplierPurchasingOrg", {
        filters: aFilters,
        urlParameters: {
          "$top":    oParams.top || "200",
          "$select": [
            "Supplier",
            "PurchasingOrganization",
            "PaymentTerms",
            "IncotermsClassification",
            "IncotermsTransferLocation",
            "MinimumOrderAmount",
            "PricingDateControl",
            "IsGoodsReceiptBased"
          ].join(","),
          "$expand": "to_PartnerFunction"
        }
      });
    },

    /**
     * Fetch business partner general data.
     * EntitySet : A_BusinessPartner
     */
    getBusinessPartners: function (oParams) {
      oParams = oParams || {};
      var aFilters = [];
      if (oParams.category) {
        aFilters.push(new Filter("BusinessPartnerCategory",
          FilterOperator.EQ, oParams.category));
      }

      return this._read(this._oBPModel, "/A_BusinessPartner", {
        filters: aFilters,
        urlParameters: {
          "$top":    oParams.top || "200",
          "$select": [
            "BusinessPartner",
            "BusinessPartnerFullName",
            "BusinessPartnerCategory",
            "BusinessPartnerGrouping",
            "Industry",
            "LegalForm",
            "OrganizationBPName1",
            "Country",
            "RegionGroup",
            "CreationDate",
            "IsBlocked"
          ].join(",")
        }
      });
    },

    // ─────────────────────────────────────────────────────────────
    // BILLING / INVOICES  (SD_INVOICE_POST_SRV)
    // ─────────────────────────────────────────────────────────────

    /**
     * Fetch billing documents for revenue calculation.
     * EntitySet : BillingDocument
     */
    getBillingDocuments: function (oParams) {
      oParams = oParams || {};
      var aFilters = [];

      if (oParams.dateFrom) {
        aFilters.push(new Filter("BillingDocumentDate",
          FilterOperator.GE, oParams.dateFrom));
      }
      if (oParams.dateTo) {
        aFilters.push(new Filter("BillingDocumentDate",
          FilterOperator.LE, oParams.dateTo));
      }
      if (oParams.type) {
        // F2 = Invoice, G2 = Credit Memo
        aFilters.push(new Filter("BillingDocumentType",
          FilterOperator.EQ, oParams.type));
      }
      if (oParams.salesOrg) {
        aFilters.push(new Filter("SalesOrganization",
          FilterOperator.EQ, oParams.salesOrg));
      }

      return this._read(this._oBillingModel, "/BillingDocument", {
        filters: aFilters,
        urlParameters: {
          "$top":     oParams.top || "500",
          "$orderby": "BillingDocumentDate desc",
          "$select":  [
            "BillingDocument",
            "BillingDocumentType",
            "SalesOrganization",
            "BillingDocumentDate",
            "SoldToParty",
            "SoldToPartyName",
            "TotalNetAmount",
            "TransactionCurrency",
            "OverallBillingStatus"
          ].join(",")
        }
      });
    },

    // ─────────────────────────────────────────────────────────────
    // HELPER UTILITIES
    // ─────────────────────────────────────────────────────────────

    /**
     * Aggregates an array of OData records by a key field,
     * summing a numeric amount field.
     * Returns sorted array [{key, label, total, count}]
     */
    aggregateByKey: function (aRecords, sKeyField, sLabelField, sAmountField) {
      var oMap = {};
      aRecords.forEach(function (oRec) {
        var sKey   = oRec[sKeyField]   || "UNKNOWN";
        var sLabel = oRec[sLabelField] || sKey;
        var fAmt   = parseFloat(oRec[sAmountField]) || 0;
        if (!oMap[sKey]) {
          oMap[sKey] = { key: sKey, label: sLabel, total: 0, count: 0 };
        }
        oMap[sKey].total += fAmt;
        oMap[sKey].count += 1;
      });
      return Object.values(oMap)
        .sort(function (a, b) { return b.total - a.total; });
    },

    /**
     * Formats a raw OData amount to a display string with currency.
     */
    formatAmount: function (fAmount, sCurrency) {
      if (fAmount === null || fAmount === undefined) { return "—"; }
      var fVal = parseFloat(fAmount);
      var sPrefix = (sCurrency === "EUR") ? "€" : (sCurrency === "USD") ? "$" : (sCurrency || "");
      if (Math.abs(fVal) >= 1e9) { return sPrefix + (fVal / 1e9).toFixed(2) + "B"; }
      if (Math.abs(fVal) >= 1e6) { return sPrefix + (fVal / 1e6).toFixed(2) + "M"; }
      if (Math.abs(fVal) >= 1e3) { return sPrefix + (fVal / 1e3).toFixed(1) + "K"; }
      return sPrefix + fVal.toFixed(2);
    },

    /**
     * Derives ObjectStatus state from a PO / SO status code.
     */
    deriveStatusState: function (sStatus) {
      switch (sStatus) {
        case "C":  return "Success";   // Closed / Completed
        case "B":  return "Error";     // Blocked
        case "A":  return "Warning";   // In Process / Partially
        default:   return "None";
      }
    },

    /**
     * Returns the first day of the current calendar month.
     */
    _monthStart: function () {
      var d = new Date();
      return new Date(d.getFullYear(), d.getMonth(), 1);
    },

    /**
     * Returns "YYYY-MM-DDT00:00:00" for an OData datetime literal.
     */
    _toODataDate: function (oDate) {
      return oDate.toISOString().slice(0, 10) + "T00:00:00";
    },

    /**
     * Generic promisified OData read.
     * @returns {Promise<{results: Array, __count: string}>}
     */
    _read: function (oModel, sPath, oOptions) {
      return new Promise(function (resolve, reject) {
        oModel.read(sPath, {
          filters:       oOptions.filters       || [],
          sorters:       oOptions.sorters        || [],
          urlParameters: oOptions.urlParameters || {},
          success: function (oData) { resolve(oData); },
          error:   function (oError) {
            var sMsg = (oError.responseText)
              ? JSON.parse(oError.responseText).error.message.value
              : oError.message;
            reject(new Error(sPath + " → " + sMsg));
          }
        });
      });
    }
  });
});
