---
name: Bug Report
about: Something isn't working correctly
title: '[BUG] '
labels: bug
assignees: ''
---

## Describe the bug
A clear description of what the bug is.

## Which package?
- [ ] `packages/control-tower` — CEO Dashboard
- [ ] `packages/logistics-delay-lib` — Delay Library
- [ ] Both

## Which tab / component?
- [ ] Overview tab
- [ ] Procurement tab
- [ ] Sales & Revenue tab
- [ ] Suppliers tab
- [ ] Logistics tab (TrackCargo)
- [ ] Alerts tab
- [ ] DelayMonitor control
- [ ] RulesEditor control
- [ ] DelaySimulator control
- [ ] RulesEngine (JS service)

## Steps to reproduce
1.
2.
3.

## Expected behaviour
What you expected to happen.

## Actual behaviour
What actually happened.

## Screenshots / console errors
Paste browser console errors here (F12 → Console):

```
paste errors here
```

## Environment
- SAP UI5 version: (check in browser console: `sap.ui.version`)
- Browser:
- BTP region: (e.g. us10, eu10)
- S/4HANA version: (e.g. 2022 FPS02)

## Additional context
Any other information that might be relevant.
