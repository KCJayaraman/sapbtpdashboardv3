sap.ui.define([
  "./BaseController",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/Sorter",
  "sap/ui/model/json/JSONModel",
  "sap/ui/export/library"
], function (BaseController, Filter, FilterOperator, Sorter,
             JSONModel, exportLibrary) {
  "use strict";

  var EdmType = exportLibrary.EdmType;

  return BaseController.extend("com.company.controltower.controller.Sales", {

    onInit: function () {
      BaseController.prototype.onInit.apply(this, arguments);
      this.getOwnerComponent().getRouter()
        .getRoute("sales")
        .attachPatternMatched(this._loadData, this);

      // Local model for aggregated customer data (not directly OData-bindable)
      this._oAggModel = new JSONModel({ customers: [], salesByOrg: [] });
      this.getView().setModel(this._oAggModel, "agg");
    },

    // ── Main loader ───────────────────────────────────────────────
    _loadData: function () {
      this.setBusy(true, "Sales");
      var oSvc  = this._oService;
      var oUI   = this.getUIModel();
      var oNow  = new Date();
      var oMonthStart = new Date(oNow.getFullYear(), oNow.getMonth(), 1);
      var sYear = oNow.getFullYear().toString();

      // 1. MTD billing revenue + avg order value
      var pRev = oSvc.getBillingDocuments({
        dateFrom: oMonthStart,
        dateTo:   oNow,
        type:     "F2",
        top:      "2000"
      }).then(function (oData) {
        var fRev = 0;
        oData.results.forEach(function (d) {
          fRev += parseFloat(d.TotalNetAmount) || 0;
        });
        var fAvg = oData.results.length ? fRev / oData.results.length : 0;

        oUI.setProperty("/kpis/totalRevenue",
          oSvc.formatAmount(fRev, "USD"));
        oUI.setProperty("/kpis/avgOrderValue",
          oSvc.formatAmount(fAvg, "USD"));

        // Revenue by sales org (aggregate billing docs)
        var aByOrg = oSvc.aggregateByKey(
          oData.results,
          "SalesOrganization",
          "SalesOrganization",
          "TotalNetAmount"
        );
        var fOrgTotal = aByOrg.reduce(function (s, o) { return s + o.total; }, 0);
        var aOrgRows  = aByOrg.map(function (o) {
          return {
            org:     o.key,
            total:   oSvc.formatAmount(o.total, "USD"),
            percent: Math.round((o.total / fOrgTotal) * 100)
          };
        });
        oUI.setProperty("/salesByOrg", aOrgRows);
      });

      // 2. Open sales order count
      var pSO = oSvc.getSalesKPIs(oMonthStart, oNow)
        .then(function (aR) {
          oUI.setProperty("/kpis/openOrders",
            parseInt(aR[0].__count || 0).toLocaleString());
        });

      // 3. Returns (credit memo billing type G2)
      var pReturns = oSvc.getBillingDocuments({
        dateFrom: oMonthStart,
        dateTo:   oNow,
        type:     "G2",
        top:      "1000"
      }).then(function (oData) {
        oUI.setProperty("/kpis/orderReturns",
          (oData.results ? oData.results.length : 0).toLocaleString());
      });

      // 4. On-time delivery rate
      //    Delivered on time = RequestedDeliveryDate >= ActualGoodsMovementDate
      //    Approximated: OverallDeliveryStatus = 'C' within date window
      var pOTD = oSvc.getSalesOrders({
        dateFrom: oMonthStart,
        dateTo:   oNow,
        top:      "1000"
      }).then(function (oData) {
        var nTotal  = oData.results.length;
        var nOnTime = oData.results.filter(function (oSO) {
          return oSO.OverallDeliveryStatus === "C";
        }).length;
        var fRate = nTotal ? Math.round((nOnTime / nTotal) * 100) : 0;
        oUI.setProperty("/kpis/onTimeDelivery", fRate + "%");

        // Build SO pipeline by OverallSDProcessStatus
        var oStageMap = { "": 0, "A": 0, "B": 0, "C": 0 };
        oData.results.forEach(function (o) {
          var s = o.OverallSDProcessStatus || "";
          if (oStageMap[s] !== undefined) { oStageMap[s]++; }
        });
        var aStagePipeline = [
          { stage: "Open",       count: oStageMap[""],  status: "None",    percent: 0 },
          { stage: "In Process", count: oStageMap["A"], status: "None",    percent: 0 },
          { stage: "Partially",  count: oStageMap["B"], status: "Warning", percent: 0 },
          { stage: "Completed",  count: oStageMap["C"], status: "Success", percent: 0 }
        ];
        aStagePipeline.forEach(function (o) {
          o.percent = nTotal ? Math.round((o.count / nTotal) * 100) : 0;
        });
        oUI.setProperty("/soPipeline", aStagePipeline);
      });

      // 5. Top customers (YTD) — aggregate by SoldToParty
      var pCust = oSvc.getTopCustomers(sYear)
        .then(function (oData) {
          var aAgg = oSvc.aggregateByKey(
            oData.results,
            "SoldToParty",
            "SoldToPartyName",
            "TotalNetAmount"
          ).slice(0, 15);

          // Enrich with order count
          var oCountMap = {};
          oData.results.forEach(function (o) {
            oCountMap[o.SoldToParty] = (oCountMap[o.SoldToParty] || 0) + 1;
          });

          var aCustomers = aAgg.map(function (o) {
            return {
              SoldToParty:     o.key,
              SoldToPartyName: o.label,
              revenueYTD:      oSvc.formatAmount(o.total, "USD"),
              revenueRaw:      o.total,
              orderCount:      (oCountMap[o.key] || 0).toString(),
              salesOrg:        ""    // populated below if needed
            };
          });
          this._oAggModel.setProperty("/customers", aCustomers);
        }.bind(this));

      // 6. Bind SO table directly to OData
      this._bindSOTable();

      Promise.all([pRev, pSO, pReturns, pOTD, pCust])
        .then(function () {
          this.setBusy(false, "Sales");
          oUI.setProperty("/lastRefresh", new Date().toLocaleTimeString());
        }.bind(this))
        .catch(function (oErr) {
          this.setBusy(false, "Sales");
          this._handleError(oErr, "Sales load");
        }.bind(this));
    },

    // ── Bind Sales Orders table directly to OData ─────────────────
    _bindSOTable: function () {
      var oTable = this.byId("soTable");
      if (!oTable) { return; }

      var oMonthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);

      oTable.bindItems({
        model:   "sales",
        path:    "/SalesOrders",
        filters: [
          new Filter("SalesOrderDate",
            FilterOperator.GE, oMonthStart),
          new Filter("OverallSDProcessStatus",
            FilterOperator.NE, "C")
        ],
        sorter:  new Sorter("TotalNetAmount", true),
        parameters: {
          select: [
            "SalesOrder",
            "SoldToParty",
            "SoldToPartyName",
            "SalesOrganization",
            "TotalNetAmount",
            "TransactionCurrency",
            "SalesOrderDate",
            "RequestedDeliveryDate",
            "OverallSDProcessStatus",
            "OverallDeliveryStatus",
            "SalesOrderBlockingReasonCode"
          ].join(","),
          top: "100"
        }
      });
    },

    // ── Search ────────────────────────────────────────────────────
    onSOSearch: function (oEvent) {
      var sQuery   = oEvent.getParameter("query");
      var oTable   = this.byId("soTable");
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }

      var oMonthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
      var aBase = [new Filter("SalesOrderDate", FilterOperator.GE, oMonthStart)];

      if (sQuery) {
        aBase.push(new Filter({
          filters: [
            new Filter("SalesOrder",       FilterOperator.Contains, sQuery),
            new Filter("SoldToPartyName",  FilterOperator.Contains, sQuery),
            new Filter("SoldToParty",      FilterOperator.Contains, sQuery)
          ],
          and: false
        }));
      }
      oBinding.filter(aBase);
    },

    onCustomerSearch: function (oEvent) {
      var sQuery = oEvent.getParameter("query").toLowerCase();
      var aAll   = this._oAggModel.getProperty("/customers") || [];
      if (!sQuery) {
        this._oAggModel.setProperty("/customers", aAll);
        return;
      }
      var aFiltered = aAll.filter(function (o) {
        return (o.SoldToPartyName || "").toLowerCase().includes(sQuery) ||
               (o.SoldToParty    || "").toLowerCase().includes(sQuery);
      });
      this._oAggModel.setProperty("/customers", aFiltered);
    },

    // ── Status filter ─────────────────────────────────────────────
    onSOStatusFilter: function (oEvent) {
      var sKey   = oEvent.getParameter("item").getKey();
      var oTable = this.byId("soTable");
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }

      var aFilters = [];
      if (sKey !== "ALL") {
        aFilters.push(new Filter("OverallSDProcessStatus",
          FilterOperator.EQ, sKey));
      }
      if (sKey === "BLOCKED") {
        aFilters = [new Filter("SalesOrderBlockingReasonCode",
          FilterOperator.NE, "")];
      }
      oBinding.filter(aFilters);
    },

    // ── Export ────────────────────────────────────────────────────
    onExportSO: function () {
      var oTable = this.byId("soTable");
      if (!oTable) { return; }
      var aData = (oTable.getBinding("items") || { getCurrentContexts: function(){ return []; }})
        .getCurrentContexts().map(function (c) { return c.getObject(); });

      this._exportToExcel(aData, [
        { label: "Sales Order",   property: "SalesOrder",           type: EdmType.String },
        { label: "Customer",      property: "SoldToPartyName",      type: EdmType.String },
        { label: "Customer ID",   property: "SoldToParty",          type: EdmType.String },
        { label: "Sales Org",     property: "SalesOrganization",    type: EdmType.String },
        { label: "Net Amount",    property: "TotalNetAmount",        type: EdmType.Number },
        { label: "Currency",      property: "TransactionCurrency",   type: EdmType.String },
        { label: "Order Date",    property: "SalesOrderDate",        type: EdmType.Date   },
        { label: "Req. Delivery", property: "RequestedDeliveryDate", type: EdmType.Date   },
        { label: "Status",        property: "OverallSDProcessStatus",type: EdmType.String }
      ], "SalesOrders_S4HANA");
    },

    onExportCustomers: function () {
      var aData = this._oAggModel.getProperty("/customers") || [];
      this._exportToExcel(aData, [
        { label: "Customer ID",   property: "SoldToParty",     type: EdmType.String },
        { label: "Customer Name", property: "SoldToPartyName", type: EdmType.String },
        { label: "Revenue YTD",   property: "revenueYTD",      type: EdmType.String },
        { label: "Orders",        property: "orderCount",      type: EdmType.String }
      ], "TopCustomers_S4HANA");
    }
  });
});
