sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/MessageToast",
  "sap/m/MessageBox",
  "sap/ui/export/Spreadsheet",
  "sap/ui/export/library",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "com/company/controltower/service/S4HanaService"
], function (Controller, MessageToast, MessageBox, Spreadsheet,
             exportLibrary, Filter, FilterOperator, S4HanaService) {
  "use strict";

  var EdmType = exportLibrary.EdmType;

  return Controller.extend("com.company.controltower.controller.BaseController", {

    // ── Lifecycle ──────────────────────────────────────────────
    onInit: function () {
      // Instantiate shared service once per controller
      this._oService = new S4HanaService(this.getOwnerComponent());
    },

    // ── Routing helpers ────────────────────────────────────────
    getRouter: function () {
      return this.getOwnerComponent().getRouter();
    },

    navTo: function (sRoute, oParams) {
      this.getRouter().navTo(sRoute, oParams || {});
    },

    // ── Model helpers ──────────────────────────────────────────
    getModel: function (sName) {
      return this.getView().getModel(sName) ||
             this.getOwnerComponent().getModel(sName);
    },

    getUIModel: function () {
      return this.getModel("ui");
    },

    setUIProperty: function (sPath, vValue) {
      this.getUIModel().setProperty(sPath, vValue);
    },

    setBusy: function (bBusy, sKey) {
      var sPath = sKey ? "/busy" + sKey : "/busy";
      this.setUIProperty(sPath, bBusy);
    },

    // ── Refresh/filter bar ─────────────────────────────────────
    onRefresh: function () {
      if (this._loadData) {
        this._loadData();
        MessageToast.show("Refreshing from S/4HANA…");
      }
    },

    _getFilterValues: function () {
      var oFY     = sap.ui.getCore().byId("selFY");
      var oPeriod = sap.ui.getCore().byId("selPeriod");
      var oCC     = sap.ui.getCore().byId("selCC");
      return {
        fiscalYear:  oFY     ? oFY.getSelectedKey()     : new Date().getFullYear().toString(),
        period:      oPeriod ? oPeriod.getSelectedKey()  : "ALL",
        companyCode: oCC     ? oCC.getSelectedKey()      : "ALL"
      };
    },

    // ── Error handling ─────────────────────────────────────────
    _handleError: function (oError, sContext) {
      var sMsg = oError.message || "Unknown error";
      MessageBox.error("S/4HANA API error" + (sContext ? " (" + sContext + ")" : "") + ":\n" + sMsg);
      jQuery.sap.log.error("[ControlTower] " + sContext + ": " + sMsg);
    },

    // ── Number formatting ──────────────────────────────────────
    formatAmount: function (fVal, sCurrency) {
      return this._oService.formatAmount(fVal, sCurrency);
    },

    _calcPercentage: function (fPart, fTotal) {
      if (!fTotal) { return 0; }
      return Math.round((fPart / fTotal) * 100);
    },

    _toDate: function (sIso) {
      return sIso ? new Date(sIso) : new Date();
    },

    // ── Table search ───────────────────────────────────────────
    onTableSearch: function (oEvent, sTableId, aFields) {
      var sQuery   = oEvent.getParameter("query");
      var oTable   = this.byId(sTableId);
      if (!oTable) { return; }
      var oBinding = oTable.getBinding("items");
      if (!oBinding) { return; }
      if (!sQuery) {
        oBinding.filter([]);
        return;
      }
      var aFilters = aFields.map(function (sField) {
        return new Filter(sField, FilterOperator.Contains, sQuery);
      });
      oBinding.filter([new Filter({ filters: aFilters, and: false })]);
    },

    // ── Excel export ───────────────────────────────────────────
    _exportToExcel: function (aData, aColumns, sFileName) {
      var oSettings = {
        workbook:   { columns: aColumns },
        dataSource: aData,
        fileName:   sFileName + "_" + new Date().toISOString().slice(0, 10) + ".xlsx",
        worker:     false
      };
      var oSheet = new Spreadsheet(oSettings);
      oSheet.build()
        .then(function () {
          MessageToast.show("Export complete: " + sFileName + ".xlsx");
        })
        .catch(function (sErr) {
          MessageBox.error("Export failed: " + sErr);
        })
        .finally(function () { oSheet.destroy(); });
    },

    // ── Status helpers (used in formatters / binding) ──────────
    poStatusText: function (sCode) {
      var mMap = { "": "Open", "A": "In Process", "B": "Blocked", "C": "Closed" };
      return mMap[sCode] || sCode;
    },

    poStatusState: function (sCode) {
      var mMap = { "": "None", "A": "Warning", "B": "Error", "C": "Success" };
      return mMap[sCode] || "None";
    },

    soStatusText: function (sCode) {
      var mMap = { "": "Open", "A": "In Process", "B": "Partially", "C": "Completed" };
      return mMap[sCode] || sCode;
    },

    soStatusState: function (sCode) {
      var mMap = { "": "None", "A": "None", "B": "Warning", "C": "Success" };
      return mMap[sCode] || "None";
    },

    // ── Deep-link to Fiori apps ────────────────────────────────
    onPOPress: function (oEvent) {
      var oCtx = oEvent.getSource().getBindingContext("procurement");
      if (!oCtx) { return; }
      var sPO = oCtx.getProperty("PurchaseOrder");
      // In production: use CrossAppNavigation to F0842A
      MessageBox.information(
        "Navigate to Manage Purchase Orders\nPO: " + sPO +
        "\n\nFiori app: F0842A — PurchaseOrder-manage");
    },

    onSOPress: function (oEvent) {
      var oCtx = oEvent.getSource().getBindingContext("sales");
      if (!oCtx) { return; }
      var sSO = oCtx.getProperty("SalesOrder");
      MessageBox.information(
        "Navigate to Manage Sales Orders\nSO: " + sSO +
        "\n\nFiori app: F1347 — SalesOrder-manage");
    },

    onCustomerPress: function (oEvent) {
      var oCtx = oEvent.getSource().getBindingContext("_aggregated");
      var sBP  = oCtx ? oCtx.getProperty("SoldToParty") : "";
      MessageBox.information(
        "Navigate to Customer Factsheet\nBP: " + sBP +
        "\n\nFiori app: F3705 — Customer-displayFactSheet");
    },

    onSupplierPress: function (oEvent) {
      var oCtx = oEvent.getSource().getBindingContext("bp");
      if (!oCtx) { return; }
      var sBP = oCtx.getProperty("Supplier");
      MessageBox.information(
        "Navigate to Supplier Factsheet\nSupplier: " + sBP +
        "\n\nFiori app: F2710 — BusinessPartner-displayFactSheet");
    }
  });
});
