/**
 * RulesEditor.js
 * com.logistics.delaylib.control.RulesEditor
 * ─────────────────────────────────────────────────────────────────────────────
 * SAP UI5 control that renders a full business rules management interface:
 *   - Rules list with enable/disable toggles
 *   - Add / Edit / Delete rule dialogs
 *   - Condition builder (field + operator + value)
 *   - Action configurator
 *   - Import / Export rules as JSON
 *   - Test rule against sample shipment
 *
 * Backed by RulesEngine.js for evaluation.
 *
 * XML usage:
 *   <delaylib:RulesEditor
 *     id="rulesEditor"
 *     title="Logistics Delay Rules"
 *     editable="true"
 *     ruleSave="onRuleSaved"
 *     ruleDelete="onRuleDeleted"
 *     ruleTest="onRuleTested"/>
 * ─────────────────────────────────────────────────────────────────────────────
 */
sap.ui.define([
  "sap/ui/core/Control",
  "sap/ui/model/json/JSONModel",
  "sap/m/VBox",
  "sap/m/HBox",
  "sap/m/Text",
  "sap/m/Title",
  "sap/m/Button",
  "sap/m/ToolbarSpacer",
  "sap/m/Toolbar",
  "sap/m/SearchField",
  "sap/m/List",
  "sap/m/CustomListItem",
  "sap/m/ObjectStatus",
  "sap/m/Switch",
  "sap/m/Dialog",
  "sap/m/Input",
  "sap/m/Select",
  "sap/m/TextArea",
  "sap/m/Label",
  "sap/m/MessageToast",
  "sap/m/MessageBox",
  "sap/m/Table",
  "sap/m/Column",
  "sap/m/ColumnListItem",
  "sap/ui/core/Item",
  "sap/m/SegmentedButton",
  "sap/m/SegmentedButtonItem",
  "sap/m/Panel",
  "sap/m/ObjectIdentifier",
  "com/company/controltower/service/TrackCargoService"
], function (
  Control, JSONModel, VBox, HBox, Text, Title, Button, ToolbarSpacer,
  Toolbar, SearchField, List, CustomListItem, ObjectStatus, Switch,
  Dialog, Input, Select, TextArea, Label, MessageToast, MessageBox,
  Table, Column, ColumnListItem, Item, SegmentedButton, SegmentedButtonItem,
  Panel, ObjectIdentifier
) {
  "use strict";

  var AVAILABLE_FIELDS = [
    { key: "delayDays",        text: "Delay Days"            },
    { key: "mode",             text: "Shipment Mode"         },
    { key: "carrier",          text: "Carrier Name"          },
    { key: "pol",              text: "Port of Loading (POL)" },
    { key: "pod",              text: "Port of Discharge (POD)"},
    { key: "status",           text: "Tracking Status"       },
    { key: "value",            text: "Shipment Value ($)"    },
    { key: "isDelayed",        text: "Is Delayed (boolean)"  },
    { key: "soReference",      text: "Sales Order Reference" },
    { key: "poReference",      text: "PO Reference"          },
    { key: "incoterm",         text: "Incoterm"              },
    { key: "carrierDelayRate", text: "Carrier Delay Rate (%)" },
    { key: "etaDayOfWeek",     text: "ETA Day of Week"       },
    { key: "customerRisk",     text: "Customer Risk Level"   }
  ];

  var AVAILABLE_OPERATORS = [
    { key: "eq",         text: "equals (=)"            },
    { key: "neq",        text: "not equals (≠)"         },
    { key: "gt",         text: "greater than (>)"       },
    { key: "gte",        text: "greater or equal (≥)"   },
    { key: "lt",         text: "less than (<)"          },
    { key: "lte",        text: "less or equal (≤)"      },
    { key: "contains",   text: "contains"               },
    { key: "startsWith", text: "starts with"            },
    { key: "in",         text: "is one of (comma list)" },
    { key: "notIn",      text: "is not one of"          },
    { key: "between",    text: "between (min,max)"      },
    { key: "isNull",     text: "is empty"               },
    { key: "isNotNull",  text: "is not empty"           },
    { key: "isTrue",     text: "is true"                },
    { key: "isFalse",    text: "is false"               }
  ];

  return Control.extend("com.logistics.delaylib.control.RulesEditor", {

    metadata: {
      library: "com.logistics.delaylib",
      properties: {
        title:         { type: "string",  defaultValue: "Business Rules Editor" },
        subtitle:      { type: "string",  defaultValue: "Configure delay detection rules" },
        editable:      { type: "boolean", defaultValue: true  },
        showTestPanel: { type: "boolean", defaultValue: true  },
        showImportExport: { type: "boolean", defaultValue: true }
      },
      aggregations: {
        _content: { type: "sap.ui.core.Control", multiple: false, visibility: "hidden" }
      },
      events: {
        ruleSave:   { parameters: { rule:   { type: "object" } } },
        ruleDelete: { parameters: { ruleId: { type: "string" } } },
        ruleTest:   { parameters: { rule: { type: "object" }, result: { type: "object" } } },
        rulesImport:{ parameters: { rules:  { type: "object" } } }
      }
    },

    init: function () {
      Control.prototype.init.apply(this, arguments);
      this._oLocalModel = new JSONModel({
        rules:        [],
        filteredRules:[],
        editingRule:  null,
        testShipment: {
          orderId: "TEST-001", reference: "BL123456789",
          carrier: "MAEU", mode: "Sea",
          pol: "Hamburg", pod: "Shanghai",
          delayDays: 5, isDelayed: true,
          status: "delayed", value: 150000,
          soReference: "4500012345"
        },
        testResult:   null,
        stats: { total: 0, active: 0, inactive: 0, critical: 0, errors: 0, warnings: 0 }
      });
      this._buildContent();
    },

    renderer: {
      apiVersion: 2,
      render: function (oRm, oControl) {
        oRm.openStart("div", oControl);
        oRm.class("ldlRulesEditor");
        oRm.openEnd();
        oRm.renderControl(oControl.getAggregation("_content"));
        oRm.close("div");
      }
    },

    // ── Public API ─────────────────────────────────────────────────────────

    /**
     * Load rules into the editor from a RulesEngine instance.
     * @param {com.logistics.delaylib.rules.RulesEngine} oEngine
     */
    loadFromEngine: function (oEngine) {
      this._oEngine = oEngine;
      var aRules = oEngine.getRules();
      this._oLocalModel.setProperty("/rules", aRules);
      this._oLocalModel.setProperty("/filteredRules", aRules);
      this._updateStats(aRules);
      return this;
    },

    /**
     * Get the current rules as a plain array.
     * @returns {Array}
     */
    getRules: function () {
      return this._oLocalModel.getProperty("/rules") || [];
    },

    // ── Content build ──────────────────────────────────────────────────────

    _buildContent: function () {
      var that = this;

      // ── Stats bar ──
      var oStatsBar = new HBox({
        alignItems: "Center",
        justifyContent: "SpaceBetween"
      }).addStyleClass("ldlStatsBar");

      ["total","active","inactive","critical","errors","warnings"].forEach(function (sKey) {
        var oTile = new VBox({ alignItems: "Center" }).addStyleClass("ldlStatTile");
        oTile.addItem(new Text({
          text: { path: "/stats/" + sKey, model: "_ldl" }
        }).addStyleClass("ldlStatValue"));
        oTile.addItem(new Text({ text: sKey.charAt(0).toUpperCase() + sKey.slice(1) })
          .addStyleClass("ldlStatLabel"));
        oStatsBar.addItem(oTile);
      });

      // ── Toolbar ──
      var oToolbar = new Toolbar({
        content: [
          new Title({ text: "Rules" }),
          new ToolbarSpacer(),
          new SearchField({
            width: "14rem",
            placeholder: "Search rules…",
            search: function (oEvent) {
              that._filterRules(oEvent.getParameter("query"));
            }
          }),
          new SegmentedButton({
            selectionChange: function (oEvent) {
              that._filterBySeverity(oEvent.getParameter("item").getKey());
            },
            items: [
              new SegmentedButtonItem({ text: "All",      key: "ALL"      }),
              new SegmentedButtonItem({ text: "Critical", key: "Critical" }),
              new SegmentedButtonItem({ text: "Error",    key: "Error"    }),
              new SegmentedButtonItem({ text: "Warning",  key: "Warning"  })
            ]
          }),
          new Button({
            text: "+ Add Rule", type: "Emphasized",
            visible: this.getEditable(),
            press: function () { that._openEditDialog(null); }
          }),
          new Button({
            icon: "sap-icon://upload",    tooltip: "Import Rules JSON",
            press: function () { that._openImportDialog(); }
          }),
          new Button({
            icon: "sap-icon://download",  tooltip: "Export Rules JSON",
            press: function () { that._exportRules(); }
          })
        ]
      });

      // ── Rules table ──
      this._oRulesTable = new Table({
        id:               this.getId() + "--rulesTable",
        alternateRowColors: true,
        sticky:           ["ColumnHeaders"],
        growing:          true,
        growingThreshold: 15,
        noDataText:       "No rules configured. Click '+ Add Rule' to create one.",
        headerToolbar:    oToolbar,
        columns: [
          new Column({ width: "3rem",  header: new Text({ text: "On" })         }),
          new Column({ width: "7rem",  header: new Text({ text: "ID" })          }),
          new Column({                 header: new Text({ text: "Rule Name" })    }),
          new Column({ width: "7rem",  header: new Text({ text: "Severity" })    }),
          new Column({ width: "6rem",  header: new Text({ text: "Mode" })        }),
          new Column({ width: "5rem",  header: new Text({ text: "Conditions" }), hAlign: "Center" }),
          new Column({ width: "4rem",  header: new Text({ text: "Priority" }),   hAlign: "Center" }),
          new Column({ width: "9rem",  header: new Text({ text: "Tags" })        }),
          new Column({ width: "10rem", header: new Text({ text: "Actions" }),    hAlign: "Center" })
        ]
      });

      // Table binding (to local model)
      var that2 = this;
      this._oRulesTable.bindItems({
        path:     "/_ldl>/filteredRules",
        template: this._buildRuleRowTemplate()
      });

      // ── Test panel ──
      this._oTestPanel = new Panel({
        headerText:  "Rule Test Sandbox",
        expandable:  true,
        expanded:    false,
        visible:     this.getShowTestPanel()
      }).addStyleClass("ldlTestPanel");

      this._buildTestPanelContent();

      // ── Root ──
      var oRoot = new VBox({
        items: [ oStatsBar, this._oRulesTable, this._oTestPanel ]
      }).addStyleClass("ldlEditorRoot");

      // Bind local model
      oRoot.setModel(this._oLocalModel, "_ldl");
      this._oRulesTable.setModel(this._oLocalModel, "_ldl");

      this.setAggregation("_content", oRoot);
    },

    _buildRuleRowTemplate: function () {
      var that = this;
      var oRow = new ColumnListItem({ type: "Active" });

      oRow.addCell(new Switch({
        state: "{_ldl>active}",
        change: function (oEvent) {
          var oCtx  = oEvent.getSource().getBindingContext("_ldl");
          var oRule = oCtx.getObject();
          oRule.active = oEvent.getParameter("state");
          if (that._oEngine) {
            that._oEngine.setRuleActive(oRule.id, oRule.active);
          }
          that._updateStats(that._oLocalModel.getProperty("/rules"));
        }
      }));

      oRow.addCell(new Text({ text: "{_ldl>id}" }).addStyleClass("ldlRuleId"));

      oRow.addCell(new ObjectIdentifier({
        title: "{_ldl>name}",
        text:  "{_ldl>description}"
      }));

      oRow.addCell(new ObjectStatus({
        text:  "{_ldl>severity}",
        state: {
          path:      "_ldl>severity",
          formatter: function (s) {
            return s === "Critical" || s === "Error" ? "Error"
                 : s === "Warning" ? "Warning" : "None";
          }
        }
      }));

      oRow.addCell(new Text({ text: "{= ${_ldl>mode} ? ${_ldl>mode}.join(', ') : 'All'}" }));

      oRow.addCell(new Text({
        text: "{= ${_ldl>conditions} ? ${_ldl>conditions}.length : 0 }",
        textAlign: "Center"
      }));

      oRow.addCell(new Text({ text: "{_ldl>priority}", textAlign: "Center" }));

      oRow.addCell(new Text({
        text: "{= ${_ldl>tags} ? ${_ldl>tags}.join(' · ') : '' }"
      }).addStyleClass("ldlTags"));

      // Action buttons
      var oActionBox = new HBox({ alignItems: "Center" });
      if (this.getEditable()) {
        oActionBox.addItem(new Button({
          icon:    "sap-icon://edit",
          tooltip: "Edit rule",
          type:    "Transparent",
          press:   function (oEvent) {
            var oCtx  = oEvent.getSource().getBindingContext("_ldl");
            that._openEditDialog(oCtx.getObject());
          }
        }));
        oActionBox.addItem(new Button({
          icon:    "sap-icon://delete",
          tooltip: "Delete rule",
          type:    "Transparent",
          press:   function (oEvent) {
            var oCtx  = oEvent.getSource().getBindingContext("_ldl");
            var oRule = oCtx.getObject();
            MessageBox.confirm("Delete rule '" + oRule.name + "'?", {
              onClose: function (sAction) {
                if (sAction === MessageBox.Action.OK) {
                  that._deleteRule(oRule.id);
                }
              }
            });
          }
        }));
      }
      oActionBox.addItem(new Button({
        icon:    "sap-icon://play",
        tooltip: "Test rule",
        type:    "Transparent",
        press:   function (oEvent) {
          var oCtx  = oEvent.getSource().getBindingContext("_ldl");
          that._testSingleRule(oCtx.getObject());
        }
      }));
      oRow.addCell(oActionBox);

      return oRow;
    },

    _buildTestPanelContent: function () {
      var that = this;
      var oBox = new VBox({ items: [] }).addStyleClass("ldlTestBox");

      oBox.addItem(new Text({
        text: "Edit the test shipment context below and click 'Run All Rules' to see which rules fire."
      }).addStyleClass("ldlTestHint"));

      this._oTestInput = new TextArea({
        width:  "100%",
        rows:   8,
        value:  JSON.stringify(this._oLocalModel.getProperty("/testShipment"), null, 2)
      }).addStyleClass("ldlTestInput");

      var oRunBtn = new Button({
        text:  "Run All Rules Against Test Shipment",
        type:  "Emphasized",
        icon:  "sap-icon://play",
        press: function () { that._runTestBatch(); }
      });

      this._oTestResultBox = new VBox({}).addStyleClass("ldlTestResult");

      oBox.addItem(this._oTestInput);
      oBox.addItem(oRunBtn);
      oBox.addItem(this._oTestResultBox);

      this._oTestPanel.addContent(oBox);
    },

    // ── Edit dialog ────────────────────────────────────────────────────────

    _openEditDialog: function (oRule) {
      var that     = this;
      var bNew     = !oRule;
      var oWorking = oRule ? JSON.parse(JSON.stringify(oRule)) : {
        id: "RULE_" + Date.now(), name: "", description: "",
        active: true, severity: "Warning", priority: 50,
        mode: ["All"], conditionLogic: "AND",
        conditions: [{ field: "delayDays", operator: "gt", value: 3 }],
        actions: [{ type: "alert", message: "", target: "CEO_DASHBOARD" }],
        tags: []
      };

      var oDialog = new Dialog({
        title:          bNew ? "Add New Rule" : "Edit Rule: " + oWorking.name,
        contentWidth:   "600px",
        resizable:      true,
        draggable:      true,
        content: [
          new VBox({ items: [] }).addStyleClass("ldlDialogForm")
        ],
        beginButton: new Button({
          text: "Save Rule", type: "Emphasized",
          press: function () {
            that._saveRule(oWorking, oDialog, bNew);
          }
        }),
        endButton: new Button({
          text: "Cancel",
          press: function () { oDialog.close(); oDialog.destroy(); }
        })
      });

      var oForm = oDialog.getContent()[0];
      this._buildRuleForm(oForm, oWorking);
      oDialog.open();
    },

    _buildRuleForm: function (oForm, oWorking) {
      var that = this;

      var addField = function (sLabel, oControl) {
        oForm.addItem(new Label({ text: sLabel, required: true }).addStyleClass("ldlFormLabel"));
        oForm.addItem(oControl);
      };

      addField("Rule ID", new Input({ value: oWorking.id, liveChange: function (e) { oWorking.id = e.getParameter("value"); }}));
      addField("Rule Name", new Input({ value: oWorking.name, liveChange: function (e) { oWorking.name = e.getParameter("value"); }}));
      addField("Description", new Input({ value: oWorking.description, liveChange: function (e) { oWorking.description = e.getParameter("value"); }}));

      var oSeveritySelect = new Select({ width: "12rem", selectedKey: oWorking.severity,
        change: function (e) { oWorking.severity = e.getParameter("selectedItem").getKey(); }
      });
      ["Info","Warning","Error","Critical"].forEach(function (s) {
        oSeveritySelect.addItem(new Item({ key: s, text: s }));
      });
      addField("Severity", oSeveritySelect);

      addField("Priority (lower = higher priority)",
        new Input({ type: "Number", value: oWorking.priority, liveChange: function (e) { oWorking.priority = parseInt(e.getParameter("value")) || 50; }}));

      addField("Tags (comma-separated)",
        new Input({ value: (oWorking.tags || []).join(", "),
          liveChange: function (e) {
            oWorking.tags = e.getParameter("value").split(",").map(function (t) { return t.trim(); }).filter(Boolean);
          }
        })
      );

      oForm.addItem(new Label({ text: "Condition Logic" }).addStyleClass("ldlFormLabel"));
      var oLogicSeg = new SegmentedButton({
        selectedKey: oWorking.conditionLogic || "AND",
        selectionChange: function (e) { oWorking.conditionLogic = e.getParameter("item").getKey(); },
        items: [
          new SegmentedButtonItem({ text: "AND (all must match)", key: "AND" }),
          new SegmentedButtonItem({ text: "OR (any must match)",  key: "OR"  })
        ]
      });
      oForm.addItem(oLogicSeg);

      oForm.addItem(new Label({ text: "Conditions" }).addStyleClass("ldlFormLabel"));
      (oWorking.conditions || []).forEach(function (oCond, i) {
        var oCondRow = new HBox({ alignItems: "Center" }).addStyleClass("ldlCondRow");
        var oFieldSel = new Select({ selectedKey: oCond.field, width: "12rem",
          change: function (e) { oCond.field = e.getParameter("selectedItem").getKey(); }
        });
        AVAILABLE_FIELDS.forEach(function (f) { oFieldSel.addItem(new Item({ key: f.key, text: f.text })); });

        var oOpSel = new Select({ selectedKey: oCond.operator, width: "10rem",
          change: function (e) { oCond.operator = e.getParameter("selectedItem").getKey(); }
        });
        AVAILABLE_OPERATORS.forEach(function (o) { oOpSel.addItem(new Item({ key: o.key, text: o.text })); });

        var oValInput = new Input({ value: oCond.value !== null ? String(oCond.value) : "",
          liveChange: function (e) {
            var sV = e.getParameter("value");
            oCond.value = isNaN(sV) ? sV : parseFloat(sV);
          }
        });

        oCondRow.addItem(oFieldSel);
        oCondRow.addItem(oOpSel);
        oCondRow.addItem(oValInput);

        if (i > 0) {
          oCondRow.addItem(new Button({
            icon: "sap-icon://delete", type: "Transparent",
            press: function () {
              oWorking.conditions.splice(i, 1);
              oForm.removeItem(oCondRow);
              oCondRow.destroy();
            }
          }));
        }
        oForm.addItem(oCondRow);
      });

      oForm.addItem(new Button({
        text: "+ Add Condition", type: "Transparent",
        press: function () {
          var oNewCond = { field: "delayDays", operator: "gt", value: 0 };
          oWorking.conditions.push(oNewCond);
          MessageToast.show("Condition added. Reopen dialog to see it.");
        }
      }));

      oForm.addItem(new Label({ text: "Action — Message Template" }).addStyleClass("ldlFormLabel"));
      var oFirstAction = (oWorking.actions && oWorking.actions[0]) || { type: "alert", message: "", target: "" };
      oForm.addItem(new TextArea({
        width: "100%", rows: 3,
        value: oFirstAction.message,
        placeholder: "Use {fieldName} tokens e.g. 'Shipment {reference} is {delayDays}d late'",
        liveChange: function (e) { oFirstAction.message = e.getParameter("value"); }
      }));

      var oActionTypeSel = new Select({ selectedKey: oFirstAction.type, width: "10rem",
        change: function (e) { oFirstAction.type = e.getParameter("selectedItem").getKey(); }
      });
      ["alert","escalate","flag","notify","block"].forEach(function (t) {
        oActionTypeSel.addItem(new Item({ key: t, text: t }));
      });
      oForm.addItem(new HBox({
        alignItems: "Center",
        items: [
          new Label({ text: "Action Type: " }),
          oActionTypeSel,
          new Label({ text: "  Target: " }),
          new Input({ value: oFirstAction.target, width: "10rem",
            liveChange: function (e) { oFirstAction.target = e.getParameter("value"); }
          })
        ]
      }));

      if (!oWorking.actions) { oWorking.actions = []; }
      if (oWorking.actions.length === 0) { oWorking.actions.push(oFirstAction); }
      else { oWorking.actions[0] = oFirstAction; }
    },

    // ── CRUD operations ─────────────────────────────────────────────────────

    _saveRule: function (oRule, oDialog, bNew) {
      if (!oRule.id || !oRule.name) {
        MessageToast.show("Rule ID and Name are required.");
        return;
      }
      var aRules = this._oLocalModel.getProperty("/rules");
      var nIdx   = aRules.findIndex(function (r) { return r.id === oRule.id; });
      oRule.modifiedAt = new Date().toISOString();
      if (!bNew && nIdx >= 0) {
        aRules[nIdx] = oRule;
      } else {
        oRule.createdAt = new Date().toISOString();
        aRules.push(oRule);
      }
      this._oLocalModel.setProperty("/rules", aRules);
      this._oLocalModel.setProperty("/filteredRules", aRules);
      this._updateStats(aRules);

      if (this._oEngine) { this._oEngine.addRule(oRule); }
      this.fireRuleSave({ rule: oRule });

      MessageToast.show("Rule '" + oRule.name + "' saved.");
      oDialog.close();
      oDialog.destroy();
    },

    _deleteRule: function (sId) {
      var aRules = this._oLocalModel.getProperty("/rules")
        .filter(function (r) { return r.id !== sId; });
      this._oLocalModel.setProperty("/rules",         aRules);
      this._oLocalModel.setProperty("/filteredRules", aRules);
      this._updateStats(aRules);
      if (this._oEngine) { this._oEngine.removeRule(sId); }
      this.fireRuleDelete({ ruleId: sId });
      MessageToast.show("Rule deleted.");
    },

    // ── Filter ──────────────────────────────────────────────────────────────

    _filterRules: function (sQuery) {
      var aAll = this._oLocalModel.getProperty("/rules");
      if (!sQuery) { this._oLocalModel.setProperty("/filteredRules", aAll); return; }
      var sQ = sQuery.toLowerCase();
      this._oLocalModel.setProperty("/filteredRules",
        aAll.filter(function (r) {
          return (r.name || "").toLowerCase().includes(sQ) ||
                 (r.id   || "").toLowerCase().includes(sQ) ||
                 ((r.tags || []).join(" ")).toLowerCase().includes(sQ);
        })
      );
    },

    _filterBySeverity: function (sSev) {
      var aAll = this._oLocalModel.getProperty("/rules");
      if (sSev === "ALL") { this._oLocalModel.setProperty("/filteredRules", aAll); return; }
      this._oLocalModel.setProperty("/filteredRules",
        aAll.filter(function (r) { return r.severity === sSev; })
      );
    },

    // ── Import / Export ─────────────────────────────────────────────────────

    _exportRules: function () {
      var sJson = JSON.stringify(this._oLocalModel.getProperty("/rules"), null, 2);
      var oBlob = new Blob([sJson], { type: "application/json" });
      var sUrl  = URL.createObjectURL(oBlob);
      var oLink = document.createElement("a");
      oLink.href = sUrl;
      oLink.download = "logistics-delay-rules-" + new Date().toISOString().slice(0,10) + ".json";
      oLink.click();
      URL.revokeObjectURL(sUrl);
      MessageToast.show("Rules exported as JSON.");
    },

    _openImportDialog: function () {
      var that    = this;
      var oInput  = new TextArea({ width: "100%", rows: 12,
        placeholder: "Paste rules JSON array here…" });
      var oDialog = new Dialog({
        title: "Import Rules from JSON",
        contentWidth: "600px",
        content: [
          new Text({ text: "Paste a JSON array of rule objects. Existing rules will be merged." }),
          oInput
        ],
        beginButton: new Button({
          text: "Import", type: "Emphasized",
          press: function () {
            try {
              var aImported = JSON.parse(oInput.getValue());
              aImported.forEach(function (r) {
                var aRules = that._oLocalModel.getProperty("/rules");
                var nIdx   = aRules.findIndex(function (x) { return x.id === r.id; });
                if (nIdx >= 0) { aRules[nIdx] = r; } else { aRules.push(r); }
                that._oLocalModel.setProperty("/rules", aRules);
                that._oLocalModel.setProperty("/filteredRules", aRules);
              });
              that._updateStats(that._oLocalModel.getProperty("/rules"));
              if (that._oEngine) { that._oEngine.loadRules(that._oLocalModel.getProperty("/rules")); }
              that.fireRulesImport({ rules: aImported });
              MessageToast.show(aImported.length + " rules imported successfully.");
              oDialog.close(); oDialog.destroy();
            } catch (e) {
              MessageBox.error("Invalid JSON: " + e.message);
            }
          }
        }),
        endButton: new Button({ text: "Cancel", press: function () { oDialog.close(); oDialog.destroy(); }})
      });
      oDialog.open();
    },

    // ── Test sandbox ─────────────────────────────────────────────────────────

    _runTestBatch: function () {
      try {
        var oShipment = JSON.parse(this._oTestInput.getValue());
      } catch (e) {
        MessageBox.error("Invalid shipment JSON: " + e.message);
        return;
      }

      if (!this._oEngine) {
        MessageToast.show("No rules engine attached. Call loadFromEngine() first.");
        return;
      }

      var oResult = this._oEngine.evaluate(oShipment);
      this._renderTestResult(oResult);
      this.fireRuleTest({ rule: null, result: oResult });
    },

    _testSingleRule: function (oRule) {
      try {
        var oShipment = JSON.parse(this._oTestInput.getValue());
      } catch (e) {
        oShipment = this._oLocalModel.getProperty("/testShipment");
      }

      if (!this._oEngine) {
        MessageToast.show("No rules engine attached. Call loadFromEngine() first.");
        return;
      }

      var oTempEngine = sap.ui.require("com/logistics/delaylib/rules/RulesEngine");
      if (!oTempEngine) {
        MessageToast.show("Testing rule… (engine not yet loaded)");
        return;
      }
      var oEng    = new oTempEngine({ rules: [oRule] });
      var oResult = oEng.evaluate(oShipment);
      this._renderTestResult(oResult, oRule.name);
      this.fireRuleTest({ rule: oRule, result: oResult });
    },

    _renderTestResult: function (oResult, sRuleName) {
      var oBox = this._oTestResultBox;
      oBox.destroyItems();

      var sHeader = sRuleName
        ? "Rule '" + sRuleName + "' test result:"
        : "All rules evaluated. " + oResult.rulesFired + " fired, " + oResult.rulesSkipped + " skipped.";

      oBox.addItem(new Title({ text: sHeader, level: "H6" }).addStyleClass("ldlTestResultTitle"));

      if (oResult.matched.length === 0) {
        oBox.addItem(new Text({ text: "No rules matched this shipment." }));
        return;
      }

      oResult.matched.forEach(function (oMatch) {
        var oCard = new VBox().addStyleClass("ldlTestMatchCard");
        oCard.addItem(new HBox({
          items: [
            new ObjectStatus({ text: oMatch.severity, state: oMatch.severity === "Critical" || oMatch.severity === "Error" ? "Error" : "Warning" }),
            new Text({ text: "  " + oMatch.ruleName }).addStyleClass("ldlMatchRuleName")
          ]
        }));
        oMatch.actions.forEach(function (oAction) {
          oCard.addItem(new Text({ text: "[" + oAction.type + "] " + oAction.message }).addStyleClass("ldlMatchAction"));
        });
        oBox.addItem(oCard);
      });
    },

    // ── Stats ────────────────────────────────────────────────────────────────

    _updateStats: function (aRules) {
      this._oLocalModel.setProperty("/stats", {
        total:    aRules.length,
        active:   aRules.filter(function (r) { return  r.active; }).length,
        inactive: aRules.filter(function (r) { return !r.active; }).length,
        critical: aRules.filter(function (r) { return r.severity === "Critical"; }).length,
        errors:   aRules.filter(function (r) { return r.severity === "Error";    }).length,
        warnings: aRules.filter(function (r) { return r.severity === "Warning";  }).length
      });
    }
  });
});
