/**
 * RulesEngine.js
 * com.logistics.delaylib.rules.RulesEngine
 * ─────────────────────────────────────────────────────────────────────────────
 * Pure JavaScript rules engine — no SAP UI5 dependency at runtime.
 * Evaluates a set of configurable business rules against a shipment context
 * and returns structured results.
 *
 * Rule schema:
 * {
 *   id:          "RULE_001"           // unique identifier
 *   name:        "Overdue Sea Freight"// display name
 *   description: "Sea PO past ETA"   // human-readable description
 *   active:      true                 // can be toggled off without deleting
 *   severity:    "Error"             // Info | Warning | Error | Critical
 *   mode:        ["Sea","Air","All"] // shipment modes this applies to
 *   conditions:  [                   // array of conditions (AND logic within group)
 *     {
 *       field:    "delayDays",        // field path in the shipment context
 *       operator: "gt",              // eq|neq|gt|gte|lt|lte|contains|startsWith|in|notIn|between|regex
 *       value:    5                   // comparison value
 *     }
 *   ],
 *   conditionLogic: "AND",           // AND | OR (how conditions are combined)
 *   actions: [                       // what happens when the rule fires
 *     {
 *       type:    "alert",             // alert | escalate | flag | notify | block
 *       message: "Shipment {ref} is {delayDays}d overdue. Escalate to CPO.",
 *       target:  "CEO_DASHBOARD"     // where the action goes
 *     }
 *   ],
 *   priority:    10,                 // lower = evaluated first
 *   tags:        ["sea","overdue"],  // free-form tags for filtering
 *   createdBy:   "admin",
 *   createdAt:   "2025-01-01T00:00:00Z",
 *   modifiedAt:  "2025-03-01T00:00:00Z"
 * }
 *
 * Shipment context schema (fields available in rule conditions):
 * {
 *   orderId, reference, carrier, mode,
 *   pol, pod, eta, ata,
 *   delayDays, isDelayed, status,
 *   weight, volume, value, currency,
 *   incoterm, customerRisk,
 *   poValue, soReference
 * }
 * ─────────────────────────────────────────────────────────────────────────────
 */
sap.ui.define([
  "sap/ui/base/Object"
], function (BaseObject) {
  "use strict";

  // ── Operator implementations ──────────────────────────────────────────────
  var Operators = {
    eq:         function (a, b) { return a == b; },
    neq:        function (a, b) { return a != b; },
    gt:         function (a, b) { return parseFloat(a) >  parseFloat(b); },
    gte:        function (a, b) { return parseFloat(a) >= parseFloat(b); },
    lt:         function (a, b) { return parseFloat(a) <  parseFloat(b); },
    lte:        function (a, b) { return parseFloat(a) <= parseFloat(b); },
    contains:   function (a, b) { return String(a).toLowerCase().includes(String(b).toLowerCase()); },
    startsWith: function (a, b) { return String(a).toLowerCase().startsWith(String(b).toLowerCase()); },
    endsWith:   function (a, b) { return String(a).toLowerCase().endsWith(String(b).toLowerCase()); },
    in:         function (a, b) { return Array.isArray(b) && b.map(String).includes(String(a)); },
    notIn:      function (a, b) { return Array.isArray(b) && !b.map(String).includes(String(a)); },
    between:    function (a, b) {
      if (!Array.isArray(b) || b.length !== 2) { return false; }
      var n = parseFloat(a);
      return n >= parseFloat(b[0]) && n <= parseFloat(b[1]);
    },
    regex:      function (a, b) {
      try { return new RegExp(b, "i").test(String(a)); }
      catch (e) { return false; }
    },
    isNull:     function (a) { return a === null || a === undefined || a === ""; },
    isNotNull:  function (a) { return a !== null && a !== undefined && a !== ""; },
    isTrue:     function (a) { return a === true || a === "true" || a === 1; },
    isFalse:    function (a) { return a === false || a === "false" || a === 0; }
  };

  return BaseObject.extend("com.logistics.delaylib.rules.RulesEngine", {

    /**
     * @param {object} [oConfig]
     * @param {Array}  [oConfig.rules=[]]   Initial rule set
     * @param {boolean}[oConfig.stopOnFirst=false] Stop evaluating after first match
     * @param {boolean}[oConfig.dryRun=false]      Evaluate without firing actions
     */
    constructor: function (oConfig) {
      oConfig = oConfig || {};
      this._aRules      = (oConfig.rules || []).slice().sort(this._byPriority);
      this._bStopFirst  = !!oConfig.stopOnFirst;
      this._bDryRun     = !!oConfig.dryRun;
      this._aAuditLog   = [];
      this._oHandlers   = {};   // action type → handler function
      this._registerDefaultHandlers();
    },

    // ── Rule CRUD ───────────────────────────────────────────────────────────

    /** Add or replace a rule (matched by id). */
    addRule: function (oRule) {
      this._validateRule(oRule);
      var nIdx = this._aRules.findIndex(function (r) { return r.id === oRule.id; });
      if (nIdx >= 0) {
        this._aRules[nIdx] = oRule;
      } else {
        this._aRules.push(oRule);
      }
      this._aRules.sort(this._byPriority);
      return this;
    },

    /** Remove rule by id. */
    removeRule: function (sId) {
      this._aRules = this._aRules.filter(function (r) { return r.id !== sId; });
      return this;
    },

    /** Get all rules (copy). */
    getRules: function () { return this._aRules.slice(); },

    /** Get single rule by id. */
    getRule: function (sId) {
      return this._aRules.find(function (r) { return r.id === sId; }) || null;
    },

    /** Enable or disable a rule without removing it. */
    setRuleActive: function (sId, bActive) {
      var oRule = this.getRule(sId);
      if (oRule) { oRule.active = bActive; }
      return this;
    },

    /** Replace the entire rule set. */
    loadRules: function (aRules) {
      aRules.forEach(this._validateRule.bind(this));
      this._aRules = aRules.slice().sort(this._byPriority);
      return this;
    },

    /** Export rules as JSON string (for persistence to BTP Object Store or HANA). */
    exportRules: function () {
      return JSON.stringify(this._aRules, null, 2);
    },

    /** Import rules from JSON string. */
    importRules: function (sJson) {
      try {
        var aRules = JSON.parse(sJson);
        return this.loadRules(aRules);
      } catch (e) {
        throw new Error("RulesEngine.importRules: invalid JSON — " + e.message);
      }
    },

    // ── Evaluation ──────────────────────────────────────────────────────────

    /**
     * Evaluate all active rules against a single shipment context.
     * @param  {object} oShipment  Shipment context object
     * @returns {object} Result: { matched, results, actions, rulesFired, rulesSkipped }
     */
    evaluate: function (oShipment) {
      var aMatched = [];
      var aActions = [];
      var nFired   = 0;
      var nSkipped = 0;
      var that     = this;

      this._aRules.forEach(function (oRule) {
        if (!oRule.active) { nSkipped++; return; }

        // Mode filter — skip if rule doesn't apply to this shipment's mode
        if (oRule.mode &&
            !oRule.mode.includes("All") &&
            !oRule.mode.includes(oShipment.mode)) {
          nSkipped++;
          return;
        }

        var bMatch = that._evaluateConditions(oRule, oShipment);
        if (bMatch) {
          nFired++;
          var aRuleActions = that._buildActions(oRule, oShipment);
          aMatched.push({
            ruleId:    oRule.id,
            ruleName:  oRule.name,
            severity:  oRule.severity,
            actions:   aRuleActions,
            matchedAt: new Date().toISOString()
          });
          aActions = aActions.concat(aRuleActions);

          // Fire action handlers (unless dry run)
          if (!that._bDryRun) {
            aRuleActions.forEach(function (oAction) {
              that._fireAction(oAction, oShipment, oRule);
            });
          }

          // Audit log entry
          that._aAuditLog.push({
            ts:        new Date().toISOString(),
            ruleId:    oRule.id,
            shipment:  oShipment.orderId || oShipment.reference || "unknown",
            severity:  oRule.severity,
            result:    "MATCHED"
          });

          if (that._bStopFirst) { return false; }
        }
      });

      return {
        matched:      aMatched,
        actions:      aActions,
        rulesFired:   nFired,
        rulesSkipped: nSkipped,
        rulesTotal:   this._aRules.length,
        shipment:     oShipment.orderId || oShipment.reference,
        evaluatedAt:  new Date().toISOString()
      };
    },

    /**
     * Evaluate a batch of shipments.
     * @param  {Array}  aShipments  Array of shipment context objects
     * @returns {object} { results, totalMatches, criticalCount, errorCount }
     */
    evaluateBatch: function (aShipments) {
      var aResults     = [];
      var nTotalMatch  = 0;
      var nCritical    = 0;
      var nErrors      = 0;
      var that         = this;

      aShipments.forEach(function (oShipment) {
        var oResult = that.evaluate(oShipment);
        aResults.push(oResult);
        nTotalMatch += oResult.rulesFired;
        oResult.matched.forEach(function (m) {
          if (m.severity === "Critical") { nCritical++; }
          if (m.severity === "Error")    { nErrors++; }
        });
      });

      return {
        results:        aResults,
        totalShipments: aShipments.length,
        totalMatches:   nTotalMatch,
        criticalCount:  nCritical,
        errorCount:     nErrors,
        batchAt:        new Date().toISOString()
      };
    },

    // ── Action Handlers ─────────────────────────────────────────────────────

    /**
     * Register a custom action handler.
     * @param {string}   sType     Action type string (e.g. "notify", "escalate")
     * @param {function} fnHandler Called with (oAction, oShipment, oRule)
     */
    registerActionHandler: function (sType, fnHandler) {
      this._oHandlers[sType] = fnHandler;
      return this;
    },

    /** Get the audit log of all rule matches. */
    getAuditLog: function () { return this._aAuditLog.slice(); },

    /** Clear the audit log. */
    clearAuditLog: function () { this._aAuditLog = []; return this; },

    // ── Built-in rule library ────────────────────────────────────────────────

    /**
     * Returns the default ruleset covering common logistics delay scenarios.
     * These are immediately usable out-of-the-box and can be customised.
     * @returns {Array}
     */
    getDefaultRules: function () {
      return [
        {
          id: "DL_001", name: "Overdue Sea Shipment",
          description: "Sea freight past ETA by more than 3 days",
          active: true, severity: "Error", priority: 10,
          mode: ["Sea"], conditionLogic: "AND",
          conditions: [
            { field: "delayDays", operator: "gt", value: 3 },
            { field: "mode",      operator: "eq", value: "Sea" }
          ],
          actions: [{ type: "alert", message: "Sea shipment {reference} is {delayDays}d overdue", target: "CEO_DASHBOARD" }],
          tags: ["sea", "overdue"]
        },
        {
          id: "DL_002", name: "Critical Sea Delay",
          description: "Sea freight delayed more than 10 days",
          active: true, severity: "Critical", priority: 5,
          mode: ["Sea"], conditionLogic: "AND",
          conditions: [
            { field: "delayDays", operator: "gte", value: 10 }
          ],
          actions: [
            { type: "alert",    message: "CRITICAL: {reference} is {delayDays}d delayed. Escalate immediately.", target: "CEO_DASHBOARD" },
            { type: "escalate", message: "Shipment {reference} requires CEO intervention", target: "CPO" }
          ],
          tags: ["sea", "critical", "escalate"]
        },
        {
          id: "DL_003", name: "Air Freight Overdue",
          description: "Air waybill past ETA by more than 1 day",
          active: true, severity: "Error", priority: 10,
          mode: ["Air"], conditionLogic: "AND",
          conditions: [
            { field: "delayDays", operator: "gte", value: 1 },
            { field: "mode",      operator: "eq",  value: "Air" }
          ],
          actions: [{ type: "alert", message: "Air shipment {reference} is {delayDays}d overdue — high-value SLA risk", target: "CEO_DASHBOARD" }],
          tags: ["air", "overdue"]
        },
        {
          id: "DL_004", name: "High-Value Shipment Delayed",
          description: "Shipment with value > $100K delayed by any amount",
          active: true, severity: "Error", priority: 8,
          mode: ["Sea", "Air", "All"], conditionLogic: "AND",
          conditions: [
            { field: "value",     operator: "gt",  value: 100000 },
            { field: "delayDays", operator: "gt",  value: 0 }
          ],
          actions: [{ type: "alert", message: "High-value shipment {reference} (${{value}}) is delayed {delayDays}d", target: "CEO_DASHBOARD" }],
          tags: ["high-value", "financial-risk"]
        },
        {
          id: "DL_005", name: "BASF / At-Risk Supplier Shipment Delayed",
          description: "Shipment from a flagged carrier showing any delay",
          active: true, severity: "Warning", priority: 15,
          mode: ["Sea", "Air", "All"], conditionLogic: "AND",
          conditions: [
            { field: "delayDays",  operator: "gt",       value: 0 },
            { field: "carrier",    operator: "in",        value: ["BASF SE", "BASF", "FOGR", "UNKN"] }
          ],
          actions: [{ type: "flag", message: "At-risk supplier {carrier} has delayed shipment {reference}", target: "PROCUREMENT" }],
          tags: ["supplier-risk", "watchlist"]
        },
        {
          id: "DL_006", name: "Customs Hold Detected",
          description: "Shipment status contains 'customs' or 'hold'",
          active: true, severity: "Warning", priority: 12,
          mode: ["Sea", "Air", "All"], conditionLogic: "OR",
          conditions: [
            { field: "status", operator: "contains", value: "customs" },
            { field: "status", operator: "contains", value: "hold" },
            { field: "status", operator: "contains", value: "detained" }
          ],
          actions: [{ type: "alert", message: "Shipment {reference} has customs/hold status: {status}", target: "CEO_DASHBOARD" }],
          tags: ["customs", "hold"]
        },
        {
          id: "DL_007", name: "EMEA→APAC Lane High Delay Rate",
          description: "Shipments on EMEA-to-APAC trade lane delayed > 5 days",
          active: true, severity: "Warning", priority: 20,
          mode: ["Sea"], conditionLogic: "AND",
          conditions: [
            { field: "pol",       operator: "in",  value: ["Hamburg","Rotterdam","Antwerp","Felixstowe"] },
            { field: "pod",       operator: "in",  value: ["Shanghai","Singapore","Tokyo","Busan","Hong Kong"] },
            { field: "delayDays", operator: "gt",  value: 5 }
          ],
          actions: [{ type: "alert", message: "EMEA→APAC lane delay: {reference} ({pol}→{pod}) is {delayDays}d late", target: "CEO_DASHBOARD" }],
          tags: ["trade-lane", "emea-apac"]
        },
        {
          id: "DL_008", name: "ETA Breach with SO Reference",
          description: "Shipment linked to a Sales Order is overdue",
          active: true, severity: "Error", priority: 7,
          mode: ["Sea", "Air", "All"], conditionLogic: "AND",
          conditions: [
            { field: "soReference", operator: "isNotNull", value: null },
            { field: "delayDays",   operator: "gt",        value: 2 }
          ],
          actions: [
            { type: "alert",  message: "SO-linked shipment {reference} (SO: {soReference}) delayed {delayDays}d — customer impact risk", target: "CEO_DASHBOARD" },
            { type: "notify", message: "Sales order {soReference} delivery at risk", target: "SALES_TEAM" }
          ],
          tags: ["sales-order", "customer-impact"]
        },
        {
          id: "DL_009", name: "Carrier On-Time Rate Below Threshold",
          description: "Carrier has delay rate > 30%",
          active: true, severity: "Warning", priority: 25,
          mode: ["Sea", "Air", "All"], conditionLogic: "AND",
          conditions: [
            { field: "carrierDelayRate", operator: "gt", value: 30 }
          ],
          actions: [{ type: "flag", message: "Carrier {carrier} has {carrierDelayRate}% delay rate — review procurement strategy", target: "PROCUREMENT" }],
          tags: ["carrier-performance", "kpi"]
        },
        {
          id: "DL_010", name: "Weekend Arrival Penalty",
          description: "Shipment arriving on weekend with delay — extra demurrage risk",
          active: false, severity: "Info", priority: 50,
          mode: ["Sea"], conditionLogic: "AND",
          conditions: [
            { field: "delayDays",   operator: "gt",    value: 0 },
            { field: "etaDayOfWeek",operator: "in",    value: ["Saturday","Sunday"] }
          ],
          actions: [{ type: "alert", message: "Weekend arrival: {reference} risks demurrage — consider rescheduling", target: "LOGISTICS" }],
          tags: ["demurrage", "weekend"]
        }
      ];
    },

    // ── Internal helpers ─────────────────────────────────────────────────────

    _evaluateConditions: function (oRule, oShipment) {
      var aConditions = oRule.conditions || [];
      var sLogic      = oRule.conditionLogic || "AND";
      var that        = this;

      if (aConditions.length === 0) { return false; }

      var aResults = aConditions.map(function (oCond) {
        return that._evaluateCondition(oCond, oShipment);
      });

      return sLogic === "OR"
        ? aResults.some(Boolean)
        : aResults.every(Boolean);
    },

    _evaluateCondition: function (oCond, oShipment) {
      var vFieldVal = this._getNestedValue(oShipment, oCond.field);
      var fnOp      = Operators[oCond.operator];
      if (!fnOp) {
        jQuery.sap.log.warning("RulesEngine: unknown operator '" + oCond.operator + "'");
        return false;
      }
      return fnOp(vFieldVal, oCond.value);
    },

    _getNestedValue: function (oObj, sPath) {
      if (!oObj || !sPath) { return undefined; }
      return sPath.split(".").reduce(function (o, k) {
        return (o !== null && o !== undefined) ? o[k] : undefined;
      }, oObj);
    },

    _buildActions: function (oRule, oShipment) {
      return (oRule.actions || []).map(function (oActionDef) {
        return {
          type:    oActionDef.type,
          message: this._interpolate(oActionDef.message, oShipment),
          target:  oActionDef.target,
          ruleId:  oRule.id,
          severity:oRule.severity
        };
      }, this);
    },

    /** Replace {fieldName} tokens in message with actual shipment values. */
    _interpolate: function (sTemplate, oCtx) {
      if (!sTemplate) { return ""; }
      return sTemplate.replace(/\{(\w+)\}/g, function (_, sKey) {
        var vVal = oCtx[sKey];
        return vVal !== undefined && vVal !== null ? vVal : "{" + sKey + "}";
      });
    },

    _fireAction: function (oAction, oShipment, oRule) {
      var fnHandler = this._oHandlers[oAction.type];
      if (fnHandler) {
        try { fnHandler(oAction, oShipment, oRule); }
        catch (e) {
          jQuery.sap.log.error("RulesEngine action handler error: " + e.message);
        }
      }
    },

    _registerDefaultHandlers: function () {
      this._oHandlers["alert"] = function (oAction) {
        jQuery.sap.log.info("[RulesEngine] ALERT [" + oAction.severity + "]: " + oAction.message);
      };
      this._oHandlers["escalate"] = function (oAction) {
        jQuery.sap.log.warning("[RulesEngine] ESCALATE → " + oAction.target + ": " + oAction.message);
      };
      this._oHandlers["flag"] = function (oAction) {
        jQuery.sap.log.info("[RulesEngine] FLAG → " + oAction.target + ": " + oAction.message);
      };
      this._oHandlers["notify"] = function (oAction) {
        jQuery.sap.log.info("[RulesEngine] NOTIFY → " + oAction.target + ": " + oAction.message);
      };
      this._oHandlers["block"] = function (oAction) {
        jQuery.sap.log.warning("[RulesEngine] BLOCK → " + oAction.target + ": " + oAction.message);
      };
    },

    _validateRule: function (oRule) {
      if (!oRule.id)         { throw new Error("Rule missing required field: id"); }
      if (!oRule.name)       { throw new Error("Rule " + oRule.id + " missing: name"); }
      if (!oRule.conditions) { throw new Error("Rule " + oRule.id + " missing: conditions"); }
      if (!oRule.severity)   { throw new Error("Rule " + oRule.id + " missing: severity"); }
    },

    _byPriority: function (a, b) {
      return (a.priority || 99) - (b.priority || 99);
    }
  });
});
