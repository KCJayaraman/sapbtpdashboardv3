# TrackCargo API — BTP Destination Configuration

Manual setup guide for configuring the `TRACKCARGO_API` BTP Destination in the cockpit.

---

## Step 1 — Get Your TrackCargo API Key

1. Go to https://trackcargo.co/signup
2. Create an account and subscribe to a plan (trial available)
3. Navigate to **Developer → API Keys** in your dashboard
4. Copy your Bearer token

---

## Step 2 — Create BTP Destination (Cockpit UI)

Navigate to: **BTP Cockpit → Connectivity → Destinations → New Destination**

Fill in exactly as follows:

| Field | Value |
|---|---|
| Name | `TRACKCARGO_API` |
| Type | `HTTP` |
| Description | `TrackCargo.co REST API for logistics tracking` |
| URL | `https://trackcargo.co` |
| Proxy Type | `Internet` |
| Authentication | `NoAuthentication` |

**Additional Properties** (click "+ New Property" for each):

| Property | Value |
|---|---|
| `HTML5.DynamicDestination` | `true` |
| `HTML5.ForwardAuthToken` | `false` |
| `TrustAll` | `false` |

**Additional Headers** (these are injected by App Router into every API call):

| Header | Value |
|---|---|
| `Authorization` | `Bearer YOUR_TRACKCARGO_API_KEY` |
| `Content-Type` | `application/json` |
| `Accept` | `application/json` |

> ⚠️ Replace `YOUR_TRACKCARGO_API_KEY` with your actual key from trackcargo.co

---

## Step 3 — Test the Connection

1. After saving, click **"Check Connection"** in the Destination editor
2. You should see: `Connection to "TRACKCARGO_API" established. Response returned: "200: OK"`
3. If you see 401: your API key is wrong
4. If you see network error: check ProxyType (use `OnPremise` + Cloud Connector if needed)

---

## Step 4 — How the App Router Uses This Destination

The `approuter/xs-app.json` contains this route:

```json
{
  "source": "^/trackcargo/(.*)$",
  "target": "/$1",
  "destination": "TRACKCARGO_API",
  "authenticationType": "none",
  "csrfProtection": false
}
```

**What this means:**
- Browser calls: `GET /trackcargo/api/v1/client-orders/sea`
- App Router rewrites to: `GET https://trackcargo.co/api/v1/client-orders/sea`
- App Router injects: `Authorization: Bearer YOUR_KEY` (from destination Additional Headers)
- API key is **never** exposed to the browser

---

## Step 5 — Verify in TrackCargoService.js

The service layer uses this base path:
```javascript
var BASE_PATH = "/trackcargo";
// All calls: /trackcargo/api/v1/client-orders/...
// App Router strips /trackcargo prefix and proxies to trackcargo.co
```

For local development without BTP, inject the key directly:
```javascript
// In your local dev config or Logistics.controller.js onInit:
this._oTrackSvc.setApiKey("YOUR_TRACKCARGO_API_KEY");
```

---

## API Endpoints Called

| Method | Path | Used for |
|---|---|---|
| GET | `/api/v1/client-orders/recent` | All shipments table |
| GET | `/api/v1/client-orders/sea` | Sea freight analysis |
| GET | `/api/v1/client-orders/air` | Air freight analysis |
| GET | `/api/v1/client-orders/sea/overview` | Sea KPIs |
| GET | `/api/v1/client-orders/air/overview` | Air KPIs |
| GET | `/api/v1/client-orders/{id}/tracking` | Live tracking events (on row press) |
| POST | `/api/v1/client-orders/create` | Track New Shipment dialog |

---

## Security Notes

- The API key is stored encrypted in the BTP Destination service
- The App Router injects it server-side — it is never sent to the browser
- The `/trackcargo/*` route has `authenticationType: none` because TrackCargo uses its own Bearer auth, not XSUAA
- All traffic is over HTTPS (TLS 1.2+)
- TrackCargo is SOC 2 Type II · ISO 27001 · GDPR compliant
