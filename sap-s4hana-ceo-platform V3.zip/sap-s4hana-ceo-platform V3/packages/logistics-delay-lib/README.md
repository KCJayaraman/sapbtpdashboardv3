# com.logistics.delaylib
### SAP UI5 Reusable Library — Logistics Delay Monitoring, Simulation & Business Rules

Version 1.0.0 · SAP UI5 1.108+ · SAP Horizon Theme · SAP BTP Cloud Foundry

---

## What This Library Provides

A standalone, deployable SAP UI5 library (`com.logistics.delaylib`) that gives any
SAP UI5 application three reusable capabilities for logistics delay management:

| Component | Type | What it does |
|---|---|---|
| `DelayMonitor` | UI5 Control | Drop-in delay KPI panel + shipment table with live filter/search |
| `RulesEditor` | UI5 Control | Full business rules management UI — add/edit/test/import/export rules |
| `DelaySimulator` | UI5 Control | Monte Carlo simulation UI with P50/P90/P99 estimates and scenario comparison |
| `RulesEngine` | JS Service | Pure JS rule evaluator — evaluates conditions against shipment context |
| `DelaySimulationEngine` | JS Service | Monte Carlo engine — 7 built-in scenarios + custom scenario support |

---

## Project Structure

```
logistics-delay-library/
├── src/
│   ├── library.js                          ← Library bootstrap + enumerations
│   ├── .library                            ← SAP UI5 library descriptor
│   ├── rules/
│   │   └── RulesEngine.js                  ← Rule evaluator (framework-agnostic)
│   ├── simulation/
│   │   └── DelaySimulationEngine.js        ← Monte Carlo engine
│   ├── control/
│   │   ├── DelayMonitor.js                 ← Delay KPI + table control
│   │   ├── RulesEditor.js                  ← Rules management UI control
│   │   └── DelaySimulatorControl.js        ← Simulation UI control
│   └── themes/base/
│       ├── library.less                    ← Source CSS
│       └── library.css                     ← Compiled CSS
├── demo/webapp/                            ← Standalone demo application
│   ├── Component.js
│   ├── manifest.json
│   ├── view/                               ← App, Monitor, Rules, Simulation views
│   └── controller/                         ← Controllers for each view
├── INTEGRATION.md                          ← How to use in your app
├── ui5.yaml                                ← SAP UI5 Tooling config
├── mta.yaml                                ← BTP deployment descriptor
└── package.json
```

---

## Quick Start

### 1. Local development

```bash
npm install
npm start
# Opens http://localhost:8081/demo/webapp/index.html
```

### 2. Deploy to SAP BTP

```bash
npm install -g mbt
mbt build
cf deploy mta_archives/com-logistics-delaylib_1.0.0.mtar
```

### 3. Use in your SAP UI5 app

Add to your `manifest.json`:
```json
"sap.ui5": {
  "dependencies": {
    "libs": { "com.logistics.delaylib": {} }
  }
}
```

In your XML view:
```xml
<mvc:View xmlns:delaylib="com.logistics.delaylib" ...>
  <delaylib:DelayMonitor  id="monitor"   ... />
  <delaylib:RulesEditor   id="editor"    ... />
  <delaylib:DelaySimulator id="simulator" ... />
</mvc:View>
```

See [INTEGRATION.md](INTEGRATION.md) for full wiring instructions.

---

## Built-in Rules (10 Default)

| Rule ID | Name | Severity | Trigger |
|---|---|---|---|
| DL_001 | Overdue Sea Shipment | Error | Sea + `delayDays > 3` |
| DL_002 | Critical Sea Delay | Critical | `delayDays >= 10` + escalate |
| DL_003 | Air Freight Overdue | Error | Air + `delayDays >= 1` |
| DL_004 | High-Value Shipment Delayed | Error | `value > 100,000` + any delay |
| DL_005 | At-Risk Supplier Delay | Warning | Carrier in watchlist + delayed |
| DL_006 | Customs Hold Detected | Warning | Status contains "customs"/"hold" |
| DL_007 | EMEA→APAC Lane High Delay | Warning | Trade lane + `delayDays > 5` |
| DL_008 | ETA Breach with SO Reference | Error | SO-linked + `delayDays > 2` |
| DL_009 | Carrier OTR Below Threshold | Warning | `carrierDelayRate > 30%` |
| DL_010 | Weekend Arrival Penalty | Info | Weekend ETA + delayed (disabled) |

---

## Simulation Scenarios (7 Built-in)

| Scenario | Port Delay | Transit | Customs | Weather | Event Prob |
|---|---|---|---|---|---|
| Baseline | 0–2d | 0–3d | 0–2d | 0–1d | 2% |
| PortCongestion | 2–14d | 0–3d | 0–3d | 0–1d | 15% |
| WeatherDisruption | 0–5d | 1–10d | 0–2d | 2–14d | 20% |
| CustomsDelay | 0–3d | 0–2d | 3–21d | 0–1d | 25% |
| CapacityShortage | 1–7d | 0–5d | 0–2d | 0–1d | 10% |
| Strike | 3–30d | 0–5d | 0–3d | 0–1d | 40% |
| Geopolitical | 0–7d | 3–21d | 1–10d | 0–2d | 30% |

---

## Rule Schema

```json
{
  "id":             "DL_001",
  "name":           "Overdue Sea Shipment",
  "description":    "Sea freight past ETA by more than 3 days",
  "active":         true,
  "severity":       "Error",
  "priority":       10,
  "mode":           ["Sea"],
  "conditionLogic": "AND",
  "conditions": [
    { "field": "delayDays", "operator": "gt", "value": 3 },
    { "field": "mode",      "operator": "eq", "value": "Sea" }
  ],
  "actions": [
    {
      "type":    "alert",
      "message": "Sea shipment {reference} is {delayDays}d overdue",
      "target":  "CEO_DASHBOARD"
    }
  ],
  "tags": ["sea", "overdue"]
}
```

### Available Operators

`eq` `neq` `gt` `gte` `lt` `lte` `contains` `startsWith` `endsWith`
`in` `notIn` `between` `regex` `isNull` `isNotNull` `isTrue` `isFalse`

### Condition Fields (Shipment Context)

`delayDays` `mode` `carrier` `pol` `pod` `status` `value` `isDelayed`
`soReference` `poReference` `incoterm` `carrierDelayRate` `etaDayOfWeek`
`customerRisk`

---

## Resources

- SAP UI5 Custom Library Guide: https://ui5.sap.com/#/topic/9f4d62c6648e4a7aa2c52f698cfe2774
- SAP BTP HTML5 App Repository: https://help.sap.com/docs/BTP/65de2977205c403bbc107264b8eccf4b/f8520f572a6445a7bfaff4a1bbcbe60a.html
- SAP UI5 Tooling: https://sap.github.io/ui5-tooling/
