# Contributing Guide

Thank you for contributing to the SAP S/4HANA CEO Platform.
This guide covers the branching strategy, PR process, and coding standards.

---

## Branching Strategy

We use **GitHub Flow** — simple and works well for BTP deployments.

```
main          ← always deployable to production BTP
  │
  ├─ feature/JIRA-123-add-logistics-tab
  ├─ fix/JIRA-456-fix-po-binding
  ├─ docs/update-how-to-guide
  └─ chore/upgrade-ui5-1121
```

| Branch prefix | When to use |
|---|---|
| `feature/` | New functionality |
| `fix/` | Bug fixes |
| `docs/` | Documentation only |
| `chore/` | Dependency updates, tooling |
| `release/` | Release preparation |

---

## Pull Request Process

1. **Create a branch** from `main`
2. **Make your changes** (see coding standards below)
3. **Run checks locally** before pushing:
   ```bash
   cd packages/control-tower && npx eslint webapp/
   cd packages/logistics-delay-lib && npx eslint src/
   ```
4. **Open a PR** against `main`
5. **Fill in the PR template** — describe what changed and why
6. **Wait for CI** — the `ci.yml` workflow must pass
7. **Get one approval** from a team member
8. **Squash and merge** — keep `main` history clean

---

## Coding Standards

### JavaScript

- **SAP UI5 module pattern** — always use `sap.ui.define([...], function() {})`
- **`"use strict"`** — always, inside every module
- **No `var` in new code** — use `var` only when touching existing code (UI5 convention)
- **JSDoc** on all public functions — `@param`, `@returns`, `@fires`
- **No `console.log`** — use `jQuery.sap.log.info/warning/error`
- **Service layer isolation** — API calls only in `*Service.js` files

### XML Views

- **Sentence case** on all labels — `"Purchase orders"` not `"Purchase Orders"`
- **No hardcoded strings** — use `i18n>key` bindings
- **One view per page** — don't nest pages
- **Fragment files for dialogs** — keep views lean

### Naming conventions

| Thing | Convention | Example |
|---|---|---|
| JS files | PascalCase | `S4HanaService.js` |
| View files | PascalCase | `Overview.view.xml` |
| CSS classes | camelCase with prefix | `ctKpiTile`, `ldlRuleId` |
| Model names | camelCase | `procurement`, `ui`, `log` |
| Event handlers | `on` + PascalCase | `onPOPress`, `onRefresh` |
| i18n keys | camelCase | `kpi.totalRevenue` |

### Commit messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
feat(logistics): add carrier delay rate breakdown chart
fix(procurement): correct 3-way match rate calculation
docs(rules): add authoring guide for complex conditions
chore(deps): upgrade @ui5/cli to 3.9.0
```

---

## Adding a New S/4HANA Entity

1. **Add a method to `S4HanaService.js`**:
   ```javascript
   getMyNewEntity: function (oParams) {
     return this._read(this._oProcModel, "/MyEntitySet", {
       urlParameters: { "$select": "Field1,Field2", "$top": "100" }
     });
   }
   ```

2. **Call it from the relevant controller**
3. **Write the result to `ui` JSONModel** for simple display, OR
   **bind a Table directly** for paginated display

4. **Add metadata** to `webapp/localService/procurement/metadata.xml`
   for offline development

---

## Adding a New Control to the Library

1. Create `packages/logistics-delay-lib/src/control/MyControl.js`
2. Follow the `DelayMonitor.js` pattern — `metadata`, `init`, `renderer`, public API
3. Register in `src/library.js` under `controls: [...]`
4. Add a demo view in `demo/webapp/view/`
5. Export CSS classes with `ldl` prefix in `src/themes/base/library.less`

---

## Testing

We use **manual testing** currently. Automated testing is on the roadmap.

### Manual test checklist before PR

**Control Tower:**
- [ ] All 5 tabs load without errors
- [ ] Filter bar changes reload data
- [ ] Search works in Procurement and Sales tables
- [ ] Alerts tab shows correct alert count
- [ ] Logistics tab shows TrackCargo data (if API key configured)
- [ ] Excel export downloads correctly

**Delay Library:**
- [ ] Demo app loads at `localhost:8081/demo/webapp/index.html`
- [ ] Monitor tab: KPI cards show values, table loads
- [ ] Rules tab: 10 default rules load, test sandbox fires correctly
- [ ] Simulation tab: Run produces P50/P90/P99 results, Compare shows table

---

## Getting Help

- Open a **GitHub Issue** using the templates in `.github/ISSUE_TEMPLATE/`
- For BTP-specific questions: [SAP Community](https://community.sap.com)
- For UI5 questions: [UI5 Slack](https://ui5-slack-invite.cfapps.eu10.hana.ondemand.com/)
