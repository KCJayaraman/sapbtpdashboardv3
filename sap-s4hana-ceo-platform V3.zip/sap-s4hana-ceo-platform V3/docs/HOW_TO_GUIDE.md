# How-To Guide
## SAP S/4HANA CEO Platform — Complete Team Reference

**Version:** 1.0 · **Last updated:** March 2025
**Audience:** Developers, BTP Admins, Business Analysts

---

## Table of Contents

1. [Repository Setup](#1-repository-setup)
2. [Local Development](#2-local-development)
3. [Understanding the Architecture](#3-understanding-the-architecture)
4. [Deploying the Control Tower to BTP](#4-deploying-the-control-tower-to-btp)
5. [Deploying the Delay Library to BTP](#5-deploying-the-delay-library-to-btp)
6. [Configuring BTP Destinations](#6-configuring-btp-destinations)
7. [Activating S/4HANA OData Services](#7-activating-s4hana-odata-services)
8. [Connecting TrackCargo API](#8-connecting-trackcargo-api)
9. [Using the Delay Library in Your App](#9-using-the-delay-library-in-your-app)
10. [Authoring Business Rules](#10-authoring-business-rules)
11. [Running Delay Simulations](#11-running-delay-simulations)
12. [Role Management & Security](#12-role-management--security)
13. [CI/CD with GitHub Actions](#13-cicd-with-github-actions)
14. [Troubleshooting](#14-troubleshooting)
15. [FAQ](#15-faq)

---

## 1. Repository Setup

### Clone and install

```bash
git clone https://github.com/YOUR-ORG/sap-s4hana-ceo-platform.git
cd sap-s4hana-ceo-platform
npm install          # installs root-level dev tools
```

### Install package dependencies

```bash
# Control Tower
cd packages/control-tower && npm install && cd ../..

# Delay Library
cd packages/logistics-delay-lib && npm install && cd ../..
```

### Verify your tooling

```bash
node --version       # must be ≥ 18
ui5 --version        # must be ≥ 3.0
mbt --version        # must be ≥ 1.2
cf --version         # Cloud Foundry CLI
```

If any tool is missing:
```bash
npm install -g @ui5/cli mbt
# CF CLI: https://docs.cloudfoundry.org/cf-cli/install-go-cli.html
```

---

## 2. Local Development

### Running the Control Tower locally

The app proxies API calls through the UI5 dev server to your S/4HANA system.
You must have network access to an S/4HANA system or BTP backend.

**Step 1** — Edit `packages/control-tower/ui5.yaml` and set the backend URL:
```yaml
backend:
  - path: /sap/opu/odata/sap/MM_PUR_PO_MAINT_V2_SRV
    url: https://YOUR-S4HANA-HOST.sap.com
    client: 100
```

**Step 2** — Start the dev server:
```bash
cd packages/control-tower
npm start
# Opens http://localhost:8080/index.html
```

**Step 3** — When prompted for credentials, use your S/4HANA RFC user and password.

> **No S/4HANA access?** The app will still load but all OData bindings will show empty tables. You can test UI layout and navigation without a backend.

### Running the Delay Library demo

```bash
cd packages/logistics-delay-lib
npm start
# Opens http://localhost:8081/demo/webapp/index.html
```

The demo uses sample data — no backend required. It demonstrates:
- `DelayMonitor` control with 6 sample shipments
- `RulesEditor` with all 10 default rules loaded
- `DelaySimulator` running Monte Carlo against all scenarios

### Running with TrackCargo locally

```bash
# Get your API key from https://trackcargo.co/signup
export TRACKCARGO_API_KEY="your-key-here"

# The UI5 proxy forwards /trackcargo/* to trackcargo.co
# Add to ui5.yaml if not already present:
# - path: /trackcargo
#   url: https://trackcargo.co
```

---

## 3. Understanding the Architecture

### Data flow — Control Tower

```
CEO Browser
    │
    ├──► GET /trackcargo/api/v1/client-orders/sea
    │         │
    │    App Router (BTP)
    │         │ injects Bearer token from TRACKCARGO_API destination
    │         └──► https://trackcargo.co/api/v1/client-orders/sea
    │
    └──► GET /sap/opu/odata/sap/MM_PUR_PO_MAINT_V2_SRV/PurchaseOrders
              │
         App Router (BTP)
              │ injects BasicAuth from S4HANA_BACKEND destination
              └──► https://your-s4h.sap.com/sap/opu/odata/...
```

### Key source files — Control Tower

| File | Role |
|---|---|
| `webapp/service/S4HanaService.js` | **All S/4HANA OData calls** — never call `oModel.read()` anywhere else |
| `webapp/service/TrackCargoService.js` | **All TrackCargo REST calls** — wraps `fetch()` via BTP proxy |
| `webapp/model/ErrorHandler.js` | Catches metadata failures + HTTP 4xx/5xx from all 4 OData models |
| `webapp/model/Formatter.js` | Pure formatter functions — PO/SO status, dates, amounts, states |
| `webapp/controller/BaseController.js` | Shared: service wiring, export, search, deep-link navigation |
| `approuter/xs-app.json` | Route rules — maps URL prefixes to BTP Destinations |
| `mta.yaml` | Deployment descriptor — creates all BTP services automatically |

### Key source files — Delay Library

| File | Role |
|---|---|
| `src/rules/RulesEngine.js` | Pure JS evaluator — no UI5 dependency, unit-testable |
| `src/simulation/DelaySimulationEngine.js` | Monte Carlo engine — Box-Muller sampling, 7 scenarios |
| `src/control/DelayMonitor.js` | Drop-in KPI + table control |
| `src/control/RulesEditor.js` | Business rules management UI |
| `src/control/DelaySimulatorControl.js` | Simulation UI with scenario comparison |

### Models in the Control Tower

| Model name | Type | Data source |
|---|---|---|
| `procurement` | ODataModel v2 | MM_PUR_PO_MAINT_V2_SRV |
| `sales` | ODataModel v2 | SD_F1493_SALESORDER_MANAGE_SRV |
| `bp` | ODataModel v2 | API_BUSINESS_PARTNER |
| `billing` | ODataModel v2 | SD_INVOICE_POST_SRV |
| `ui` | JSONModel | Computed KPIs + alert list from OData results |
| `device` | JSONModel | sap.ui.Device (responsive bindings) |

---

## 4. Deploying the Control Tower to BTP

### Step 1 — Log in to Cloud Foundry

```bash
cf login -a https://api.cf.us10-001.hana.ondemand.com
# Enter your BTP Trial email and password
# Select org: your-trial-org
# Select space: dev  (or create one: cf create-space dev)
```

### Step 2 — Create BTP services

Run this once per space. The `mta.yaml` creates these automatically on deploy,
but you can pre-create them manually:

```bash
cd packages/control-tower

cf create-service xsuaa application sap-control-tower-xsuaa \
  -c xs-security.json

cf create-service html5-apps-repo app-host \
  sap-control-tower-html5-repo-host

cf create-service html5-apps-repo app-runtime \
  sap-control-tower-html5-repo-runtime

cf create-service destination lite \
  sap-control-tower-dest
```

### Step 3 — Build the MTA archive

```bash
cd packages/control-tower
mbt build
# Output: mta_archives/sap-s4hana-control-tower_3.0.0.mtar
```

### Step 4 — Deploy

```bash
cf deploy mta_archives/sap-s4hana-control-tower_3.0.0.mtar
```

Watch the output. Full deploy takes 3–5 minutes. When complete:

```bash
cf apps
# NAME                              REQUESTED STATE   INSTANCES
# sap-control-tower-approuter       started           1/1
```

### Step 5 — Get the app URL

```bash
cf app sap-control-tower-approuter
# routes: sap-control-tower-approuter-xyz.cfapps.us10.hana.ondemand.com
```

Open the route URL in a browser. You will be redirected to SAP IDP login.

---

## 5. Deploying the Delay Library to BTP

The library deploys separately as a shared HTML5 App Repository resource.
Any BTP app in the same space can load it.

```bash
cd packages/logistics-delay-lib
mbt build
cf deploy mta_archives/com-logistics-delaylib_1.0.0.mtar
```

Verify it is served:
```bash
# The library is now accessible at the HTML5 App Repo runtime URL
# Other apps reference it via their manifest.json dependencies
```

---

## 6. Configuring BTP Destinations

All external API connections use the BTP Destination Service.
**Never hardcode credentials in source code.**

### Option A — Automated (recommended)

Edit `packages/control-tower/btpconfig/setup-btp-destinations.sh`:

```bash
S4HANA_HOST="https://YOUR-S4HANA-HOST.sap.com"
S4HANA_USER="RFC_USER"
S4HANA_PASSWORD="password"
TRACKCARGO_API_KEY="your-trackcargo-key"
SUBACCOUNT_GUID="your-btp-subaccount-guid"
```

Then run:
```bash
chmod +x btpconfig/setup-btp-destinations.sh
./btpconfig/setup-btp-destinations.sh
```

### Option B — Manual (BTP Cockpit UI)

Navigate to: **BTP Cockpit → Connectivity → Destinations → New Destination**

#### S4HANA_BACKEND

| Field | Value |
|---|---|
| Name | `S4HANA_BACKEND` |
| Type | `HTTP` |
| URL | `https://YOUR-S4HANA.sap.com` |
| Proxy Type | `Internet` (or `OnPremise` with Cloud Connector) |
| Authentication | `BasicAuthentication` |
| User | Your RFC user |
| Password | RFC user password |
| Additional Properties | `sap-client=100`, `HTML5.DynamicDestination=true` |

#### TRACKCARGO_API

| Field | Value |
|---|---|
| Name | `TRACKCARGO_API` |
| Type | `HTTP` |
| URL | `https://trackcargo.co` |
| Proxy Type | `Internet` |
| Authentication | `NoAuthentication` |
| Additional Properties | `HTML5.DynamicDestination=true` |
| Additional Headers | `Authorization=Bearer YOUR_TRACKCARGO_KEY` |

> ⚠️ The Authorization header in Additional Headers is injected server-side by the
> App Router. The API key never reaches the browser.

#### Test your destinations

In BTP Cockpit, click **Check Connection** on each destination.
Expected: `Connection to "TRACKCARGO_API" established. Response returned: "200: OK"`

---

## 7. Activating S/4HANA OData Services

In your SAP S/4HANA system, run transaction `/IWFND/MAINT_SERVICE` and activate:

| Technical Service Name | Description | Used by |
|---|---|---|
| `MM_PUR_PO_MAINT_V2_SRV` | Purchase Order Maintenance v2 | Procurement tab, Alerts tab |
| `SD_F1493_SALESORDER_MANAGE_SRV` | Manage Sales Orders | Sales tab, Overview KPIs |
| `API_BUSINESS_PARTNER` | Business Partner (Suppliers) | Suppliers tab |
| `SD_INVOICE_POST_SRV` | Post Billing Documents | Revenue KPIs |

**For each service:**
1. Click **Add Service**
2. Search by Technical Service Name
3. Select → **Add Selected Services**
4. Set **System Alias** to your system
5. Click **OK**

**Verify activation:**
```
GET /sap/opu/odata/sap/MM_PUR_PO_MAINT_V2_SRV/$metadata
```
Should return an XML metadata document.

**Permission required (PFCG role):**
```
S_SERVICE object with:
  SRV_NAME = MM_PUR_PO_MAINT_V2_SRV
  SRV_VERSION = 0001
```

---

## 8. Connecting TrackCargo API

### Get your API key

1. Sign up at [trackcargo.co/signup](https://trackcargo.co/signup)
2. Choose a plan (trial available)
3. Go to **Developer → API Keys** in your dashboard
4. Copy the Bearer token

### How it works in the app

The `TrackCargoService.js` prefixes all calls with `/trackcargo/`:

```javascript
// In TrackCargoService.js
var BASE_PATH = "/trackcargo";

// Call becomes:
fetch("/trackcargo/api/v1/client-orders/sea")
// App Router rewrites to:
// GET https://trackcargo.co/api/v1/client-orders/sea
// With header: Authorization: Bearer YOUR_KEY
```

The App Router route in `approuter/xs-app.json`:
```json
{
  "source": "^/trackcargo/(.*)$",
  "target": "/$1",
  "destination": "TRACKCARGO_API",
  "authenticationType": "none"
}
```

### Endpoints used

| Controller | TrackCargo endpoint |
|---|---|
| Logistics (overview KPIs) | `GET /api/v1/client-orders/sea/overview` |
| Logistics (overview KPIs) | `GET /api/v1/client-orders/air/overview` |
| Logistics (delay analytics) | `GET /api/v1/client-orders/sea` |
| Logistics (delay analytics) | `GET /api/v1/client-orders/air` |
| Logistics (main table) | `GET /api/v1/client-orders/recent` |
| Shipment row press | `GET /api/v1/client-orders/{id}/tracking` |
| Track New dialog | `POST /api/v1/client-orders/create` |

### For local development without BTP

```javascript
// In Logistics.controller.js onInit():
this._oTrackSvc.setApiKey("your-trackcargo-key");
// This injects the key directly into fetch() headers locally
// In production on BTP, this line is not needed — destination handles it
```

---

## 9. Using the Delay Library in Your App

### Add the library dependency

In your app's `manifest.json`:
```json
{
  "sap.ui5": {
    "dependencies": {
      "libs": {
        "com.logistics.delaylib": {}
      }
    }
  }
}
```

### Declare the XML namespace

```xml
<mvc:View
  xmlns:delaylib="com.logistics.delaylib"
  ...>
```

### DelayMonitor — drop-in delay panel

```xml
<delaylib:DelayMonitor
  id="myMonitor"
  title="Shipment Delays"
  subtitle="Live from TrackCargo"
  totalShipments="{myModel>/kpis/total}"
  delayedCount="{myModel>/kpis/delayed}"
  onTimeRate="{myModel>/kpis/onTimeRate}"
  avgDelayDays="{myModel>/kpis/avgDelay}"
  onTimeRateState="{myModel>/kpis/rateState}"
  showKpis="true"
  showTable="true"
  showAlerts="true"
  rowPress="onShipmentPress"
  refresh="onRefresh"/>
```

Bind shipment data from your controller:
```javascript
var oMonitor = this.byId("myMonitor");
oMonitor.bindShipmentData("myModel", "/shipments");
```

### RulesEditor — business rules management

```xml
<delaylib:RulesEditor
  id="myEditor"
  editable="true"
  showTestPanel="true"
  ruleSave="onRuleSaved"
  ruleDelete="onRuleDeleted"
  ruleTest="onRuleTested"/>
```

Load rules from the engine:
```javascript
var oEditor = this.byId("myEditor");
oEditor.loadFromEngine(this._oRulesEngine);
```

### DelaySimulator — simulation UI

```xml
<delaylib:DelaySimulator
  id="mySimulator"
  iterations="1000"
  demurrageDayRate="500"
  simulationComplete="onSimDone"/>
```

---

## 10. Authoring Business Rules

### Rule anatomy

```json
{
  "id":             "MY_RULE_001",
  "name":           "High-Value Air Freight Delayed",
  "description":    "Alert when air shipment worth over $50K is delayed",
  "active":         true,
  "severity":       "Error",
  "priority":       8,
  "mode":           ["Air"],
  "conditionLogic": "AND",
  "conditions": [
    { "field": "mode",      "operator": "eq",  "value": "Air"   },
    { "field": "value",     "operator": "gt",  "value": 50000   },
    { "field": "delayDays", "operator": "gte", "value": 1       }
  ],
  "actions": [
    {
      "type":    "alert",
      "message": "Air freight {reference} (${{value}}) delayed {delayDays}d",
      "target":  "CEO_DASHBOARD"
    },
    {
      "type":    "escalate",
      "message": "High-value air delay — escalate to logistics VP",
      "target":  "LOGISTICS_VP"
    }
  ],
  "tags": ["air", "high-value", "escalate"]
}
```

### Priority guide

| Priority range | Use for |
|---|---|
| 1–9 | Critical safety-net rules (always fire first) |
| 10–19 | Standard operational rules |
| 20–49 | Advisory and informational rules |
| 50+ | Experimental / disabled-by-default rules |

### Available condition operators

| Operator | Example | Use for |
|---|---|---|
| `eq` | `"mode" eq "Air"` | Exact match |
| `neq` | `"status" neq "Completed"` | Not equal |
| `gt` / `gte` | `"delayDays" gt 5` | Numeric threshold |
| `lt` / `lte` | `"value" lt 10000` | Numeric threshold |
| `contains` | `"status" contains "customs"` | Substring match |
| `in` | `"carrier" in ["BASF","FOGR"]` | Allowlist |
| `notIn` | `"pol" notIn ["Hamburg"]` | Blocklist |
| `between` | `"delayDays" between [3,7]` | Range check |
| `regex` | `"reference" regex "^MAEU"` | Pattern match |
| `isNull` | `"soReference" isNull` | Empty check |
| `isNotNull` | `"soReference" isNotNull` | Presence check |

### Message template tokens

In the `message` field, use `{fieldName}` to interpolate shipment context values:

```
"Shipment {reference} from {carrier} ({pol}→{pod}) is {delayDays} days late."
```

Available tokens: `orderId`, `reference`, `carrier`, `mode`, `pol`, `pod`,
`eta`, `status`, `value`, `currency`, `delayDays`, `soReference`, `poReference`

### Testing rules in the RulesEditor

1. Open the **Rules** tab in the app
2. Expand the **Rule Test Sandbox** panel at the bottom
3. Edit the JSON to represent your target shipment
4. Click **Run All Rules Against Test Shipment**
5. Matched rules appear highlighted with their action messages

### Exporting rules for team sharing

```javascript
var oEngine = new RulesEngine();
oEngine.loadRules(myRules);

// Export as JSON string — share with team or persist to backend
var sJson = oEngine.exportRules();
console.log(sJson);

// Import from team-shared JSON
oEngine.importRules(sJson);
```

---

## 11. Running Delay Simulations

### Choosing a scenario

| Scenario | When to use |
|---|---|
| `Baseline` | Normal market conditions |
| `PortCongestion` | Major port congestion (e.g. Long Beach, Shanghai) |
| `WeatherDisruption` | Storm season, typhoon risk |
| `CustomsDelay` | New trade regulations, documentation issues |
| `CapacityShortage` | Peak season, container shortage |
| `Strike` | Labour action at port or carrier |
| `Geopolitical` | Sanctions, route disruption (Suez, Panama) |

### Interpreting simulation results

| Metric | Meaning |
|---|---|
| **P50 (median)** | Half of all simulation runs had delays below this value |
| **P90** | 90% of runs had delays below this — use for SLA planning |
| **P99** | Worst-case tail risk — budget for this in high-value contracts |
| **On-time probability** | % of runs where the shipment arrived on schedule |
| **Cost P90** | 90th percentile cost = demurrage + expedite freight upgrade |

### Programmatic simulation

```javascript
sap.ui.require([
  "com/logistics/delaylib/simulation/DelaySimulationEngine"
], function (Engine) {

  var oEngine = new Engine({ iterations: 5000, demurrageDayRate: 600 });

  var oShipment = {
    reference: "MAEU123456",
    mode: "Sea",
    value: 250000,
    pol: "Rotterdam",
    pod: "Shanghai"
  };

  // Single scenario
  var oResult = oEngine.simulate(oShipment, "PortCongestion");
  console.log("P90 delay:", oResult.delays.p90, "days");
  console.log("Cost P90: $" + oResult.costs.p90);

  // Compare all 7 scenarios
  var oComp = oEngine.compareScenarios(oShipment, [
    "Baseline", "PortCongestion", "Strike", "Geopolitical"
  ]);
  oComp.comparison.forEach(function (s) {
    console.log(s.scenario, "— P90:", s.p90 + "d, Delay%:", s.delayProb + "%");
  });

  // Custom scenario
  oEngine.registerScenario("RedSeaCrisis", {
    portDelay:    { min: 5, max: 20, mean: 10, stdDev: 4 },
    transitDelay: { min: 7, max: 28, mean: 14, stdDev: 6 },
    customsDelay: { min: 2, max: 8,  mean: 4,  stdDev: 2 },
    weatherDelay: { min: 0, max: 3,  mean: 1,  stdDev: 1 },
    carrierDelay: { min: 3, max: 12, mean: 6,  stdDev: 3 },
    eventProb:    0.35
  });

  var oRedSea = oEngine.simulate(oShipment, "RedSeaCrisis");
  console.log("Red Sea P99:", oRedSea.delays.p99, "days");
});
```

---

## 12. Role Management & Security

### BTP Roles

| Role Collection | Who gets it | Access |
|---|---|---|
| `Control_Tower_CEO` | CEO, C-suite, board | View all dashboards, all KPIs |
| `Control_Tower_Admin` | IT team, BTP admin | All CEO access + settings |

### Assign roles

In **BTP Cockpit → Security → Role Collections**:
1. Find `Control_Tower_CEO`
2. Click **Edit → Users**
3. Add user by email (must be registered in the BTP trust configuration)

### Adding a new role

1. Edit `xs-security.json`:
```json
{
  "scopes": [
    { "name": "$XSAPPNAME.Export", "description": "Export data to Excel" }
  ],
  "role-templates": [
    {
      "name": "CEO_Exporter",
      "scope-references": ["$XSAPPNAME.View", "$XSAPPNAME.Export"]
    }
  ],
  "role-collections": [
    {
      "name": "Control_Tower_Export",
      "role-template-references": ["$XSAPPNAME.CEO_Exporter"]
    }
  ]
}
```

2. Redeploy:
```bash
mbt build && cf deploy mta_archives/*.mtar
```

### Security architecture

- All traffic over HTTPS — no plain HTTP anywhere
- API keys stored in BTP Destination service (encrypted at rest)
- API keys injected server-side by App Router — never reach the browser
- XSUAA validates JWT on every request to protected routes
- TrackCargo route (`/trackcargo/*`) has `authenticationType: none` — protected by TrackCargo's own Bearer token

---

## 13. CI/CD with GitHub Actions

The repository includes two workflows in `.github/workflows/`:

### `ci.yml` — runs on every Pull Request

```yaml
# .github/workflows/ci.yml
name: CI — Lint and Build

on:
  pull_request:
    branches: [main, develop]

jobs:
  lint-and-build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - name: Install tools
        run: npm ci && npm install -g @ui5/cli mbt
      - name: Lint Control Tower
        run: cd packages/control-tower && npx eslint webapp/
      - name: Build Control Tower
        run: cd packages/control-tower && npm install && mbt build
      - name: Build Delay Library
        run: cd packages/logistics-delay-lib && npm install && mbt build
      - name: Upload artifacts
        uses: actions/upload-artifact@v4
        with:
          name: mtar-archives
          path: |
            packages/control-tower/mta_archives/*.mtar
            packages/logistics-delay-lib/mta_archives/*.mtar
```

### `deploy.yml` — runs on merge to main

```yaml
# .github/workflows/deploy.yml
name: Deploy to SAP BTP

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    environment: production
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - name: Install tools
        run: npm install -g @ui5/cli mbt
      - name: Install CF CLI
        run: |
          curl -L "https://packages.cloudfoundry.org/stable?release=linux64-binary&version=v8" | tar -xz
          sudo mv cf8 /usr/local/bin/cf
      - name: CF Login
        env:
          CF_API:      ${{ secrets.CF_API_ENDPOINT }}
          CF_USERNAME: ${{ secrets.CF_USERNAME }}
          CF_PASSWORD: ${{ secrets.CF_PASSWORD }}
          CF_ORG:      ${{ secrets.CF_ORG }}
          CF_SPACE:    ${{ secrets.CF_SPACE }}
        run: cf login -a $CF_API -u $CF_USERNAME -p $CF_PASSWORD -o $CF_ORG -s $CF_SPACE
      - name: Build and deploy Delay Library
        run: |
          cd packages/logistics-delay-lib
          npm install && mbt build
          cf deploy mta_archives/com-logistics-delaylib_1.0.0.mtar --no-confirm
      - name: Build and deploy Control Tower
        run: |
          cd packages/control-tower
          npm install && mbt build
          cf deploy mta_archives/sap-s4hana-control-tower_3.0.0.mtar --no-confirm
```

### Required GitHub Secrets

Set these in **GitHub → Settings → Secrets → Actions**:

| Secret | Value |
|---|---|
| `CF_API_ENDPOINT` | `https://api.cf.us10-001.hana.ondemand.com` |
| `CF_USERNAME` | BTP user email |
| `CF_PASSWORD` | BTP password |
| `CF_ORG` | Your CF org name |
| `CF_SPACE` | Your CF space name (e.g. `dev`) |

---

## 14. Troubleshooting

### OData calls return 401 Unauthorized

**Cause:** XSUAA role not assigned or destination credentials wrong.

**Fix:**
1. Check user has `Control_Tower_CEO` role in BTP Cockpit → Security
2. Check `S4HANA_BACKEND` destination credentials in BTP Cockpit → Connectivity

### OData calls return 404 Not Found

**Cause:** S/4HANA OData service not activated.

**Fix:**
1. Log into S/4HANA, run `/IWFND/MAINT_SERVICE`
2. Search for the service name and activate it

### TrackCargo API returns 401

**Cause:** API key wrong or expired, or destination `Authorization` header not set.

**Fix:**
1. In BTP Cockpit → Destinations → `TRACKCARGO_API` → Additional Properties
2. Verify `Authorization` = `Bearer YOUR_KEY` (not `Bearer YOUR_KEY` with extra spaces)
3. Click **Check Connection** — must return 200

### App loads but all KPIs show `—`

**Cause:** OData calls succeed but the fiscal year filter doesn't match S/4HANA data.

**Fix:**
1. Open browser DevTools → Network tab
2. Check `/PurchaseOrders?...` response — does it return `results: []`?
3. If yes, the date filter excludes all records — change fiscal year selector in the filter bar

### `mbt build` fails with "No module found"

**Cause:** `mbt` global not installed or wrong version.

**Fix:**
```bash
npm uninstall -g mbt
npm install -g mbt@latest
mbt --version  # should show 1.2+
```

### `cf deploy` fails with "service already exists"

**Cause:** BTP services from a previous deploy conflict.

**Fix:**
```bash
# Add --skip-existing-services flag
cf deploy mta_archives/*.mtar --skip-existing-services
```

### Library control not rendering

**Cause:** Library not loaded before the view renders.

**Fix:**
Ensure `com.logistics.delaylib` is in `manifest.json` dependencies:
```json
"dependencies": {
  "libs": {
    "sap.m": {},
    "com.logistics.delaylib": {}
  }
}
```

---

## 15. FAQ

**Q: Can I use this with SAP S/4HANA Cloud (public edition)?**
> Yes — replace `BasicAuthentication` with `OAuth2SAMLBearerAssertion` in the BTP Destination and use the S/4HANA Cloud OData service URLs. The service names are the same.

**Q: Can I use this with SAP ECC (on-prem, older system)?**
> Partially. `MM_PUR_PO_MAINT_V2_SRV` requires S/4HANA. For ECC, replace with `/sap/opu/odata/sap/MM_PUR_PO_SRV/` and update field mappings in `S4HanaService.js`.

**Q: How do I add a new tab/page?**
> 1. Create `webapp/view/MyTab.view.xml`
> 2. Create `webapp/controller/MyTab.controller.js` extending `BaseController`
> 3. Add a route in `manifest.json` routing section
> 4. Add a `NavigationListItem` in `App.view.xml`

**Q: How do I persist business rules to a database?**
> Call `oEngine.exportRules()` to get a JSON string, then POST it to an SAP HANA Cloud table or BTP Object Store. Load it back on startup with `oEngine.importRules(sJson)`. See `INTEGRATION.md` for an Object Store example.

**Q: Can the simulation run in a backend service instead of the browser?**
> Yes — `DelaySimulationEngine.js` has no browser dependencies. Copy it to a Node.js service or CAP application and call it from there.

**Q: How do I add a new TrackCargo endpoint?**
> Add a new method to `webapp/service/TrackCargoService.js` following the existing pattern. The `_get()` and `_post()` methods handle all HTTP plumbing.

**Q: How do I add a new S/4HANA OData entity set?**
> Add a new method to `webapp/service/S4HanaService.js`. Use the appropriate model (`_oProcModel`, `_oSalesModel`, `_oBPModel`, `_oBillingModel`) and call `this._read(oModel, "/EntitySet", { ... })`.

**Q: Is there a BTP Free Tier alternative to the Trial?**
> Yes — SAP BTP Free Tier gives permanent (not time-limited) access to CF, HTML5 App Repo, Destination Service, and XSUAA at no cost. See [SAP BTP Free Tier](https://www.sap.com/products/technology-platform/trial.html).
