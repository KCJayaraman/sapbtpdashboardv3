/**
 * TrackCargoService.js
 * ─────────────────────────────────────────────────────────────────────────────
 * REST API client for trackcargo.co (https://trackcargo.co/developer)
 *
 * All HTTP calls are routed through the SAP BTP Destination "TRACKCARGO_API"
 * configured in BTP Cockpit → Connectivity → Destinations.
 * The App Router (approuter) proxies /trackcargo/* → trackcargo.co API,
 * injecting the API key from the destination's Additional Headers.
 *
 * TrackCargo REST API v1.0:
 *   Base URL  : https://trackcargo.co
 *   Auth      : Bearer token (API key) in Authorization header
 *   Endpoints used:
 *     GET  /api/v1/client-orders/recent              → all recent orders
 *     GET  /api/v1/client-orders/sea                 → sea freight orders
 *     GET  /api/v1/client-orders/air                 → air freight orders
 *     GET  /api/v1/client-orders/sea/overview        → sea shipments overview
 *     GET  /api/v1/client-orders/air/overview        → air shipments overview
 *     GET  /api/v1/client-orders/{orderId}           → single order detail
 *     GET  /api/v1/client-orders/{orderId}/tracking  → live tracking events
 *     POST /api/v1/client-orders/create              → create tracking order
 *     GET  /api/tracking/api/v1/active-airlines      → supported airlines
 *     GET  /api/tracking/api/v1/active-shipping-lines→ supported carriers
 *
 * ─────────────────────────────────────────────────────────────────────────────
 */
sap.ui.define([
  "sap/ui/base/Object",
  "sap/m/MessageToast"
], function (BaseObject, MessageToast) {
  "use strict";

  /**
   * Base path for all TrackCargo API calls.
   * The approuter xs-app.json maps this prefix → TRACKCARGO_API destination.
   */
  var BASE_PATH = "/trackcargo";

  return BaseObject.extend("com.company.controltower.service.TrackCargoService", {

    /**
     * @param {sap.ui.model.json.JSONModel} oUIModel  the "ui" model for busy state
     */
    constructor: function (oUIModel) {
      this._oUIModel = oUIModel;
      this._sApiKey  = "";   // Set at runtime via setApiKey() or BTP Destination header
    },

    /**
     * Allow runtime API key injection (for local dev without BTP Destination).
     * In production on BTP, the key is injected by the destination Additional Header.
     * @param {string} sKey  TrackCargo API key
     */
    setApiKey: function (sKey) {
      this._sApiKey = sKey;
    },

    // ═══════════════════════════════════════════════════════════════════════
    // ORDER MANAGEMENT ENDPOINTS
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * GET /api/v1/client-orders/recent
     * Returns the most recently created tracking orders across all modes.
     * @param {number} [nLimit=50]
     * @returns {Promise<Array>}  array of order objects
     */
    getRecentOrders: function (nLimit) {
      return this._get("/api/v1/client-orders/recent", {
        limit: nLimit || 50
      }).then(function (oRes) {
        return oRes.orders || oRes.data || oRes || [];
      });
    },

    /**
     * GET /api/v1/client-orders/sea
     * Returns all sea freight tracking orders.
     * @returns {Promise<Array>}
     */
    getSeaOrders: function () {
      return this._get("/api/v1/client-orders/sea")
        .then(function (oRes) {
          return oRes.orders || oRes.data || oRes || [];
        });
    },

    /**
     * GET /api/v1/client-orders/air
     * Returns all air freight tracking orders.
     * @returns {Promise<Array>}
     */
    getAirOrders: function () {
      return this._get("/api/v1/client-orders/air")
        .then(function (oRes) {
          return oRes.orders || oRes.data || oRes || [];
        });
    },

    /**
     * GET /api/v1/client-orders/sea/overview
     * Returns aggregate statistics for sea shipments:
     *   total, onTime, delayed, inTransit, arrived, etc.
     * @returns {Promise<object>}
     */
    getSeaOverview: function () {
      return this._get("/api/v1/client-orders/sea/overview")
        .then(function (oRes) {
          return oRes.overview || oRes.data || oRes || {};
        });
    },

    /**
     * GET /api/v1/client-orders/air/overview
     * Returns aggregate statistics for air shipments.
     * @returns {Promise<object>}
     */
    getAirOverview: function () {
      return this._get("/api/v1/client-orders/air/overview")
        .then(function (oRes) {
          return oRes.overview || oRes.data || oRes || {};
        });
    },

    /**
     * GET /api/v1/client-orders/{orderId}
     * Returns full detail for a single tracking order.
     * @param {string} sOrderId
     * @returns {Promise<object>}
     */
    getOrderDetail: function (sOrderId) {
      return this._get("/api/v1/client-orders/" + encodeURIComponent(sOrderId))
        .then(function (oRes) {
          return oRes.order || oRes.data || oRes || {};
        });
    },

    /**
     * GET /api/v1/client-orders/{orderId}/tracking
     * Returns the live tracking event timeline for a single order.
     * Events include: departed, arrived, customs, delayed, delivered.
     * @param {string} sOrderId
     * @returns {Promise<object>}  { events: [], currentStatus, eta, delayDays }
     */
    getOrderTracking: function (sOrderId) {
      return this._get(
        "/api/v1/client-orders/" + encodeURIComponent(sOrderId) + "/tracking"
      ).then(function (oRes) {
        return oRes.tracking || oRes.data || oRes || {};
      });
    },

    /**
     * POST /api/v1/client-orders/create
     * Creates a new shipment tracking order.
     *
     * @param {object} oPayload
     * @param {string} oPayload.type          "sea" | "air"
     * @param {string} oPayload.trackingNumber BL number, container ID, or AWB
     * @param {string} oPayload.carrier        Carrier SCAC or IATA code
     * @param {string} [oPayload.reference]   Internal PO or SO reference
     * @param {string} [oPayload.description] Free-text description
     * @returns {Promise<object>}  { orderId, status, message }
     */
    createOrder: function (oPayload) {
      return this._post("/api/v1/client-orders/create", {
        type:           oPayload.type,
        trackingNumber: oPayload.trackingNumber,
        carrier:        oPayload.carrier,
        reference:      oPayload.reference   || "",
        description:    oPayload.description || ""
      });
    },

    // ═══════════════════════════════════════════════════════════════════════
    // CARRIER / AIRLINE REFERENCE ENDPOINTS
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * GET /api/tracking/api/v1/active-airlines
     * Returns list of supported airlines with IATA codes.
     * @returns {Promise<Array>}  [{ name, iataCode, logo }, ...]
     */
    getActiveAirlines: function () {
      return this._get("/api/tracking/api/v1/active-airlines")
        .then(function (oRes) {
          return oRes.airlines || oRes.data || oRes || [];
        });
    },

    /**
     * GET /api/tracking/api/v1/active-shipping-lines
     * Returns list of supported shipping lines with SCAC codes.
     * @returns {Promise<Array>}  [{ name, scacCode, logo }, ...]
     */
    getActiveShippingLines: function () {
      return this._get("/api/tracking/api/v1/active-shipping-lines")
        .then(function (oRes) {
          return oRes.shippingLines || oRes.data || oRes || [];
        });
    },

    // ═══════════════════════════════════════════════════════════════════════
    // ANALYTICS & DELAY COMPUTATION
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Fetches all shipments (sea + air), then computes delay metrics:
     *   - Total in transit
     *   - Delayed count + avg delay days
     *   - On-time rate
     *   - Delay by carrier
     *   - Delay by trade lane (origin → destination)
     *   - Recent delay events (last 10)
     *
     * @returns {Promise<object>}  full delay analytics object
     */
    getDelayAnalytics: function () {
      var that = this;
      return Promise.all([
        that.getSeaOrders(),
        that.getAirOrders()
      ]).then(function (aResults) {
        var aSeaOrders = aResults[0] || [];
        var aAirOrders = aResults[1] || [];
        var aAll       = aSeaOrders.concat(aAirOrders);
        return that._computeDelayMetrics(aAll, aSeaOrders, aAirOrders);
      });
    },

    /**
     * Fetches both sea and air overviews, merges into one summary.
     * @returns {Promise<object>}
     */
    getCombinedOverview: function () {
      return Promise.all([
        this.getSeaOverview(),
        this.getAirOverview()
      ]).then(function (aR) {
        var oSea = aR[0] || {};
        var oAir = aR[1] || {};
        return {
          totalShipments:  (oSea.total    || 0) + (oAir.total    || 0),
          delayed:         (oSea.delayed  || 0) + (oAir.delayed  || 0),
          onTime:          (oSea.onTime   || 0) + (oAir.onTime   || 0),
          inTransit:       (oSea.inTransit|| 0) + (oAir.inTransit|| 0),
          arrived:         (oSea.arrived  || 0) + (oAir.arrived  || 0),
          seaTotal:        oSea.total    || 0,
          airTotal:        oAir.total    || 0,
          seaDelayed:      oSea.delayed  || 0,
          airDelayed:      oAir.delayed  || 0,
          seaOnTimeRate:   oSea.onTimeRate || oSea.onTime_rate || 0,
          airOnTimeRate:   oAir.onTimeRate || oAir.onTime_rate || 0
        };
      });
    },

    // ═══════════════════════════════════════════════════════════════════════
    // INTERNAL — Delay computation
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Derives delay analytics from raw order arrays.
     * Field names follow common TrackCargo response patterns;
     * uses optional chaining fallbacks for schema flexibility.
     */
    _computeDelayMetrics: function (aAll, aSeaOrders, aAirOrders) {
      var nTotal    = aAll.length;
      var nDelayed  = 0;
      var nOnTime   = 0;
      var nTransit  = 0;
      var fDelaySum = 0;
      var oCarrierMap   = {};   // { carrierName: { delayed, total } }
      var oLaneMap      = {};   // { "POL→POD": { delayed, total } }
      var aRecentDelays = [];

      aAll.forEach(function (oOrder) {
        var sStatus   = (oOrder.status || oOrder.trackingStatus || "").toLowerCase();
        var bDelayed  = sStatus.includes("delay") ||
                        oOrder.isDelayed === true  ||
                        oOrder.delayed   === true  ||
                        (typeof oOrder.delayDays === "number" && oOrder.delayDays > 0);

        var nDelayDays = parseFloat(oOrder.delayDays || oOrder.delay_days || 0);
        var sCarrier   = oOrder.carrier || oOrder.carrierName || oOrder.shippingLine || "Unknown";
        var sPOL       = oOrder.portOfLoading    || oOrder.origin      || oOrder.pol || "?";
        var sPOD       = oOrder.portOfDischarge   || oOrder.destination || oOrder.pod || "?";
        var sLane      = sPOL + " → " + sPOD;

        if (bDelayed) {
          nDelayed++;
          fDelaySum += nDelayDays;
          aRecentDelays.push({
            orderId:    oOrder.orderId    || oOrder.id        || "—",
            reference:  oOrder.reference || oOrder.blNumber  || oOrder.awbNumber || "—",
            carrier:    sCarrier,
            mode:       oOrder.type || oOrder.mode || "sea",
            pol:        sPOL,
            pod:        sPOD,
            delayDays:  Math.round(nDelayDays),
            eta:        oOrder.eta        || oOrder.estimatedArrival || "—",
            status:     oOrder.status     || "Delayed",
            statusState:"Error"
          });
        } else if (sStatus.includes("transit") || sStatus.includes("progress")) {
          nTransit++;
        } else if (sStatus.includes("deliver") || sStatus.includes("arriv") ||
                   sStatus.includes("complet")) {
          nOnTime++;
        }

        // Carrier breakdown
        if (!oCarrierMap[sCarrier]) {
          oCarrierMap[sCarrier] = { carrier: sCarrier, delayed: 0, total: 0 };
        }
        oCarrierMap[sCarrier].total++;
        if (bDelayed) { oCarrierMap[sCarrier].delayed++; }

        // Trade lane breakdown
        if (!oLaneMap[sLane]) {
          oLaneMap[sLane] = { lane: sLane, pol: sPOL, pod: sPOD, delayed: 0, total: 0 };
        }
        oLaneMap[sLane].total++;
        if (bDelayed) { oLaneMap[sLane].delayed++; }
      });

      // Sort and enrich carrier/lane arrays
      var aCarriers = Object.values(oCarrierMap)
        .map(function (o) {
          o.delayRate = o.total ? Math.round((o.delayed / o.total) * 100) : 0;
          o.delayRateState = o.delayRate > 30 ? "Error"
                           : o.delayRate > 15 ? "Warning" : "Success";
          return o;
        })
        .sort(function (a, b) { return b.delayed - a.delayed; })
        .slice(0, 10);

      var aLanes = Object.values(oLaneMap)
        .map(function (o) {
          o.delayRate = o.total ? Math.round((o.delayed / o.total) * 100) : 0;
          o.delayRateState = o.delayRate > 30 ? "Error"
                           : o.delayRate > 15 ? "Warning" : "Success";
          return o;
        })
        .sort(function (a, b) { return b.delayed - a.delayed; })
        .slice(0, 8);

      aRecentDelays.sort(function (a, b) { return b.delayDays - a.delayDays; });

      var nOnTimeRate = nTotal ? Math.round(((nTotal - nDelayed) / nTotal) * 100) : 100;
      var fAvgDelay   = nDelayed ? Math.round(fDelaySum / nDelayed) : 0;

      return {
        totalShipments: nTotal,
        delayed:        nDelayed,
        onTime:         nOnTime,
        inTransit:      nTransit,
        onTimeRate:     nOnTimeRate,
        avgDelayDays:   fAvgDelay,
        totalSeaOrders: aSeaOrders.length,
        totalAirOrders: aAirOrders.length,
        carrierBreakdown: aCarriers,
        laneBreakdown:    aLanes,
        recentDelays:     aRecentDelays.slice(0, 20),
        onTimeRateState:  nOnTimeRate >= 90 ? "Success"
                        : nOnTimeRate >= 75 ? "Warning" : "Error"
      };
    },

    // ═══════════════════════════════════════════════════════════════════════
    // HTTP LAYER — routed via BTP Destination
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * HTTP GET via the BTP App Router proxy (/trackcargo/...).
     * @param {string} sPath        API path, e.g. "/api/v1/client-orders/sea"
     * @param {object} [oParams]    Query string key-value pairs
     * @returns {Promise<object>}
     */
    _get: function (sPath, oParams) {
      var sUrl = BASE_PATH + sPath;
      if (oParams && Object.keys(oParams).length > 0) {
        var sParts = Object.keys(oParams).map(function (k) {
          return encodeURIComponent(k) + "=" + encodeURIComponent(oParams[k]);
        }).join("&");
        sUrl += "?" + sParts;
      }
      return this._fetch(sUrl, {
        method: "GET"
      });
    },

    /**
     * HTTP POST via the BTP App Router proxy.
     * @param {string} sPath   API path
     * @param {object} oBody   JSON request body
     * @returns {Promise<object>}
     */
    _post: function (sPath, oBody) {
      return this._fetch(BASE_PATH + sPath, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(oBody)
      });
    },

    /**
     * Core fetch wrapper.
     * In BTP: Authorization header is injected by the App Router Destination.
     * In local dev: passes this._sApiKey if set via setApiKey().
     * @returns {Promise<object>}
     */
    _fetch: function (sUrl, oInit) {
      var oHeaders = Object.assign({
        "Accept": "application/json"
      }, oInit.headers || {});

      // Local dev only — in BTP the destination injects the header automatically
      if (this._sApiKey) {
        oHeaders["Authorization"] = "Bearer " + this._sApiKey;
      }

      return fetch(sUrl, {
        method:      oInit.method  || "GET",
        headers:     oHeaders,
        body:        oInit.body    || undefined,
        credentials: "same-origin" // required for BTP App Router session cookies
      }).then(function (oResponse) {
        if (!oResponse.ok) {
          return oResponse.text().then(function (sBody) {
            var sMsg;
            try {
              var oErr = JSON.parse(sBody);
              sMsg = oErr.message || oErr.error || sBody;
            } catch (e) {
              sMsg = sBody || oResponse.statusText;
            }
            throw new Error(
              "TrackCargo API " + oResponse.status + ": " + sMsg +
              " [" + sUrl + "]"
            );
          });
        }
        return oResponse.json();
      }).catch(function (oError) {
        jQuery.sap.log.error("[TrackCargoService] " + oError.message);
        throw oError;
      });
    }
  });
});
