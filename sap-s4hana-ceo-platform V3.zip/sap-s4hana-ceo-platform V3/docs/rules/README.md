# Rules Library

This folder is the team's shared repository of business rules for the
`com.logistics.delaylib` Rules Engine.

## How to use these files

### Load into the app

In the Rules tab of the Control Tower, click **↑ Import**, paste the contents of any
JSON file here, and click **Import**. Rules are merged — existing rules with the same
ID are updated, new IDs are added.

### Export and commit back

After creating or editing rules in the app, click **↓ Export**. Commit the downloaded
file here so the rest of the team can use it.

### Load programmatically at startup

```javascript
// In a controller onInit() or Component.js
fetch("/rules/default-rules-v1.json")
  .then(function(r) { return r.json(); })
  .then(function(aRules) {
    oEngine.loadRules(aRules);
  });
```

## Files in this folder

| File | Description | Status |
|---|---|---|
| `default-rules-v1.json` | 10 built-in rules shipped with the library | Active |

## Naming convention for new files

```
{team}-{area}-rules.json

Examples:
  emea-procurement-rules.json
  apac-customs-rules.json
  finance-high-value-rules.json
  seasonal-weather-rules.json
```

## Adding a new rule file

1. Create your rules using the **Rules Editor** in the app
2. Export the JSON
3. Save to this folder with a descriptive name
4. Open a PR — another team member should review the rule logic
5. Merge to `main` — the rules are now part of the team's shared library
