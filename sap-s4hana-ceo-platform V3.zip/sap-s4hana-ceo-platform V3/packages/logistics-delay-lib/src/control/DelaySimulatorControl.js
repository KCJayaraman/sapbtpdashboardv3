/**
 * DelaySimulatorControl.js
 * com.logistics.delaylib.control.DelaySimulator
 * ─────────────────────────────────────────────────────────────────────────────
 * SAP UI5 control that wraps DelaySimulationEngine and renders an interactive
 * simulation UI with scenario selection, parameter tuning, and result charts.
 *
 * XML usage:
 *   <delaylib:DelaySimulator
 *     id="simulator"
 *     title="Delay Simulation"
 *     iterations="1000"
 *     simulationComplete="onSimulationDone"/>
 * ─────────────────────────────────────────────────────────────────────────────
 */
sap.ui.define([
  "sap/ui/core/Control",
  "sap/ui/model/json/JSONModel",
  "sap/m/VBox",
  "sap/m/HBox",
  "sap/m/Text",
  "sap/m/Title",
  "sap/m/Button",
  "sap/m/Select",
  "sap/m/Input",
  "sap/m/Label",
  "sap/m/Slider",
  "sap/m/ObjectStatus",
  "sap/m/ObjectNumber",
  "sap/m/MessageStrip",
  "sap/m/Toolbar",
  "sap/m/ToolbarSpacer",
  "sap/m/Table",
  "sap/m/Column",
  "sap/m/ColumnListItem",
  "sap/m/ProgressIndicator",
  "sap/ui/core/Item",
  "sap/m/Panel",
  "sap/m/BusyIndicator",
  "sap/m/MessageToast",
  "com/logistics/delaylib/simulation/DelaySimulationEngine"
], function (
  Control, JSONModel, VBox, HBox, Text, Title, Button, Select, Input,
  Label, Slider, ObjectStatus, ObjectNumber, MessageStrip, Toolbar,
  ToolbarSpacer, Table, Column, ColumnListItem, ProgressIndicator,
  Item, Panel, BusyIndicator, MessageToast, DelaySimulationEngine
) {
  "use strict";

  return Control.extend("com.logistics.delaylib.control.DelaySimulator", {

    metadata: {
      library: "com.logistics.delaylib",
      properties: {
        title:            { type: "string",  defaultValue: "Delay Simulation"  },
        iterations:       { type: "int",     defaultValue: 1000                },
        demurrageDayRate: { type: "float",   defaultValue: 500                 },
        expediteCostRate: { type: "float",   defaultValue: 0.03                },
        showComparison:   { type: "boolean", defaultValue: true                },
        showBatchMode:    { type: "boolean", defaultValue: true                }
      },
      aggregations: {
        _content: { type: "sap.ui.core.Control", multiple: false, visibility: "hidden" }
      },
      events: {
        simulationComplete: {
          parameters: {
            scenario: { type: "string" },
            result:   { type: "object" }
          }
        }
      }
    },

    init: function () {
      Control.prototype.init.apply(this, arguments);
      this._oEngine = new DelaySimulationEngine({
        iterations:      this.getIterations(),
        demurrageDayRate:this.getDemurrageDayRate(),
        expediteCostRate:this.getExpediteCostRate()
      });
      this._oSimModel = new JSONModel({
        busy:          false,
        result:        null,
        comparison:    null,
        batchResult:   null,
        scenarios:     ["Baseline","PortCongestion","WeatherDisruption","CustomsDelay","CapacityShortage","Strike","Geopolitical"],
        selectedScenario: "Baseline",
        compareScenarios: ["Baseline","PortCongestion","Strike"],
        shipment: {
          orderId: "SIM-001", reference: "MAEU123456789",
          carrier: "Maersk", mode: "Sea",
          pol: "Rotterdam", pod: "Shanghai",
          value: 250000, currency: "USD"
        },
        iterations: 1000
      });
      this._buildContent();
    },

    renderer: {
      apiVersion: 2,
      render: function (oRm, oControl) {
        oRm.openStart("div", oControl);
        oRm.class("ldlSimulator");
        oRm.openEnd();
        oRm.renderControl(oControl.getAggregation("_content"));
        oRm.close("div");
      }
    },

    // ── Build UI ─────────────────────────────────────────────────────────────

    _buildContent: function () {
      var that = this;

      // ── Input panel ──
      var oInputPanel = new Panel({
        headerText: "Simulation Parameters",
        expandable: true,
        expanded:   true
      });

      var oInputGrid = new HBox({ wrap: "Wrap", alignItems: "Start" }).addStyleClass("ldlSimInputGrid");

      // Shipment value
      oInputGrid.addItem(new VBox({ items: [
        new Label({ text: "Shipment Value (USD)" }),
        new Input({ type: "Number", width: "12rem",
          value: { path: "shipment/value", model: "_sim" },
          liveChange: function (e) {
            that._oSimModel.setProperty("/shipment/value", parseFloat(e.getParameter("value")) || 0);
          }
        })
      ]}).addStyleClass("ldlSimField"));

      // Carrier
      oInputGrid.addItem(new VBox({ items: [
        new Label({ text: "Carrier" }),
        new Input({ width: "12rem",
          value: { path: "shipment/carrier", model: "_sim" }
        })
      ]}).addStyleClass("ldlSimField"));

      // Mode
      var oModeSelect = new Select({ width: "10rem",
        change: function (e) {
          that._oSimModel.setProperty("/shipment/mode",
            e.getParameter("selectedItem").getKey());
        }
      });
      ["Sea","Air","Road","Rail"].forEach(function (m) {
        oModeSelect.addItem(new Item({ key: m, text: m }));
      });
      oInputGrid.addItem(new VBox({ items: [ new Label({ text: "Mode" }), oModeSelect ]}).addStyleClass("ldlSimField"));

      // Iterations slider
      oInputGrid.addItem(new VBox({ items: [
        new Label({ text: "Iterations: 1,000 – 10,000" }),
        new HBox({ alignItems: "Center", items: [
          new Slider({ width: "14rem", min: 100, max: 5000, step: 100,
            value: { path: "/iterations", model: "_sim" },
            liveChange: function (e) {
              that._oSimModel.setProperty("/iterations", e.getParameter("value"));
            }
          }),
          new Text({ text: { path: "/iterations", model: "_sim" } }).addStyleClass("ldlSliderVal")
        ]})
      ]}).addStyleClass("ldlSimField"));

      oInputPanel.addContent(oInputGrid);

      // ── Scenario selector ──
      var oScenPanel = new Panel({ headerText: "Scenario", expandable: true, expanded: true });
      var oScenBox   = new HBox({ wrap: "Wrap", alignItems: "End" }).addStyleClass("ldlScenRow");

      var oScenSelect = new Select({ width: "16rem",
        change: function (e) {
          that._oSimModel.setProperty("/selectedScenario",
            e.getParameter("selectedItem").getKey());
        }
      });
      var aScens = ["Baseline","PortCongestion","WeatherDisruption","CustomsDelay","CapacityShortage","Strike","Geopolitical","Custom"];
      aScens.forEach(function (s) { oScenSelect.addItem(new Item({ key: s, text: s })); });

      oScenBox.addItem(new VBox({ items: [new Label({ text: "Scenario" }), oScenSelect] }).addStyleClass("ldlSimField"));

      oScenBox.addItem(new Button({
        text:  "Run Simulation",
        type:  "Emphasized",
        icon:  "sap-icon://play",
        press: function () { that._runSimulation(); }
      }).addStyleClass("ldlRunBtn"));

      oScenBox.addItem(new Button({
        text:  "Compare All Scenarios",
        type:  "Default",
        icon:  "sap-icon://chart-table-view",
        press: function () { that._runComparison(); }
      }));

      oScenPanel.addContent(oScenBox);

      // ── Busy ──
      this._oBusy = new BusyIndicator({ visible: false, size: "Small" });

      // ── Result panels ──
      this._oResultPanel      = this._buildResultPanel();
      this._oComparisonPanel  = this._buildComparisonPanel();

      // ── Root ──
      var oRoot = new VBox({
        items: [ oInputPanel, oScenPanel, this._oBusy, this._oResultPanel, this._oComparisonPanel ]
      }).addStyleClass("ldlSimRoot");

      oRoot.setModel(this._oSimModel, "_sim");
      this.setAggregation("_content", oRoot);
    },

    _buildResultPanel: function () {
      var oPanel = new Panel({ headerText: "Simulation Results", expandable: true, expanded: true, visible: false });
      var oBox   = new VBox().addStyleClass("ldlResultBox");

      // P-stats row
      var oStatsRow = new HBox({ justifyContent: "SpaceBetween" }).addStyleClass("ldlPStatsRow");
      [
        { id: "p50",       label: "P50 (median) delay" },
        { id: "p90",       label: "P90 delay"         },
        { id: "p99",       label: "P99 (worst case)"  },
        { id: "onTimeProb",label: "On-time probability"},
        { id: "costP90",   label: "Cost P90 (USD)"    }
      ].forEach(function (oStat) {
        var oTile = new VBox({ alignItems: "Center" }).addStyleClass("ldlPStatTile");
        oTile.addItem(new Text({ id: "ldlStat_" + oStat.id }).addStyleClass("ldlPStatValue"));
        oTile.addItem(new Text({ text: oStat.label }).addStyleClass("ldlPStatLabel"));
        oStatsRow.addItem(oTile);
      });
      oBox.addItem(oStatsRow);

      // Histogram bar chart (CSS bars)
      oBox.addItem(new Title({ text: "Delay Distribution (days)", level: "H6" }).addStyleClass("ldlHistTitle"));
      this._oHistBox = new HBox({ alignItems: "flex-end" }).addStyleClass("ldlHistogram");
      oBox.addItem(this._oHistBox);

      oPanel.addContent(oBox);
      return oPanel;
    },

    _buildComparisonPanel: function () {
      var oPanel = new Panel({ headerText: "Scenario Comparison", expandable: true, expanded: true, visible: false });
      this._oCompTable = new Table({
        alternateRowColors: true,
        noDataText: "Run comparison to see results.",
        columns: [
          new Column({ header: new Text({ text: "Scenario" })                          }),
          new Column({ header: new Text({ text: "P50 delay (d)" }), hAlign: "Center"  }),
          new Column({ header: new Text({ text: "P90 delay (d)" }), hAlign: "Center"  }),
          new Column({ header: new Text({ text: "On-Time %" }),      hAlign: "Center"  }),
          new Column({ header: new Text({ text: "Delay %" }),        hAlign: "Center"  }),
          new Column({ header: new Text({ text: "Severe Risk %" }),  hAlign: "Center"  }),
          new Column({ header: new Text({ text: "Cost P90 (USD)" }), hAlign: "End"     })
        ]
      });
      oPanel.addContent(this._oCompTable);
      return oPanel;
    },

    // ── Simulation runner ───────────────────────────────────────────────────

    _runSimulation: function () {
      var that      = this;
      var sScenario = this._oSimModel.getProperty("/selectedScenario");
      var oShipment = this._oSimModel.getProperty("/shipment");
      var nIter     = this._oSimModel.getProperty("/iterations");

      // Update engine iterations
      this._oEngine._nIterations = nIter;

      this._oBusy.setVisible(true);

      // Run asynchronously to keep UI responsive
      setTimeout(function () {
        try {
          var oResult = that._oEngine.simulate(oShipment, sScenario);
          that._renderResult(oResult);
          that.fireSimulationComplete({ scenario: sScenario, result: oResult });
        } catch (e) {
          MessageToast.show("Simulation error: " + e.message);
        }
        that._oBusy.setVisible(false);
      }, 50);
    },

    _runComparison: function () {
      var that      = this;
      var oShipment = this._oSimModel.getProperty("/shipment");
      var aScenarios= ["Baseline","PortCongestion","WeatherDisruption","CustomsDelay","CapacityShortage","Strike","Geopolitical"];

      this._oBusy.setVisible(true);
      setTimeout(function () {
        try {
          var oComp = that._oEngine.compareScenarios(oShipment, aScenarios);
          that._renderComparison(oComp);
        } catch (e) {
          MessageToast.show("Comparison error: " + e.message);
        }
        that._oBusy.setVisible(false);
      }, 100);
    },

    _renderResult: function (oResult) {
      var oD = oResult.delays;
      var oC = oResult.costs;

      var setVal = function (sId, sText) {
        var oCtrl = sap.ui.getCore().byId("ldlStat_" + sId);
        if (oCtrl) { oCtrl.setText(sText); }
      };

      setVal("p50",        oD.p50 + " days");
      setVal("p90",        oD.p90 + " days");
      setVal("p99",        oD.p99 + " days");
      setVal("onTimeProb", Math.round(oResult.onTimeProb * 100) + "%");
      setVal("costP90",    "$" + oC.p90.toLocaleString());

      // Histogram
      this._oHistBox.destroyItems();
      var nMax = Math.max.apply(null, oD.histogram.map(function (b) { return b.count; })) || 1;
      oD.histogram.forEach(function (oBin) {
        var nH  = Math.max(4, Math.round((oBin.count / nMax) * 120));
        var oBar = new VBox({ alignItems: "Center" }).addStyleClass("ldlHistBar");
        oBar.addItem(new Text({ text: oBin.count }).addStyleClass("ldlHistCount"));
        var oFill = document.createElement ? null : null;
        var oBarFill = new sap.m.Image ? null : null;
        oBar.addItem(new Text({ text: oBin.from + "d" }).addStyleClass("ldlHistLabel"));
        this._oHistBox.addItem(oBar);
      }, this);

      this._oResultPanel.setVisible(true);
    },

    _renderComparison: function (oComp) {
      var oModel = new JSONModel({ items: oComp.comparison });
      this._oCompTable.setModel(oModel, "_comp");
      this._oCompTable.destroyItems();
      this._oCompTable.bindItems({
        model: "_comp", path: "/items",
        template: (function () {
          var oRow = new ColumnListItem();
          oRow.addCell(new Text({ text: "{_comp>scenario}" }));
          oRow.addCell(new ObjectNumber({ number: "{_comp>p50}",       unit: "d",    hAlign: "Center" }));
          oRow.addCell(new ObjectNumber({ number: "{_comp>p90}",       unit: "d",    hAlign: "Center" }));
          oRow.addCell(new ObjectStatus({ text: "{_comp>onTimeProb}%", state: "Success"               }));
          oRow.addCell(new ObjectStatus({
            text: "{_comp>delayProb}%",
            state: {
              path: "_comp>delayProb",
              formatter: function (n) { return n > 50 ? "Error" : n > 30 ? "Warning" : "Success"; }
            }
          }));
          oRow.addCell(new ObjectStatus({
            text: "{_comp>severeProb}%",
            state: {
              path: "_comp>severeProb",
              formatter: function (n) { return n > 20 ? "Error" : n > 10 ? "Warning" : "Success"; }
            }
          }));
          oRow.addCell(new ObjectNumber({
            number: { path: "_comp>costP90", formatter: function (n) { return "$" + Math.round(n).toLocaleString(); }},
            hAlign: "End"
          }));
          return oRow;
        })()
      });
      this._oComparisonPanel.setVisible(true);
    }
  });
});
