# Architecture Guide

## System Components

### Control Tower (`packages/control-tower`)

A standard SAP UI5 Fiori application structured as a Multi-Target Application (MTA)
for deployment to SAP BTP Cloud Foundry.

```
packages/control-tower/
├── webapp/                     SAP UI5 Frontend
│   ├── service/
│   │   ├── S4HanaService.js    OData v2 client — all S/4HANA calls
│   │   └── TrackCargoService.js REST client — all TrackCargo calls
│   ├── model/
│   │   ├── ErrorHandler.js     Global OData error handler
│   │   └── Formatter.js        Pure formatter functions
│   ├── controller/             One controller per view (MVC)
│   ├── view/                   XML views + dialog fragments
│   └── manifest.json           App descriptor + 4 OData model declarations
├── approuter/
│   └── xs-app.json             Route rules — maps URL prefixes → destinations
├── mta.yaml                    MTA deployment descriptor
└── xs-security.json            XSUAA role definitions
```

### Delay Library (`packages/logistics-delay-lib`)

A standard SAP UI5 library (`type: library` in ui5.yaml). Libraries are different
from applications — they register controls and types into a namespace, and are
consumed by applications as dependencies.

```
packages/logistics-delay-lib/
├── src/
│   ├── library.js              Library root — registers types + controls
│   ├── .library                SAP UI5 Tooling library descriptor
│   ├── rules/
│   │   └── RulesEngine.js      Framework-agnostic rule evaluator
│   ├── simulation/
│   │   └── DelaySimulationEngine.js  Monte Carlo engine
│   ├── control/
│   │   ├── DelayMonitor.js     Composite control
│   │   ├── RulesEditor.js      Composite control
│   │   └── DelaySimulatorControl.js  Composite control
│   └── themes/base/            Horizon-compatible CSS
└── demo/                       Standalone demo app
```

---

## Data Flow

### S/4HANA data path

```
                   manifest.json declares 4 ODataModels
                          ↓
     Controller calls S4HanaService.js method
                          ↓
     S4HanaService._read(oModel, sEntitySet, oOptions)
                          ↓
     oModel.read() → HTTP GET /sap/opu/odata/sap/.../EntitySet?...
                          ↓
     approuter xs-app.json: /sap/* → S4HANA_BACKEND destination
                          ↓
     BTP Destination Service injects BasicAuth / OAuth header
                          ↓
     HTTPS request to SAP S/4HANA system
                          ↓
     OData v2 JSON response
                          ↓
     S4HanaService Promise resolves with oData.results array
                          ↓
     Controller writes computed values to ui JSONModel
                          ↓
     XML view binding {ui>/kpis/openPOs} updates automatically
```

### TrackCargo data path

```
     Logistics.controller.js calls TrackCargoService.js method
                          ↓
     TrackCargoService._fetch("/trackcargo/api/v1/client-orders/sea")
                          ↓
     fetch() — browser HTTP call to same origin
                          ↓
     approuter xs-app.json: /trackcargo/* → TRACKCARGO_API destination
     (strips /trackcargo prefix, injects Authorization: Bearer KEY)
                          ↓
     HTTPS GET https://trackcargo.co/api/v1/client-orders/sea
                          ↓
     JSON response
                          ↓
     TrackCargoService._computeDelayMetrics(aSeaOrders, aAirOrders)
                          ↓
     Controller writes to log JSONModel
                          ↓
     Logistics.view.xml bindings update
```

---

## Key Design Decisions

### 1. Service layer isolation

All API calls live in `S4HanaService.js` and `TrackCargoService.js`.
Controllers never call `oModel.read()` or `fetch()` directly.

**Why:** Makes it easy to swap the backend (e.g. replace TrackCargo with another
provider) without touching controllers or views. Also makes unit testing possible
by mocking the service.

### 2. `ui` JSONModel as aggregation layer

Rather than binding views directly to multiple OData models, controllers
read from OData models, aggregate/compute, and write results to a single
`ui` JSONModel. Views bind to `{ui>/...}`.

**Why:** OData models don't support client-side aggregation (e.g. sum of
`NetPurchaseOrderAmount` across 200 POs). The controller does this in JavaScript
and puts the result in the `ui` model as a formatted string.

**Exception:** Tables are bound directly to OData models
(`{procurement>/PurchaseOrders}`) for efficient server-side paging and filtering.

### 3. Formatter as a pure module

`Formatter.js` exports a plain object of functions. It has no `sap.ui.define`
dependencies beyond the module loader wrapper. Every function is pure (no side
effects, no `this` references).

**Why:** Pure functions are trivially unit-testable and reusable in both XML
binding formatters and controller code.

### 4. Library as a separate BTP package

The delay library deploys independently from the Control Tower app.

**Why:**
- Other SAP UI5 apps in the same BTP space can load the library
- Library updates don't require redeploying the Control Tower
- The library's CI/CD pipeline runs independently

### 5. Rules engine is framework-agnostic

`RulesEngine.js` uses only `sap.ui.base.Object` — no `sap.m` or rendering
dependency. The simulation engine is even lighter — just vanilla JavaScript.

**Why:** Makes them usable in Node.js CAP services, OPA5 tests, and other
non-browser contexts without pulling in the entire UI5 framework.

---

## BTP Services Used

| Service | Plan | Purpose |
|---|---|---|
| `html5-apps-repo` app-host | free | Stores built UI5 app bundles |
| `html5-apps-repo` app-runtime | free | Serves the UI5 app from the browser |
| `xsuaa` application | free | Authentication + role-based authorization |
| `destination` lite | free | Stores S4HANA_BACKEND + TRACKCARGO_API credentials |
| App Router (`@sap/approuter`) | CF app | Routes requests, proxies to destinations, enforces XSUAA |

---

## Threat Model

| Threat | Mitigation |
|---|---|
| API key exposed in browser | TrackCargo key stored in BTP Destination, injected server-side |
| S/4HANA credentials leaked | Stored encrypted in BTP Destination, never in source code |
| Unauthorized data access | XSUAA validates JWT on every route, role-check on sensitive routes |
| XSS in rule message templates | Template interpolation is server-side only; no `innerHTML` usage |
| CSRF on POST /create endpoint | `csrfProtection: false` on TrackCargo route only (external API); S/4HANA POST routes use CSRF tokens |
| Supply chain attack via npm | Pin dependency versions; review `package-lock.json` on PRs |
