/**
 * Logistics.controller.js
 * ─────────────────────────────────────────────────────────────────────────────
 * CEO Logistics & Delay Control Tower tab.
 * Calls TrackCargo REST API via BTP Destination "TRACKCARGO_API".
 *
 * Data flow:
 *   TrackCargoService._get(...)           (fetch via BTP App Router proxy)
 *     → /trackcargo/api/v1/client-orders/sea
 *     → /trackcargo/api/v1/client-orders/air
 *     → /trackcargo/api/v1/client-orders/sea/overview
 *     → /trackcargo/api/v1/client-orders/air/overview
 *     → /trackcargo/api/v1/client-orders/{id}/tracking  (on row press)
 *     → /trackcargo/api/v1/client-orders/create          (on "Track New" dialog)
 *   → TrackCargoService._computeDelayMetrics()
 *   → oUIModel ("ui") → XML view bindings
 */
sap.ui.define([
  "./BaseController",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageBox",
  "sap/m/MessageToast",
  "sap/m/Dialog",
  "sap/m/Button",
  "sap/m/Input",
  "sap/m/Select",
  "sap/ui/core/Item",
  "sap/m/Label",
  "sap/m/VBox",
  "sap/m/Text",
  "sap/m/ObjectStatus",
  "sap/m/ColumnListItem",
  "sap/m/List",
  "sap/m/StandardListItem",
  "com/company/controltower/service/TrackCargoService"
], function (
  BaseController, JSONModel, MessageBox, MessageToast,
  Dialog, Button, Input, Select, Item, Label, VBox, Text,
  ObjectStatus, ColumnListItem, List, StandardListItem,
  TrackCargoService
) {
  "use strict";

  return BaseController.extend("com.company.controltower.controller.Logistics", {

    onInit: function () {
      BaseController.prototype.onInit.apply(this, arguments);

      // Instantiate TrackCargo service
      this._oTrackSvc = new TrackCargoService(this.getUIModel());

      // Local model holds all logistics data
      this._oLogModel = new JSONModel({
        busy:           false,
        lastRefresh:    "—",
        apiConnected:   false,

        // KPIs
        kpis: {
          totalShipments: "—",
          delayed:        "—",
          onTime:         "—",
          inTransit:      "—",
          onTimeRate:     "—%",
          onTimeRateState:"None",
          avgDelayDays:   "—",
          seaOrders:      "—",
          airOrders:      "—"
        },

        // Overview breakdown
        seaOverview: {},
        airOverview: {},

        // Tables
        delayedShipments:  [],
        carrierBreakdown:  [],
        laneBreakdown:     [],
        allShipments:      [],
        filteredShipments: [],

        // Tracking dialog
        trackingDialog: {
          orderId:    "",
          events:     [],
          status:     "",
          eta:        "",
          delayDays:  0
        }
      });
      this.getView().setModel(this._oLogModel, "log");

      // Load on route match
      this.getOwnerComponent().getRouter()
        .getRoute("logistics")
        .attachPatternMatched(this._loadData, this);
    },

    // ── Main data loader ──────────────────────────────────────────
    _loadData: function () {
      this._oLogModel.setProperty("/busy", true);
      var oSvc = this._oTrackSvc;
      var oLog = this._oLogModel;

      // 1. Combined overview (KPIs from overview endpoints)
      var pOverview = oSvc.getCombinedOverview()
        .then(function (oData) {
          oLog.setProperty("/kpis/totalShipments", oData.totalShipments.toLocaleString());
          oLog.setProperty("/kpis/delayed",        oData.delayed.toLocaleString());
          oLog.setProperty("/kpis/onTime",         oData.onTime.toLocaleString());
          oLog.setProperty("/kpis/inTransit",      oData.inTransit.toLocaleString());
          oLog.setProperty("/kpis/seaOrders",      oData.seaTotal.toLocaleString());
          oLog.setProperty("/kpis/airOrders",      oData.airTotal.toLocaleString());
          oLog.setProperty("/seaOverview",         oData);
          oLog.setProperty("/airOverview",         oData);
        });

      // 2. Full delay analytics (sea + air orders merged)
      var pDelays = oSvc.getDelayAnalytics()
        .then(function (oMetrics) {
          var nRate = oMetrics.onTimeRate;
          oLog.setProperty("/kpis/onTimeRate",      nRate + "%");
          oLog.setProperty("/kpis/onTimeRateState", oMetrics.onTimeRateState);
          oLog.setProperty("/kpis/avgDelayDays",    oMetrics.avgDelayDays + " days");

          oLog.setProperty("/delayedShipments",     oMetrics.recentDelays);
          oLog.setProperty("/carrierBreakdown",     oMetrics.carrierBreakdown);
          oLog.setProperty("/laneBreakdown",        oMetrics.laneBreakdown);
        });

      // 3. Recent orders for the main table
      var pRecent = oSvc.getRecentOrders(100)
        .then(function (aOrders) {
          var aEnriched = aOrders.map(function (o) {
            var sStatus = (o.status || o.trackingStatus || "").toLowerCase();
            var bDelayed = sStatus.includes("delay") ||
                           o.isDelayed === true ||
                           (parseFloat(o.delayDays || 0) > 0);
            return {
              orderId:    o.orderId    || o.id     || "—",
              reference:  o.reference || o.blNumber || o.awbNumber || "—",
              carrier:    o.carrier   || o.shippingLine || o.carrierName || "—",
              mode:       (o.type     || o.mode   || "sea").toUpperCase(),
              modeIcon:   (o.type || o.mode || "sea").toLowerCase() === "air"
                            ? "sap-icon://flight" : "sap-icon://shipping-status",
              pol:        o.portOfLoading   || o.origin      || o.pol || "—",
              pod:        o.portOfDischarge || o.destination || o.pod || "—",
              eta:        o.eta || o.estimatedArrival || "—",
              status:     o.status || "—",
              statusState:bDelayed ? "Error"
                        : sStatus.includes("complet") || sStatus.includes("arriv")
                          ? "Success" : "None",
              delayDays:  Math.round(parseFloat(o.delayDays || 0)),
              delayState: parseFloat(o.delayDays || 0) > 0 ? "Error" : "Success",
              isDelayed:  bDelayed
            };
          });
          oLog.setProperty("/allShipments",      aEnriched);
          oLog.setProperty("/filteredShipments", aEnriched);
        });

      Promise.all([pOverview, pDelays, pRecent])
        .then(function () {
          oLog.setProperty("/busy",         false);
          oLog.setProperty("/apiConnected", true);
          oLog.setProperty("/lastRefresh",
            new Date().toLocaleTimeString("en-US",
              { hour: "2-digit", minute: "2-digit", second: "2-digit" }));

          // Push delay alerts into the global ui model alert list
          this._pushDelayAlerts();
        }.bind(this))
        .catch(function (oErr) {
          oLog.setProperty("/busy", false);
          this._handleError(oErr, "TrackCargo API");
        }.bind(this));
    },

    // ── Push logistics delay alerts into the global ui model ─────
    _pushDelayAlerts: function () {
      var oUI   = this.getUIModel();
      var oLog  = this._oLogModel;
      var aExisting = (oUI.getProperty("/alerts") || [])
        .filter(function (a) { return !a.id.startsWith("TC_"); });

      var nDelayed = parseInt(
        (oLog.getProperty("/kpis/delayed") || "0").replace(/,/g, "")) || 0;
      var sRate    = oLog.getProperty("/kpis/onTimeRate") || "100%";
      var nRate    = parseInt(sRate) || 100;

      if (nDelayed > 0) {
        aExisting.push({
          id: "TC_DELAYED", priority: "High", priorityState: "Error",
          icon: "sap-icon://shipping-status", module: "TrackCargo",
          title: nDelayed + " Shipments Delayed — Live via TrackCargo API",
          description: "On-time rate: " + sRate + ". " + nDelayed +
                       " active shipments past ETA. Check Logistics tab for details.",
          category: "Logistics", time: new Date().toLocaleTimeString()
        });
      }

      if (nRate < 85 && nDelayed > 0) {
        aExisting.push({
          id: "TC_OTR", priority: "Medium", priorityState: "Warning",
          icon: "sap-icon://warning2", module: "TrackCargo",
          title: "Logistics On-Time Rate " + sRate + " — Below 85% Threshold",
          description: "Sea & air freight combined OTR from TrackCargo. " +
                       "Review carrier performance in Logistics tab.",
          category: "Logistics", time: new Date().toLocaleTimeString()
        });
      }

      oUI.setProperty("/alerts", aExisting);
      oUI.setProperty("/kpis/alertCount", aExisting.length);
    },

    // ── Shipment table filter/search ──────────────────────────────
    onShipmentSearch: function (oEvent) {
      var sQuery = (oEvent.getParameter("query") || "").toLowerCase();
      var aAll   = this._oLogModel.getProperty("/allShipments") || [];
      if (!sQuery) {
        this._oLogModel.setProperty("/filteredShipments", aAll);
        return;
      }
      this._oLogModel.setProperty("/filteredShipments",
        aAll.filter(function (o) {
          return (o.reference || "").toLowerCase().includes(sQuery) ||
                 (o.carrier   || "").toLowerCase().includes(sQuery) ||
                 (o.pol       || "").toLowerCase().includes(sQuery) ||
                 (o.pod       || "").toLowerCase().includes(sQuery) ||
                 (o.orderId   || "").toLowerCase().includes(sQuery);
        })
      );
    },

    onModeFilter: function (oEvent) {
      var sKey = oEvent.getParameter("item").getKey();
      var aAll = this._oLogModel.getProperty("/allShipments") || [];
      if (sKey === "ALL") {
        this._oLogModel.setProperty("/filteredShipments", aAll);
      } else if (sKey === "DELAYED") {
        this._oLogModel.setProperty("/filteredShipments",
          aAll.filter(function (o) { return o.isDelayed; }));
      } else {
        this._oLogModel.setProperty("/filteredShipments",
          aAll.filter(function (o) {
            return (o.mode || "").toUpperCase() === sKey;
          }));
      }
    },

    // ── Row press → fetch live tracking events ────────────────────
    onShipmentPress: function (oEvent) {
      var oCtx    = oEvent.getSource().getBindingContext("log");
      if (!oCtx) { return; }
      var oShip   = oCtx.getObject();
      var sId     = oShip.orderId;

      this._oLogModel.setProperty("/trackingDialog", {
        orderId:   sId,
        reference: oShip.reference,
        carrier:   oShip.carrier,
        mode:      oShip.mode,
        pol:       oShip.pol,
        pod:       oShip.pod,
        status:    oShip.status,
        eta:       oShip.eta,
        delayDays: oShip.delayDays,
        events:    [],
        loadingEvents: true
      });

      this._openTrackingDialog();

      // Fetch live tracking events for this order
      this._oTrackSvc.getOrderTracking(sId)
        .then(function (oTracking) {
          var aEvents = (oTracking.events || oTracking.trackingEvents || [])
            .map(function (ev) {
              var sEvStatus = (ev.status || ev.event || ev.type || "").toLowerCase();
              return {
                timestamp:  ev.timestamp || ev.date || ev.eventDate || "—",
                location:   ev.location  || ev.port || ev.city || "—",
                event:      ev.event     || ev.description || ev.status || "—",
                status:     ev.status    || ev.type || "—",
                statusIcon: sEvStatus.includes("delay")
                              ? "sap-icon://alert"
                            : sEvStatus.includes("arriv") || sEvStatus.includes("deliver")
                              ? "sap-icon://accept"
                            : sEvStatus.includes("depart") || sEvStatus.includes("load")
                              ? "sap-icon://shipping-status"
                            : "sap-icon://lateness",
                statusState:sEvStatus.includes("delay") ? "Error"
                          : sEvStatus.includes("arriv") || sEvStatus.includes("deliver")
                            ? "Success" : "None"
              };
            });

          this._oLogModel.setProperty("/trackingDialog/events",        aEvents);
          this._oLogModel.setProperty("/trackingDialog/loadingEvents", false);
          if (oTracking.eta || oTracking.estimatedArrival) {
            this._oLogModel.setProperty("/trackingDialog/eta",
              oTracking.eta || oTracking.estimatedArrival);
          }
          if (typeof oTracking.delayDays === "number") {
            this._oLogModel.setProperty("/trackingDialog/delayDays", oTracking.delayDays);
          }
        }.bind(this))
        .catch(function (oErr) {
          this._oLogModel.setProperty("/trackingDialog/loadingEvents", false);
          this._oLogModel.setProperty("/trackingDialog/events", [{
            timestamp:   new Date().toISOString(),
            location:    "API",
            event:       "Unable to load tracking events: " + oErr.message,
            statusState: "Error",
            statusIcon:  "sap-icon://alert"
          }]);
        }.bind(this));
    },

    // ── Tracking detail dialog ────────────────────────────────────
    _openTrackingDialog: function () {
      if (!this._oTrackDialog) {
        this._oTrackDialog = sap.ui.xmlfragment(
          "com.company.controltower.view.TrackingDialog",
          this
        );
        this.getView().addDependent(this._oTrackDialog);
      }
      this._oTrackDialog.setModel(this._oLogModel, "log");
      this._oTrackDialog.open();
    },

    onCloseTrackingDialog: function () {
      if (this._oTrackDialog) { this._oTrackDialog.close(); }
    },

    // ── "Track New Shipment" dialog ───────────────────────────────
    onOpenTrackNew: function () {
      if (!this._oNewDialog) {
        this._oNewDialog = sap.ui.xmlfragment(
          "com.company.controltower.view.TrackNewDialog",
          this
        );
        this.getView().addDependent(this._oNewDialog);
      }
      this._oNewDialog.open();
    },

    onCancelTrackNew: function () {
      if (this._oNewDialog) { this._oNewDialog.close(); }
    },

    onSubmitTrackNew: function () {
      var oF  = sap.ui.getCore();
      var sType      = oF.byId("trackTypeSelect").getSelectedKey();
      var sTracking  = oF.byId("trackingNumberInput").getValue().trim();
      var sCarrier   = oF.byId("carrierInput").getValue().trim();
      var sReference = oF.byId("referenceInput").getValue().trim();

      if (!sTracking || !sCarrier) {
        MessageToast.show("Tracking number and carrier are required.");
        return;
      }

      this._oTrackSvc.createOrder({
        type:           sType,
        trackingNumber: sTracking,
        carrier:        sCarrier,
        reference:      sReference
      }).then(function (oRes) {
        MessageToast.show("Shipment added to tracking: " +
          (oRes.orderId || oRes.id || sTracking));
        if (this._oNewDialog) { this._oNewDialog.close(); }
        this._loadData();
      }.bind(this)).catch(function (oErr) {
        MessageBox.error("Failed to create tracking order:\n" + oErr.message);
      });
    },

    // ── Exports ───────────────────────────────────────────────────
    onExportDelayed: function () {
      var aData = this._oLogModel.getProperty("/delayedShipments") || [];
      this._exportToExcel(aData, [
        { label: "Order ID",   property: "orderId",   type: "string" },
        { label: "Reference",  property: "reference", type: "string" },
        { label: "Carrier",    property: "carrier",   type: "string" },
        { label: "Mode",       property: "mode",      type: "string" },
        { label: "POL",        property: "pol",       type: "string" },
        { label: "POD",        property: "pod",       type: "string" },
        { label: "Delay Days", property: "delayDays", type: "number" },
        { label: "ETA",        property: "eta",       type: "string" },
        { label: "Status",     property: "status",    type: "string" }
      ], "DelayedShipments_TrackCargo");
    },

    onRefresh: function () {
      this._loadData();
      MessageToast.show("Refreshing from TrackCargo API…");
    }
  });
});
